# Material 3 Expressive UI & Motion Upgrade — PixelBoost ADB

อัปเกรดหน้าตาและระบบแอนิเมชันของแอป **PixelBoost ADB** ทั้งหมดให้เป็นมาตรฐาน **Google Material Design 3 Expressive (2025+)** บน Jetpack Compose โดยผสานระบบสี Tonal Surface ครบทุกระดับ, แอนิเมชันฟิสิกส์แบบสปริง (Spring Physics), การเปลี่ยนทรงปุ่ม/การ์ด (Shape Morphing), ตัวโหลดทรงโพลีกอน/แถบคลื่น และรูปทรงเรขาคณิตผสมผสาน โดยคงความเร็วและความเข้าใจง่ายของเมนูภาษาไทยไว้ครบถ้วน

---

## User Review & Critical Decisions

> [!IMPORTANT]
> แผนนี้อ้างอิงตามสเปก Material 3 Expressive ที่แนบมาและตัวเลือกที่คุณยืนยันไว้ครบทุกข้อ พร้อมคงฟังก์ชันปรับแต่ง Android 14 (No-Root ผ่าน Shizuku) และระบบโปรไฟล์/ประวัติในเครื่องไว้ครบเหมือนเดิม

- **Confirmed Decision 1 (ขอบเขตการอัปเกรด)**: อัปเกรด **ทั้งแอปทุกหน้า** (`หน้าหลัก Dashboard`, `หน้าปรับแต่ง Tweaks`, `หน้าจัดการแอป & Bloatware`, `หน้าโปรไฟล์และประวัติ`, รวมถึง Shell การนำทางและ Bottom Sheets)
- **Confirmed Decision 2 (ระบบสี & Surface Tonal)**: คงตัวเลือก **3 เฉดสีหลัก (ฟ้า Google Blue `#4285F4` / ม่วง M3 `#6750A4` / เขียว Emerald `#34A853`)** พร้อมโหมดมืด/สว่าง/ตามระบบ และอัปเกรดเป็น **Tonal Surface Container Hierarchy ครบชุด** (`surfaceContainerLowest` ถึง `surfaceContainerHighest`, `inverseSurface`, `inversePrimary`, `tertiaryContainer` ที่อิ่มตัวมากขึ้น)
- **Confirmed Decision 3 (ลูกเล่น Motion & Shape Expressive)**: ใส่ครบทั้ง 4 กลุ่ม ได้แก่:
  1. ปุ่มเปลี่ยนทรงเมื่อกด (Pill -> Squarer corners) และกลุ่มปุ่มเชื่อมต่อกัน (Connected Button Groups / Split Actions)
  2. แถบนำทางที่ตัวบ่งชี้ (Pill Indicator) ขยับด้วยสปริง และแถบค้นหาทรงแคปซูลเต็มบน `surfaceContainerHigh`
  3. ตัวโหลดรูปทรงโพลีกอน/ดอกไม้หมุนเปลี่ยนทรง (Morphing Polygon Loader) และแถบความคืบหน้าแบบคลื่น (Wavy Linear Progress)
  4. รูปทรงผสมผสาน (Squircle / Scallop Cookie / Star Burst) สำหรับไอคอนสถานะ, โล่ความปลอดภัย, และไฮไลต์การ์ดสำคัญ

---

## 1. Overview & Core Concept

- **What It Does**: ยกระดับ UI ของ PixelBoost ADB จาก Material 3 มาตรฐานให้มีความ "มีชีวิตชีวาและตอบสนองทางกายภาพ" ตามแนวทาง Material 3 Expressive — ทุกการแตะปุ่ม การสลับโหมด CPU/GPU การเชื่อมต่อ Shizuku และการเปลี่ยนหน้าจะตอบสนองด้วยความยืดหยุ่นของสปริงและเลเยอร์สี Tonal ที่แยกชั้นความลึกชัดเจนโดยไม่พึ่งเงาแข็ง
- **Target Audience / Persona**: ผู้ใช้มือถือ Android 14 (No-Root) ที่ต้องการเครื่องมือปรับแต่งประสิทธิภาพและ Bloatware ที่มีหน้าตาทันสมัยระดับแอปของ Google ยุค 2025+ อ่านง่ายทั้งภาษาไทยและสคริปต์ ADB
- **Key Value**:
  - **ความชัดเจนทางสายตา (Visual Hierarchy)**: ใช้โทนสี `surfaceContainer*` 5 ระดับ + `tertiary` ไฮไลต์ ทำให้แยกการ์ดหลัก การ์ดย่อย และแถบควบคุมได้ทันทีแม้ในโหมดมืด
  - **การตอบสนองที่สัมผัสได้ (Tactile Motion)**: สปริงแยก 2 โปรไฟล์ (`EXPRESSIVE` สำหรับ Hero/โหมดเด่น และ `STANDARD` สำหรับลิสต์/ตั้งค่า) พร้อมรองรับการลดแอนิเมชันเมื่อเปิด Reduced Motion บนระบบ

---

## 2. User Experience & Visual Design

### Visual Identity & Theme Tokens

- **Color System (Tonal Palettes & Semantic Roles)**:
  - รองรับ 3 Seed Accents (**Google Blue `#4285F4`**, **M3 Baseline Purple `#6750A4`**, **Google Green `#34A853`**) ทั้ง Light Mode และ Dark Mode โดยมี Baseline ตามสเปก (เช่น Dark Purple `#D0BCFF` บน Surface `#141218` และ Light Purple `#6750A4` บน Surface `#FEF7FF`)
  - เติมเต็ม Role ระดับ Surface Tonal ของ Material 3 ครบชุดใน `ColorScheme`: `surfaceContainerLowest`, `surfaceContainerLow`, `surfaceContainer`, `surfaceContainerHigh`, `surfaceContainerHighest`, `inverseSurface`, `inverseOnSurface`, `inversePrimary`
  - ใช้ `tertiary` และ `tertiaryContainer` ที่อิ่มตัวมากขึ้นสำหรับจุดเน้นสำคัญ เช่น แถบสถานะ Bloatware, ปุ่มบูสต์เกม, และ Badge แนะนำ
  - เก็บสี Google Brand (`#4285F4`, `#EA4335`, `#FBBC05`, `#34A853`) ไว้ใช้เฉพาะจุดสัญลักษณ์แบรนด์/โลโก้ใน Header อย่างประณีต

- **Typography & Emphasized Hierarchy**:
  - คงฟอนต์ภาษาไทยที่คมชัด (`Noto Sans Thai`) จับคู่กับฟอนต์ละตินตระกูล Flex/Geometric (`Roboto Flex` ร่วมกับ `Plus Jakarta Sans`) และ `JetBrains Mono` สำหรับคำสั่ง ADB
  - อัปเกรด Type Scale ให้ตรงสเปก M3 Expressive (`Display L 57/64`, `M 45/52`, `S 36/44`, `Headline L 32/40`, `M 28/36`, `S 24/32`, `Title L 22/28`, `M 16/24`, `S 14/20`, `Body L 16/24`, `M 14/20`, `S 12/16`, `Label L 14/20`, `M 12/16`, `S 11/16`)
  - ใช้ **Emphasized Variants** (น้ำหนักตัวหนาพิเศษ + ตัวเลขขนาดใหญ่) กับค่า Telemetry เช่น `% แบต`, `Hz หน้าจอ`, และจำนวนแอปที่แช่แข็ง

- **Shape Scale & Contrasting Expressive Silhouettes**:
  - นิยามชุด Corner Radius Tokens ครบ 10 ระดับ: `0dp` (None), `4dp` (XS), `8dp` (S), `12dp` (M), `16dp` (L), `20dp` (L-Increased), `28dp` (XL), `32dp` (XL-Increased), `48dp` (XXL), และ `Full` (Pill/Circle)
  - ปุ่มกดใช้ทรงแคปซูล (`Full`), การ์ดใช้ `Medium–Large (12–20dp)`, Dialog และ Bottom Sheet ใช้ `Extra-Large (28dp)`
  - เพิ่ม Custom `Shape` แบบ Expressive ได้แก่ **Scallop/Cookie** (ขอบหยักโค้ง), **Burst/Star** (แฉกนุ่มนวล), และ **Squircle** สำหรับโลโก้สถานะ Shizuku, เหรียญความปลอดภัย และไอคอนโหมด CPU/GPU

### Motion Physics & Expressive Patterns

- **Dual Spring Motion Scheme** (เขียนเป็นส่วนกลางไว้ใช้ทั้งแอป):
  - **Expressive Scheme** (Hero cards, ปุ่มโหมด CPU/GPU, Nav indicator, Bottom sheet reveal):
    - *Spatial* (ตำแหน่ง/ขนาด/รัศมีมุม — เด้งเล็กน้อย): Fast (`stiffness = 800f`, `dampingRatio = 0.6f`), Default (`380f / 0.8f`), Slow (`200f / 0.8f`)
    - *Effects* (สี/ความโปร่งแสง — ไม่เด้ง): Fast (`3800f / 1.0f`), Default (`1600f / 1.0f`), Slow (`800f / 1.0f`)
  - **Standard Scheme** (รายการ Tweak, ตัวกรอง, การตั้งค่า):
    - *Spatial*: `dampingRatio = 0.9f` กับ Stiffness `1400f / 700f / 300f`
  - **Reduced Motion Compliance**: ตรวจจับตั้งค่าระบบ (`Animator.durationScale == 0f` หรือ Accessibility reduced motion) หากเปิดไว้จะสลับจากการเคลื่อนที่สปริงเป็นการ Fade นุ่มนวลแทน
- **Required Motion Components**:
  - **Shape Morphing Buttons**: ปุ่ม Expressive ที่ตรวจจับ `InteractionSource` เมื่อกดค้างจะแปลงมุมจาก Pill (`50%`) เป็นมุมเหลี่ยมมน (`12dp`) ด้วยสปริง และกลุ่มปุ่มเลือก (Connected Button Group) ที่ชิ้นที่ถูกเลือกจะเปลี่ยนทรงและสีอย่างลื่นไหล
  - **Expressive Polygon & Wavy Loaders**: ตัวโหลดทรงโพลีกอน 8–10 แฉกที่หมุนและเปลี่ยนความมนอย่างต่อเนื่องขณะ Shizuku เชื่อมต่อ/โหลดรายการแอป พร้อมแถบความคืบหน้าแบบคลื่น (`WavyProgressIndicator`) ด้านบนเมื่อกำลังรันคำสั่ง ADB
  - **Screen & Container Transitions**: ใช้ Shared-Axis / Fade-Through ระหว่างการสลับแท็บหลัก และ Spring Indicator Animation บนแถบนำทางล่าง (Mobile) / Navigation Rail (Tablet)

### Key User Flows Across All 4 Screens

1. **Shell & Navigation**: แถบนำทางด้านล่าง (หรือ Navigation Rail เมื่อจอ >= 600dp) มีพื้นหลัง Tonal `surfaceContainer`, Active Pill ที่ขยับขนาดและสีด้วย Spatial Spring และแถบคลื่น Wavy Progress ด้านบนเมื่อรันคำสั่ง
2. **หน้าหลัก (Dashboard)**:
   - แถบเลือกโทนสีแบบ Connected Pills (ฟ้า / ม่วง / เขียว) และปุ่มสลับ Dark/Light
   - การ์ดสถานะ Shizuku ใช้รูปทรง Scallop/Burst badge ที่เปลี่ยนทรงตามสถานะการเชื่อมต่อ + ปุ่ม Morphing
   - การ์ด **โหมด CPU & GPU อัจฉริยะ** ใช้ Connected Expressive Button Group (`ภาพสวย` | `เล่นลื่น` | `สมดุล`) พร้อมไอคอนทรงเรขาคณิตเปลี่ยนตามโหมด
   - การ์ด **Quick Actions** ใช้พื้นหลังไล่ระดับ Tonal (`surfaceContainerLow` / `surfaceContainerHigh`) และเน้นค่าตัวเลข Telemetry แบบ Emphasized Typography
3. **หน้าปรับแต่ง (Tweaks)**:
   - ช่องค้นหา **Full-Pill Search Bar** บนพื้นสี `surfaceContainerHigh` ที่มุมโค้งรับกับปุ่มล้างคำค้น
   - ตัวกรองหมวดหมู่แบบ Expressive Filter Chips (เปลี่ยนมุมเมื่อเลือก) และการ์ดปรับแต่งที่เน้นคำสั่ง ADB ชัดเจน
4. **หน้าจัดการแอป & Bloatware (Apps)**:
   - ช่องค้นหา Full-Pill บน `surfaceContainerHigh` + การ์ดสรุป Bloatware ทรง Tonal Elevated
   - ขณะโหลดรายการแอปแสดง **Expressive Morphing Polygon Loader** พร้อมข้อความสถานะ
   - แถบเครื่องมือ **Floating Docked Toolbar** ด้านล่างเมื่อเข้าสู่โหมดเลือกหลายแอป (แช่แข็ง / เปิดคืน / จำกัดเบื้องหลัง)
5. **หน้าโปรไฟล์และประวัติ (Profiles & Logs)**:
   - แถบสลับย่อยแบบ Connected Button Group + Extended FAB ทรง Expressive (พร้อมข้อความ "สร้างโปรไฟล์") ที่มี Shape Morphing เมื่อกด

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: สร้างระบบ Material 3 Expressive Token & Spring Layer เองบน Compose Material 3 Stable**
  - *Chosen Approach*: สร้าง Object กลางสำหรับ Motion Specs (ค่า Stiffness & Damping Ratio ตรงตามสเปก 100%), Shape Tokens 10 ระดับ, Contrasting Vector/Polygon Shapes (`Shape`), และ M3 Tonal `ColorScheme` ครบทุก Container Role โดยไม่ต้องอัปเกรดไลบรารี `material3` ที่เสี่ยง Alpha/Beta API แตกกับ Compose BOM ปัจจุบัน
  - *Why*: คอมไพล์เสถียร 100%, ควบคุมพารามิเตอร์สปริง `800/0.6`, `380/0.8`, `200/0.8` ได้แม่นยำตามสเปกที่แนบมา และทำงานร่วมกับ Dynamic Light/Dark + 3 Seed Accents ได้ทันที
  - *Alternatives Considered*: เปลี่ยน Compose BOM ไปใช้ Material3 Alpha 1.4+ ซึ่งอาจทำให้ API ของ `SegmentedButton` หรือ Navigation Compose เดิมติดปัญหา Breaking Changes

- **Decision 2: คงภาษาไทยที่อ่านง่ายพร้อมเพิ่ม Roboto Flex / Plus Jakarta Sans คู่กับ Noto Sans Thai**
  - *Chosen Approach*: ตรวจสอบติดตั้ง `Roboto Flex` (ถ้ามีใน `font-util`) หรือใช้ `Plus Jakarta Sans` ร่วมกับ `Noto Sans Thai` และ `JetBrains Mono` พร้อมปรับ Scale & Emphasized Weight ตามสเปก M3 Expressive
  - *Why*: สระและวรรณยุกต์ภาษาไทยต้องอาศัย `Noto Sans Thai` เพื่อไม่ให้ตัวอักษรขาดหรือเหลื่อม ส่วนตัวเลข/ภาษาอังกฤษจะได้ความคมชัดสไตล์ Google Sans Flex / Roboto Flex

- **Decision 3: รักษา `testTag` เดิมและ Accessibility (48dp + Contrast AA)**
  - *Chosen Approach*: คง `Modifier.testTag(...)` และ `minimumInteractiveComponentSize()` บนทุกปุ่ม/การ์ดใหม่ และเพิ่ม Ripple/State layer + Focus border สี `secondary` ความหนา `3.dp` เมื่อโฟกัสด้วยคีย์บอร์ด
  - *Why*: ไม่ทำให้ความเข้ากันได้กับการทดสอบอัตโนมัติหรือผู้ใช้ TalkBack/Keyboard ลดลง

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Hierarchy Diagram

```text
┌──────────────────────────────────────────────────────────────────────┐
│                        PixelBoostTheme (Theme.kt)                    │
│  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────┐ │
│  │ ExpressiveColor    │  │ ExpressiveMotion   │  │ Expressive     │ │
│  │ Tonal Palettes     │  │ (Expressive /      │  │ Shapes &       │ │
│  │ (Blue/Purple/Green │  │  Standard Springs  │  │ Typography     │ │
│  │  + 5 Surface Lvls) │  │  + Reduced Motion) │  │ (10 Radii)     │ │
│  └─────────┬──────────┘  └─────────┬──────────┘  └───────┬────────┘ │
└────────────┼───────────────────────┼─────────────────────┼──────────┘
             └───────────────────────┼─────────────────────┘
                                     ▼
┌──────────────────────────────────────────────────────────────────────┐
│                   Expressive UI Kit (Components)                     │
│  • MorphingPillButton / ConnectedButtonGroup / ExpressiveIconBadge   │
│  • MorphingPolygonLoader (Canvas) / WavyLinearProgressIndicator      │
│  • ExpressiveSearchBar (Full-Pill on surfaceContainerHigh)           │
│  • FloatingDockedToolbar (Multi-select & Actions)                    │
└────────────────────────────────────┬─────────────────────────────────┘
                                     ▼
┌──────────────────────────────────────────────────────────────────────┐
│                  MainActivity Shell & 4 App Screens                  │
│  ┌─────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│  │ Dashboard   │ │ Tweaks       │ │ Apps/Bloat   │ │ Profiles/Log │ │
│  │ (Hero +     │ │ (Pill Search │ │ (Polygon     │ │ (Extended    │ │
│  │  CPU/GPU    │ │  + Connected │ │  Loader +    │ │  FAB +       │ │
│  │  Switcher)  │ │  Chips)      │ │  Docked Bar) │ │  History)    │ │
│  └─────────────┘ └──────────────┘ └──────────────┘ └──────────────┘ │
└────────────────────────────────────┬─────────────────────────────────┘
                                     ▼
┌──────────────────────────────────────────────────────────────────────┐
│              TunerViewModel + DataStore + Room + Shizuku             │
│         (Existing ADB UID 2000 Execution & Local Persistence)        │
└──────────────────────────────────────────────────────────────────────┘
```

### Data Model & State Mapping

- **Theme & Preferences (DataStore)**: คง `ThemeMode` (`DARK`, `LIGHT`, `SYSTEM`) และ `ThemeAccent` (`BLUE`, `PURPLE`, `GREEN`) โดยปรับค่าเริ่มต้นหรือ Tonal mapping ให้ครบ `surfaceContainerLowest`..`surfaceContainerHighest`, `tertiaryContainer`, `inverseSurface`, `inversePrimary`
- **Reduced Motion State**: เพิ่ม CompositionLocal (`LocalReduceMotion`) ที่อ่านการตั้งค่าความเร็วแอนิเมชันของระบบและส่งค่าสปริงหรือ Fade Transition ให้คอมโพเนนต์ Expressive ทุกตัวโดยอัตโนมัติ
- **Interactive Component & State Mapping**:
  - **Morphing Buttons & Connected Groups**: ฟังสถานะ `collectIsPressedAsState()` และ `selected` เพื่อ Animate มุมโค้ง (`animateDpAsState` ด้วย `ExpressiveMotion.SpatialFast`) และความกว้าง/สี Indicator
  - **Wavy Progress & Morphing Polygon Loader**: ขับเคลื่อนเฟสคลื่นและจุดยอดโพลีกอนผ่าน `rememberInfiniteTransition` เมื่อ `isExecuting` หรือ `isLoadingApps` เป็นจริง และหยุดวาด/เปลี่ยนเป็น Fade นิ่งเมื่อเปิด Reduced Motion
  - **Navigation Indicator**: แถบนำทางแสดง `NavigationBar` (<600dp) / `NavigationRail` (>=600dp) พร้อม AnimatedContent แบบ Fade-Through ระหว่างปลายทาง
  - **Floating Docked Toolbar**: แสดงแบบ Spring Pop-in เหนือ Navigation Bar เมื่อ `selectedPackages.isNotEmpty()` ในหน้าจัดการแอป พร้อม `navigationBarsPadding` ที่ปลอดภัยไม่ชนขอบจอ
