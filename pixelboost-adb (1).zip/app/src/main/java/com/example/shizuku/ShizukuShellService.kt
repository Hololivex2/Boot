package com.example.shizuku

import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

@Keep
class ShizukuShellService : IShizukuShellService.Stub() {

    override fun execCommand(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(false)
                .start()

            val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdout = StringBuilder()
            val stderr = StringBuilder()

            val outThread = Thread {
                stdoutReader.useLines { lines ->
                    lines.forEach { stdout.appendLine(it) }
                }
            }
            val errThread = Thread {
                stderrReader.useLines { lines ->
                    lines.forEach { stderr.appendLine(it) }
                }
            }

            outThread.start()
            errThread.start()

            val finished = process.waitFor(20, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                outThread.join(1000)
                errThread.join(1000)
                return "-1|TIMEOUT|คำสั่งใช้เวลานานเกิน 20 วินาที"
            }

            outThread.join(1500)
            errThread.join(1500)

            val code = process.exitValue()
            val outText = stdout.toString().trim()
            val errText = stderr.toString().trim()
            "$code||$outText||$errText"
        } catch (e: Exception) {
            "-1||||${e.message ?: "Unknown execution error"}"
        }
    }

    override fun destroy() {
        exitProcess(0)
    }
}
