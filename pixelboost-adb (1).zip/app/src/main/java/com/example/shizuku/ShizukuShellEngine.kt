package com.example.shizuku

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import com.example.BuildConfig
import com.example.model.BloatwareAdvisor
import com.example.model.DeviceTelemetry
import com.example.model.InstalledAppInfo
import com.example.model.ShellExecutionResult
import com.example.model.ShizukuConnectionState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

class ShizukuShellEngine(private val context: Context) {

    companion object {
        const val SHIZUKU_PACKAGE_NAME = "moe.shizuku.privileged.api"
        private const val REQUEST_CODE_SHIZUKU = 10042
    }

    private val _connectionState = MutableStateFlow(ShizukuConnectionState.NOT_RUNNING)
    val connectionState: StateFlow<ShizukuConnectionState> = _connectionState.asStateFlow()

    private val _statusDetail = MutableStateFlow("")
    val statusDetail: StateFlow<String> = _statusDetail.asStateFlow()

    private var shellService: IShizukuShellService? = null
    private var serviceDeferred: CompletableDeferred<IShizukuShellService?>? = null
    private val bindMutex = Mutex()
    private var isBound = false

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(
            ComponentName(BuildConfig.APPLICATION_ID, ShizukuShellService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("adb_shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val service = if (binder != null && binder.pingBinder()) {
                IShizukuShellService.Stub.asInterface(binder)
            } else {
                null
            }
            shellService = service
            isBound = service != null
            if (service != null) {
                _connectionState.value = ShizukuConnectionState.CONNECTED
                _statusDetail.value = "เชื่อมต่อ UserService (UID 2000) สำเร็จ"
            } else {
                _connectionState.value = ShizukuConnectionState.ERROR
                _statusDetail.value = "ไม่สามารถเชื่อมต่อ Shizuku UserService"
            }
            serviceDeferred?.complete(service)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shellService = null
            isBound = false
            refreshStatus()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shellService = null
        isBound = false
        refreshStatus()
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                bindServiceInternal()
            } else {
                _connectionState.value = ShizukuConnectionState.PERMISSION_REQUIRED
                _statusDetail.value = "ผู้ใช้ไม่อนุญาตสิทธิ์ Shizuku"
            }
        }
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (_: Throwable) {
        }
        refreshStatus()
    }

    fun release() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            if (isBound) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
                isBound = false
            }
        } catch (_: Throwable) {
        }
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    SHIZUKU_PACKAGE_NAME,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(SHIZUKU_PACKAGE_NAME, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        } catch (_: Throwable) {
            false
        }
    }

    fun refreshStatus() {
        val installed = isShizukuInstalled()
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }

        if (!installed && !binderAlive) {
            _connectionState.value = ShizukuConnectionState.NOT_INSTALLED
            _statusDetail.value = "ยังไม่ได้ติดตั้งแอป Shizuku บนเครื่องนี้"
            return
        }

        if (!binderAlive) {
            _connectionState.value = ShizukuConnectionState.NOT_RUNNING
            _statusDetail.value = "กรุณาเปิดแอป Shizuku และเริ่มทำงาน (Start via Wireless debugging)"
            return
        }

        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

        if (!granted) {
            _connectionState.value = ShizukuConnectionState.PERMISSION_REQUIRED
            _statusDetail.value = "Shizuku พร้อมแล้ว รอการกดอนุญาตสิทธิ์ให้แอปนี้"
            return
        }

        if (shellService != null && shellService?.asBinder()?.isBinderAlive == true) {
            _connectionState.value = ShizukuConnectionState.CONNECTED
            _statusDetail.value = "เชื่อมต่อ ADB Shell (No-Root) พร้อมใช้งาน"
        } else {
            bindServiceInternal()
        }
    }

    fun requestPermissionOrConnect() {
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }

        if (!binderAlive) {
            refreshStatus()
            return
        }

        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

        if (!granted) {
            try {
                Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
            } catch (e: Throwable) {
                _connectionState.value = ShizukuConnectionState.ERROR
                _statusDetail.value = e.message ?: "ขอสิทธิ์ Shizuku ไม่สำเร็จ"
            }
        } else {
            bindServiceInternal()
        }
    }

    private fun bindServiceInternal() {
        try {
            _connectionState.value = ShizukuConnectionState.CONNECTING
            _statusDetail.value = "กำลังเชื่อมต่อ UserService..."
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Throwable) {
            _connectionState.value = ShizukuConnectionState.ERROR
            _statusDetail.value = e.message ?: "เชื่อมต่อ UserService ไม่สำเร็จ"
        }
    }

    private suspend fun ensureService(): IShizukuShellService? = bindMutex.withLock {
        val current = shellService
        if (current != null && current.asBinder().isBinderAlive) {
            return current
        }

        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }
        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

        if (!binderAlive || !granted) {
            refreshStatus()
            return null
        }

        val deferred = CompletableDeferred<IShizukuShellService?>()
        serviceDeferred = deferred
        try {
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Throwable) {
            deferred.complete(null)
        }
        return withTimeoutOrNull(4500L) {
            deferred.await()
        }
    }

    suspend fun execute(command: String): ShellExecutionResult = withContext(Dispatchers.IO) {
        val service = ensureService()
            ?: return@withContext ShellExecutionResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = "Shizuku ยังไม่ได้เชื่อมต่อหรือไม่ได้รับอนุญาตสิทธิ์"
            )

        return@withContext try {
            val raw = service.execCommand(command)
            val parts = raw.split("||", limit = 3)
            val code = parts.getOrNull(0)?.toIntOrNull() ?: -1
            val stdout = parts.getOrNull(1).orEmpty().trim()
            val stderr = parts.getOrNull(2).orEmpty().trim()
            ShellExecutionResult(
                success = code == 0,
                exitCode = code,
                stdout = stdout,
                stderr = stderr
            )
        } catch (e: Throwable) {
            shellService = null
            refreshStatus()
            ShellExecutionResult(
                success = false,
                exitCode = -1,
                stdout = "",
                stderr = e.message ?: "เกิดข้อผิดพลาดระหว่างรันคำสั่ง"
            )
        }
    }

    suspend fun readSetting(namespace: String, key: String): String? {
        val result = execute("settings get $namespace $key")
        if (!result.success) return null
        val value = result.stdout.trim()
        return if (value.isBlank() || value == "null") null else value
    }

    suspend fun readDeviceTelemetry(): DeviceTelemetry = withContext(Dispatchers.IO) {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val totalRamGb = memInfo.totalMem / (1024f * 1024f * 1024f)
        val availRamGb = memInfo.availMem / (1024f * 1024f * 1024f)

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 0
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = displayManager.getDisplay(Display.DEFAULT_DISPLAY)
        val currentMode = display?.mode
        val currentHz = currentMode?.refreshRate?.toInt() ?: 60
        val maxHz = display?.supportedModes?.maxOfOrNull { it.refreshRate.toInt() } ?: currentHz
        val resolutionText = if (currentMode != null) {
            "${currentMode.physicalWidth} × ${currentMode.physicalHeight}"
        } else {
            "-"
        }

        var windowAnim = "-"
        var transitionAnim = "-"
        var animatorScale = "-"
        var privateDnsMode = "-"
        var privateDnsHost = "-"
        var freezer = "-"

        if (connectionState.value == ShizukuConnectionState.CONNECTED) {
            windowAnim = readSetting("global", "window_animation_scale") ?: "1.0"
            transitionAnim = readSetting("global", "transition_animation_scale") ?: "1.0"
            animatorScale = readSetting("global", "animator_duration_scale") ?: "1.0"
            privateDnsMode = readSetting("global", "private_dns_mode") ?: "opportunistic"
            privateDnsHost = readSetting("global", "private_dns_specifier") ?: "-"
            freezer = readSetting("global", "cached_apps_freezer") ?: "device_default"
        }

        DeviceTelemetry(
            deviceModel = Build.MODEL,
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            androidRelease = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            totalRamGb = totalRamGb,
            availableRamGb = availRamGb,
            batteryLevel = batteryPct,
            batteryTempC = tempTenths / 10f,
            isCharging = isCharging,
            currentRefreshRateHz = currentHz,
            maxSupportedRefreshRateHz = maxHz,
            resolutionText = resolutionText,
            windowAnimationScale = windowAnim,
            transitionAnimationScale = transitionAnim,
            animatorDurationScale = animatorScale,
            privateDnsMode = privateDnsMode,
            privateDnsHost = privateDnsHost,
            cachedAppsFreezer = freezer
        )
    }

    suspend fun loadInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(
                PackageManager.ApplicationInfoFlags.of(PackageManager.MATCH_DISABLED_COMPONENTS.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.MATCH_DISABLED_COMPONENTS)
        }

        apps.asSequence()
            .filter { it.packageName != context.packageName }
            .map { info ->
                val isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isGame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    info.category == ApplicationInfo.CATEGORY_GAME
                } else {
                    @Suppress("DEPRECATION")
                    (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                }
                val advice = BloatwareAdvisor.evaluate(info.packageName, isSystem)
                InstalledAppInfo(
                    packageName = info.packageName,
                    appName = pm.getApplicationLabel(info).toString().ifBlank { info.packageName },
                    isSystemApp = isSystem,
                    isGame = isGame,
                    isEnabled = info.enabled,
                    safetyRisk = advice.risk,
                    adviceTh = advice.reasonTh
                )
            }
            .sortedWith(
                compareBy<InstalledAppInfo> { it.safetyRisk.ordinal }
                    .thenBy { it.isSystemApp }
                    .thenBy { it.appName.lowercase() }
            )
            .toList()
    }

    fun openShizukuApp() {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE_NAME)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        }
    }

    fun openWirelessDebuggingSettings() {
        val devIntent = Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(devIntent)
        } catch (_: Throwable) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }
}
