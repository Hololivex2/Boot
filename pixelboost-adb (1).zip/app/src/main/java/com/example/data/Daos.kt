package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM tuning_profiles ORDER BY isBuiltIn DESC, createdAt ASC")
    fun getAllProfiles(): Flow<List<SavedProfileEntity>>

    @Query("SELECT COUNT(*) FROM tuning_profiles")
    suspend fun countProfiles(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: SavedProfileEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<SavedProfileEntity>)

    @Query("UPDATE tuning_profiles SET lastAppliedAt = :appliedAt WHERE id = :profileId")
    suspend fun updateLastApplied(profileId: Int, appliedAt: Long)

    @Query("DELETE FROM tuning_profiles WHERE id = :profileId AND isBuiltIn = 0")
    suspend fun deleteCustomProfile(profileId: Int)
}

@Dao
interface ExecutionLogDao {
    @Query("SELECT * FROM execution_logs ORDER BY timestamp DESC LIMIT 120")
    fun getRecentLogs(): Flow<List<ExecutionLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ExecutionLogEntity)

    @Query("DELETE FROM execution_logs")
    suspend fun clearAllLogs()
}
