package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CpuGpuPresetMode
import com.example.model.ThemeAccent
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "pixelboost_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val THEME_ACCENT = stringPreferencesKey("theme_accent")
        val CPU_GPU_MODE = stringPreferencesKey("cpu_gpu_mode")
        val CONFIRM_BEFORE_RUN = booleanPreferencesKey("confirm_before_run")
        val SHOW_COMMAND_CHIPS = booleanPreferencesKey("show_command_chips")
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.THEME_MODE] ?: ThemeMode.DARK.name
        runCatching { ThemeMode.valueOf(raw) }.getOrDefault(ThemeMode.DARK)
    }

    val themeAccent: Flow<ThemeAccent> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.THEME_ACCENT] ?: ThemeAccent.BLUE.name
        runCatching { ThemeAccent.valueOf(raw) }.getOrDefault(ThemeAccent.BLUE)
    }

    val activeCpuGpuMode: Flow<CpuGpuPresetMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.CPU_GPU_MODE] ?: CpuGpuPresetMode.BALANCED.name
        runCatching { CpuGpuPresetMode.valueOf(raw) }.getOrDefault(CpuGpuPresetMode.BALANCED)
    }

    val confirmBeforeRun: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.CONFIRM_BEFORE_RUN] ?: false
    }

    val showCommandChips: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.SHOW_COMMAND_CHIPS] ?: true
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun setThemeAccent(accent: ThemeAccent) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_ACCENT] = accent.name
        }
    }

    suspend fun setActiveCpuGpuMode(mode: CpuGpuPresetMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CPU_GPU_MODE] = mode.name
        }
    }

    suspend fun setConfirmBeforeRun(confirm: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.CONFIRM_BEFORE_RUN] = confirm
        }
    }

    suspend fun setShowCommandChips(show: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SHOW_COMMAND_CHIPS] = show
        }
    }
}
