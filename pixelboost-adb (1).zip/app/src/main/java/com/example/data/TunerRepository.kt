package com.example.data

import com.example.model.ExecutionStatus
import com.example.model.ProfileTweakPayload
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class TunerRepository(
    private val profileDao: ProfileDao,
    private val logDao: ExecutionLogDao
) {
    private val json = Json { ignoreUnknownKeys = true }

    val profiles: Flow<List<SavedProfileEntity>> = profileDao.getAllProfiles()
    val recentLogs: Flow<List<ExecutionLogEntity>> = logDao.getRecentLogs()

    suspend fun seedBuiltInProfilesIfNeeded() {
        if (profileDao.countProfiles() > 0) return
        val defaults = listOf(
            SavedProfileEntity(
                name = "โหมดเกมและตอบสนองไว",
                description = "เร่งแอนิเมชัน 0.25x, รีเฟรชสูงสุด 120Hz, ทัชไว 200ms, แช่แข็งแอปเบื้องหลัง และ Cloudflare DNS",
                iconKey = "gaming",
                isBuiltIn = true,
                settingsJson = encodeSettings(
                    mapOf(
                        "window_animation_scale" to "0.25",
                        "transition_animation_scale" to "0.25",
                        "animator_duration_scale" to "0.25",
                        "peak_refresh_rate" to "120.0",
                        "long_press_timeout" to "200",
                        "cached_apps_freezer" to "enabled",
                        "private_dns_preset" to "one.one.one.one",
                        "wifi_scan_always_enabled" to "0",
                        "ble_scan_always_enabled" to "0",
                        "low_power_mode" to "0"
                    )
                )
            ),
            SavedProfileEntity(
                name = "ลื่นไหลประจำวัน (Pixel Smooth)",
                description = "สมดุลความเร็วแอนิเมชัน 0.5x, เปิดจอ 120Hz อัตโนมัติ, Cached Freezer และ Adaptive Battery",
                iconKey = "smooth",
                isBuiltIn = true,
                settingsJson = encodeSettings(
                    mapOf(
                        "window_animation_scale" to "0.5",
                        "transition_animation_scale" to "0.5",
                        "animator_duration_scale" to "0.5",
                        "peak_refresh_rate" to "120.0",
                        "min_refresh_rate" to "auto",
                        "long_press_timeout" to "300",
                        "cached_apps_freezer" to "enabled",
                        "adaptive_battery" to "1",
                        "low_power_mode" to "0"
                    )
                )
            ),
            SavedProfileEntity(
                name = "ประหยัดแบตสูงสุด (Eco Doze)",
                description = "จำกัดจอ 60Hz, ปิดสแกน Wi-Fi/BLE เบื้องหลัง, เปิด Adaptive Battery & Battery Saver",
                iconKey = "eco",
                isBuiltIn = true,
                settingsJson = encodeSettings(
                    mapOf(
                        "window_animation_scale" to "0.5",
                        "transition_animation_scale" to "0.5",
                        "animator_duration_scale" to "0.5",
                        "peak_refresh_rate" to "60.0",
                        "min_refresh_rate" to "60.0",
                        "cached_apps_freezer" to "enabled",
                        "wifi_scan_always_enabled" to "0",
                        "ble_scan_always_enabled" to "0",
                        "adaptive_battery" to "1",
                        "low_power_mode" to "1"
                    )
                )
            )
        )
        profileDao.insertProfiles(defaults)
    }

    fun encodeSettings(settings: Map<String, String>): String {
        return json.encodeToString(ProfileTweakPayload(settings))
    }

    fun decodeSettings(settingsJson: String): Map<String, String> {
        return runCatching {
            json.decodeFromString<ProfileTweakPayload>(settingsJson).settings
        }.getOrDefault(emptyMap())
    }

    suspend fun createCustomProfile(
        name: String,
        description: String,
        iconKey: String,
        settings: Map<String, String>
    ) {
        profileDao.insertProfile(
            SavedProfileEntity(
                name = name.trim(),
                description = description.trim().ifBlank { "โปรไฟล์ปรับแต่งส่วนตัว" },
                iconKey = iconKey,
                isBuiltIn = false,
                settingsJson = encodeSettings(settings)
            )
        )
    }

    suspend fun markProfileApplied(profileId: Int) {
        profileDao.updateLastApplied(profileId, System.currentTimeMillis())
    }

    suspend fun deleteCustomProfile(profileId: Int) {
        profileDao.deleteCustomProfile(profileId)
    }

    suspend fun recordExecutionLog(
        titleTh: String,
        command: String,
        previousValue: String,
        newValue: String,
        status: ExecutionStatus,
        outputMessage: String
    ) {
        logDao.insertLog(
            ExecutionLogEntity(
                titleTh = titleTh,
                command = command,
                previousValue = previousValue,
                newValue = newValue,
                status = status.name,
                outputMessage = outputMessage
            )
        )
    }

    suspend fun clearLogs() {
        logDao.clearAllLogs()
    }
}
