package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tuning_profiles")
data class SavedProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val iconKey: String,
    val isBuiltIn: Boolean = false,
    val settingsJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastAppliedAt: Long? = null
)

@Entity(tableName = "execution_logs")
data class ExecutionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val titleTh: String,
    val command: String,
    val previousValue: String,
    val newValue: String,
    val status: String,
    val outputMessage: String,
    val timestamp: Long = System.currentTimeMillis()
)
