package com.example.ui.theme

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

val LocalReduceMotion = staticCompositionLocalOf { false }

/**
 * Material 3 Expressive Corner Radius Scale (2025+)
 */
object ExpressiveCorner {
    val None: Dp = 0.dp
    val ExtraSmall: Dp = 4.dp
    val Small: Dp = 8.dp
    val Medium: Dp = 12.dp
    val Large: Dp = 16.dp
    val LargeIncreased: Dp = 20.dp
    val ExtraLarge: Dp = 28.dp
    val ExtraLargeIncreased: Dp = 32.dp
    val ExtraExtraLarge: Dp = 48.dp
    val Full: Dp = 9999.dp
}

/**
 * Material 3 Expressive Elevation Levels (dp)
 */
object ExpressiveElevation {
    val Level0: Dp = 0.dp
    val Level1: Dp = 1.dp
    val Level2: Dp = 3.dp
    val Level3: Dp = 6.dp
    val Level4: Dp = 8.dp
    val Level5: Dp = 12.dp
}

/**
 * Material 3 Expressive State Layer Opacity Constants
 */
object ExpressiveStateAlpha {
    const val Hover: Float = 0.08f
    const val Focus: Float = 0.10f
    const val Pressed: Float = 0.10f
    const val Dragged: Float = 0.16f
    const val DisabledContent: Float = 0.38f
    const val DisabledContainer: Float = 0.12f
}

/**
 * Spring Physics Motion Tokens (EXPRESSIVE & STANDARD schemes).
 */
object ExpressiveMotion {
    // --- EXPRESSIVE SCHEME (hero interactions, shape morphs, nav pills) ---
    fun <T> spatialFast(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(120)
        else spring(dampingRatio = 0.6f, stiffness = 800f)

    fun <T> spatialDefault(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(160)
        else spring(dampingRatio = 0.8f, stiffness = 380f)

    fun <T> spatialSlow(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(200)
        else spring(dampingRatio = 0.8f, stiffness = 200f)

    fun <T> effectsFast(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(100)
        else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 3800f)

    fun <T> effectsDefault(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(140)
        else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 1600f)

    fun <T> effectsSlow(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(180)
        else spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 800f)

    // --- STANDARD SCHEME (utilitarian UI, settings, lists) ---
    fun <T> standardSpatialFast(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(100)
        else spring(dampingRatio = 0.9f, stiffness = 1400f)

    fun <T> standardSpatialDefault(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(140)
        else spring(dampingRatio = 0.9f, stiffness = 700f)

    fun <T> standardSpatialSlow(reduceMotion: Boolean = false): FiniteAnimationSpec<T> =
        if (reduceMotion) tween(180)
        else spring(dampingRatio = 0.9f, stiffness = 300f)
}

/**
 * Contrasting Expressive Geometric Shapes (Squircle, Scallop Cookie, Soft Burst Star)
 */
object ExpressiveGeometry {

    val Squircle: Shape = RoundedCornerShape(34)

    fun scallopCookie(lobes: Int = 8, amplitudeRatio: Float = 0.09f): Shape = GenericShape { size, _ ->
        buildPolarRibbonPath(
            path = this,
            width = size.width,
            height = size.height,
            lobes = lobes,
            amplitudeRatio = amplitudeRatio
        )
    }

    fun softBurst(points: Int = 10, amplitudeRatio: Float = 0.14f): Shape = GenericShape { size, _ ->
        buildPolarRibbonPath(
            path = this,
            width = size.width,
            height = size.height,
            lobes = points,
            amplitudeRatio = amplitudeRatio
        )
    }

    private fun buildPolarRibbonPath(
        path: Path,
        width: Float,
        height: Float,
        lobes: Int,
        amplitudeRatio: Float
    ) {
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = min(cx, cy) * (1f - amplitudeRatio)
        val amp = min(cx, cy) * amplitudeRatio
        val steps = lobes * 12
        for (i in 0..steps) {
            val angle = (2.0 * PI * i / steps).toFloat()
            val r = baseRadius + amp * cos(lobes * angle)
            val x = cx + r * cos(angle)
            val y = cy + r * sin(angle)
            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }
        path.close()
    }
}

/**
 * Accessible 3dp focus ring using secondary color for keyboard/D-pad navigation.
 */
fun Modifier.expressiveFocusRing(
    shape: Shape = RoundedCornerShape(50),
    ringColor: Color? = null
): Modifier = composed {
    var isFocused by remember { mutableStateOf(false) }
    val resolvedColor = ringColor ?: MaterialTheme.colorScheme.secondary
    this
        .onFocusChanged { isFocused = it.isFocused }
        .then(
            if (isFocused) {
                Modifier.border(width = 3.dp, color = resolvedColor, shape = shape)
            } else {
                Modifier
            }
        )
}
