package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.GoogleBrandColors
import com.example.ui.theme.LocalReduceMotion
import com.example.ui.theme.expressiveFocusRing
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Primary Material 3 Expressive Button that morphs from full pill (28dp)
 * to a squarer container (12dp) on press using Expressive Spatial Spring physics.
 */
@Composable
fun ExpressiveMorphingButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    content: @Composable RowScope.() -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val cornerRadius by animateDpAsState(
        targetValue = if (pressed) ExpressiveCorner.Medium else ExpressiveCorner.ExtraLarge,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "morphingBtnCorner"
    )
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && !reduceMotion) 0.97f else 1f,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "morphingBtnScale"
    )
    val shape = RoundedCornerShape(cornerRadius)

    Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = colors,
        contentPadding = contentPadding,
        interactionSource = interactionSource,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .expressiveFocusRing(shape),
        content = content
    )
}

@Composable
fun ExpressiveMorphingTonalButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.filledTonalButtonColors(),
    content: @Composable RowScope.() -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val cornerRadius by animateDpAsState(
        targetValue = if (pressed) ExpressiveCorner.Medium else ExpressiveCorner.ExtraLarge,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "morphingTonalCorner"
    )
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && !reduceMotion) 0.97f else 1f,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "morphingTonalScale"
    )
    val shape = RoundedCornerShape(cornerRadius)

    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = colors,
        interactionSource = interactionSource,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .graphicsLayer {
                scaleX = pressScale
                scaleY = pressScale
            }
            .expressiveFocusRing(shape),
        content = content
    )
}

@Composable
fun ExpressiveMorphingOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    border: BorderStroke? = ButtonDefaults.outlinedButtonBorder(enabled),
    content: @Composable RowScope.() -> Unit
) {
    val reduceMotion = LocalReduceMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val cornerRadius by animateDpAsState(
        targetValue = if (pressed) ExpressiveCorner.Medium else ExpressiveCorner.ExtraLarge,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "morphingOutlinedCorner"
    )
    val shape = RoundedCornerShape(cornerRadius)

    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        border = border,
        interactionSource = interactionSource,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .expressiveFocusRing(shape),
        content = content
    )
}

/**
 * Connected Button Group (Material 3 Expressive):
 * Outer segments have large rounded outer corners and small inner gaps (6dp);
 * the selected segment morphs smoothly into a full pill (28dp) with saturated container styling.
 */
@Composable
fun <T> ExpressiveConnectedButtonGroup(
    items: List<T>,
    selectedItem: T,
    labelProvider: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    tagPrefix: String = "connected_btn",
    tagProvider: ((T) -> String)? = null,
    leadingIcon: (@Composable (T, Boolean) -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { index, item ->
            val selected = item == selectedItem
            val interactionSource = remember(item) { MutableInteractionSource() }
            val pressed by interactionSource.collectIsPressedAsState()

            val outerCorner = 24.dp
            val innerDefault = 8.dp

            val startTop by animateDpAsState(
                targetValue = when {
                    selected -> 26.dp
                    pressed -> 12.dp
                    index == 0 -> outerCorner
                    else -> innerDefault
                },
                animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
                label = "cbgStart"
            )
            val endTop by animateDpAsState(
                targetValue = when {
                    selected -> 26.dp
                    pressed -> 12.dp
                    index == items.lastIndex -> outerCorner
                    else -> innerDefault
                },
                animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
                label = "cbgEnd"
            )
            val containerColor by animateColorAsState(
                targetValue = if (selected) cs.primary else cs.surfaceContainerHigh,
                animationSpec = ExpressiveMotion.effectsDefault(reduceMotion),
                label = "cbgBg"
            )
            val contentColor by animateColorAsState(
                targetValue = if (selected) cs.onPrimary else cs.onSurfaceVariant,
                animationSpec = ExpressiveMotion.effectsDefault(reduceMotion),
                label = "cbgFg"
            )

            val segmentShape = RoundedCornerShape(
                topStart = startTop,
                bottomStart = startTop,
                topEnd = endTop,
                bottomEnd = endTop
            )

            Surface(
                shape = segmentShape,
                color = containerColor,
                contentColor = contentColor,
                modifier = Modifier
                    .weight(if (selected) 1.15f else 1f)
                    .heightIn(min = 48.dp)
                    .clip(segmentShape)
                    .clickable(
                        interactionSource = interactionSource,
                        indication = androidx.compose.material3.ripple(),
                        onClick = { onSelect(item) }
                    )
                    .expressiveFocusRing(segmentShape)
                    .testTag(tagProvider?.invoke(item) ?: "${tagPrefix}_$index")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (leadingIcon != null) {
                        leadingIcon(item, selected)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = labelProvider(item),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * Extended FAB with shape morphing on press.
 */
@Composable
fun ExpressiveMorphingExtendedFab(
    text: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val corner by animateDpAsState(
        targetValue = if (pressed) ExpressiveCorner.Medium else ExpressiveCorner.LargeIncreased,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "fabCorner"
    )
    val shape = RoundedCornerShape(corner)

    ExtendedFloatingActionButton(
        onClick = onClick,
        icon = icon,
        text = { Text(text, fontWeight = FontWeight.SemiBold) },
        shape = shape,
        containerColor = cs.primaryContainer,
        contentColor = cs.onPrimaryContainer,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 3.dp),
        interactionSource = interactionSource,
        modifier = modifier.expressiveFocusRing(shape)
    )
}

/**
 * Expressive Loading Indicator:
 * Continuously morphing and rotating scalloped polygon/blob shape.
 * Falls back to static calm badge when Reduce Motion is enabled.
 */
@Composable
fun ExpressivePolygonLoader(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    color: Color = MaterialTheme.colorScheme.primary,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer
) {
    val reduceMotion = LocalReduceMotion.current

    val rotation: Float
    val morphFactor: Float

    if (reduceMotion) {
        rotation = 0f
        morphFactor = 0.5f
    } else {
        val transition = rememberInfiniteTransition(label = "polygonLoader")
        val rot by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 3600, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "polygonRot"
        )
        val morph by transition.animateFloat(
            initialValue = 0.06f,
            targetValue = 0.19f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1100, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "polygonMorph"
        )
        rotation = rot
        morphFactor = morph
    }

    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val minDim = min(cx, cy)

        // Outer soft container blob
        drawCircle(
            color = containerColor.copy(alpha = 0.55f),
            radius = minDim
        )

        // Inner morphing 8-lobe expressive polygon
        val lobes = 8
        val steps = 96
        val baseR = minDim * 0.68f
        val amp = minDim * morphFactor
        val radOffset = rotation * (PI.toFloat() / 180f)

        val path = Path()
        for (i in 0..steps) {
            val theta = (2.0 * PI * i / steps).toFloat()
            val r = baseR + amp * cos(lobes * theta)
            val x = cx + r * cos(theta + radOffset)
            val y = cy + r * sin(theta + radOffset)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path = path, color = color)
    }
}

/**
 * Expressive Wavy Linear Progress Bar for ongoing ADB/Shizuku batch operations.
 */
@Composable
fun ExpressiveWavyLinearProgress(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceContainerHighest
) {
    val reduceMotion = LocalReduceMotion.current
    val phase: Float = if (reduceMotion) {
        0f
    } else {
        val transition = rememberInfiniteTransition(label = "wavyProgress")
        val p by transition.animateFloat(
            initialValue = 0f,
            targetValue = (2.0 * PI).toFloat(),
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 900, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "wavyPhase"
        )
        p
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(10.dp)
    ) {
        val midY = size.height / 2f
        val amplitude = if (reduceMotion) 0f else size.height * 0.30f
        val wavelength = 36.dp.toPx()

        // Base track
        drawLine(
            color = trackColor,
            start = androidx.compose.ui.geometry.Offset(0f, midY),
            end = androidx.compose.ui.geometry.Offset(size.width, midY),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Active sinusoidal wave
        val path = Path()
        val samples = 72
        for (i in 0..samples) {
            val x = size.width * i / samples
            val angle = (x / wavelength) * (2f * PI.toFloat()) - phase
            val y = midY + amplitude * sin(angle)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(
                width = 3.5.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

/**
 * Full-Pill Material 3 Search Bar sitting on surfaceContainerHigh with 3dp secondary focus ring.
 */
@Composable
fun ExpressivePillSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    testTag: String = "expressive_search_bar"
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    var isFocused by remember { mutableStateOf(false) }

    val bgColor by animateColorAsState(
        targetValue = if (isFocused) cs.surfaceContainerHighest else cs.surfaceContainerHigh,
        animationSpec = ExpressiveMotion.effectsDefault(reduceMotion),
        label = "searchBg"
    )

    Surface(
        shape = CircleShape,
        color = bgColor,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .then(
                if (isFocused) {
                    Modifier.border(3.dp, cs.secondary, CircleShape)
                } else {
                    Modifier.border(1.dp, cs.outlineVariant.copy(alpha = 0.6f), CircleShape)
                }
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = null,
                tint = if (isFocused) cs.primary else cs.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )

            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text(
                        text = placeholder,
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = cs.onSurface),
                    cursorBrush = SolidColor(cs.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .onFocusChanged { isFocused = it.isFocused }
                        .testTag(testTag)
                )
            }

            AnimatedVisibility(
                visible = query.isNotEmpty(),
                enter = fadeIn(ExpressiveMotion.effectsFast(reduceMotion)) +
                    scaleIn(ExpressiveMotion.spatialFast(reduceMotion)),
                exit = fadeOut(ExpressiveMotion.effectsFast(reduceMotion)) +
                    scaleOut(ExpressiveMotion.spatialFast(reduceMotion))
            ) {
                IconButton(
                    onClick = { onQueryChange("") },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Clear,
                        contentDescription = "ล้างคำค้นหา",
                        tint = cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Contrasting Shape Badge (Squircle, Scallop Cookie, or Soft Burst Star)
 */
@Composable
fun ExpressiveShapeIconBadge(
    shape: Shape,
    containerColor: Color,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(containerColor),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

/**
 * Google 4-color brand dots used sparingly in the app header emblem.
 */
@Composable
fun ExpressiveBrandDots(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val dots = listOf(
            GoogleBrandColors.Blue,
            GoogleBrandColors.Red,
            GoogleBrandColors.Yellow,
            GoogleBrandColors.Green
        )
        dots.forEachIndexed { idx, color ->
            val shape = if (idx % 2 == 0) CircleShape else ExpressiveGeometry.Squircle
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(shape)
                    .background(color)
            )
        }
    }
}
