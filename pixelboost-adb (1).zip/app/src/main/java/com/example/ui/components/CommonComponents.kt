package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeveloperMode
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.SavedProfileEntity
import com.example.model.Android14TweakCatalog
import com.example.model.SafetyLevel
import com.example.model.ShizukuConnectionState
import com.example.ui.theme.AdbMonoFontFamily
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.LocalExtendedColors
import com.example.ui.theme.LocalReduceMotion

@Composable
fun ShizukuStatusCard(
    state: ShizukuConnectionState,
    detail: String,
    onPrimaryAction: () -> Unit,
    onRefresh: () -> Unit,
    onOpenGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalExtendedColors.current
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current

    val (containerBg, accentColor, statusTitle, primaryBtnText) = when (state) {
        ShizukuConnectionState.CONNECTED -> Quad(
            ext.successContainer,
            ext.success,
            "เชื่อมต่อ Shizuku พร้อมใช้งาน",
            "อัปเดตสถานะ"
        )
        ShizukuConnectionState.PERMISSION_REQUIRED -> Quad(
            cs.primaryContainer,
            cs.primary,
            "พบ Shizuku แล้ว • รอขออนุญาตสิทธิ์",
            "ขอสิทธิ์ Shizuku"
        )
        ShizukuConnectionState.CONNECTING -> Quad(
            cs.tertiaryContainer,
            cs.tertiary,
            "กำลังเชื่อมต่อบริการ Shell...",
            "กำลังเชื่อมต่อ"
        )
        ShizukuConnectionState.NOT_RUNNING -> Quad(
            ext.warningContainer,
            ext.warning,
            "ติดตั้ง Shizuku แล้ว • ยังไม่เปิดบริการ",
            "เปิดแอป Shizuku"
        )
        ShizukuConnectionState.NOT_INSTALLED -> Quad(
            cs.surfaceContainerHigh,
            cs.primary,
            "โหมดดูคำสั่ง • ยังไม่พบ Shizuku",
            "วิธีเปิดใช้ No-Root"
        )
        ShizukuConnectionState.ERROR -> Quad(
            cs.errorContainer,
            cs.error,
            "การเชื่อมต่อ Shizuku ขัดข้อง",
            "ลองเชื่อมต่อใหม่"
        )
    }

    val animatedTint by animateColorAsState(
        targetValue = containerBg,
        animationSpec = ExpressiveMotion.effectsDefault(reduceMotion),
        label = "shizukuCardTint"
    )
    val badgeShape = when (state) {
        ShizukuConnectionState.CONNECTED -> ExpressiveGeometry.softBurst(points = 10, amplitudeRatio = 0.10f)
        ShizukuConnectionState.PERMISSION_REQUIRED,
        ShizukuConnectionState.NOT_RUNNING -> ExpressiveGeometry.scallopCookie(lobes = 8, amplitudeRatio = 0.08f)
        else -> ExpressiveGeometry.Squircle
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("shizuku_status_card"),
        shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(animatedTint.copy(alpha = 0.85f), cs.surfaceContainer)
                    )
                )
                .border(
                    width = 1.dp,
                    color = accentColor.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge)
                )
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (state == ShizukuConnectionState.CONNECTING) {
                        ExpressivePolygonLoader(
                            size = 50.dp,
                            color = accentColor,
                            containerColor = containerBg
                        )
                    } else {
                        ExpressiveShapeIconBadge(
                            shape = badgeShape,
                            containerColor = accentColor.copy(alpha = 0.16f),
                            size = 50.dp
                        ) {
                            when (state) {
                                ShizukuConnectionState.CONNECTED -> Icon(
                                    Icons.Filled.CheckCircle,
                                    contentDescription = "เชื่อมต่อแล้ว",
                                    tint = accentColor,
                                    modifier = Modifier.size(26.dp)
                                )
                                ShizukuConnectionState.PERMISSION_REQUIRED -> Icon(
                                    Icons.Filled.LockOpen,
                                    contentDescription = "รอขอสิทธิ์",
                                    tint = accentColor,
                                    modifier = Modifier.size(25.dp)
                                )
                                ShizukuConnectionState.NOT_RUNNING -> Icon(
                                    Icons.Filled.WarningAmber,
                                    contentDescription = "Shizuku ยังไม่ทำงาน",
                                    tint = accentColor,
                                    modifier = Modifier.size(25.dp)
                                )
                                ShizukuConnectionState.NOT_INSTALLED -> Icon(
                                    Icons.Filled.Terminal,
                                    contentDescription = "ยังไม่ได้ติดตั้ง Shizuku",
                                    tint = accentColor,
                                    modifier = Modifier.size(25.dp)
                                )
                                ShizukuConnectionState.ERROR -> Icon(
                                    Icons.Filled.ErrorOutline,
                                    contentDescription = "เชื่อมต่อผิดพลาด",
                                    tint = accentColor,
                                    modifier = Modifier.size(25.dp)
                                )
                                ShizukuConnectionState.CONNECTING -> Unit
                            }
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Surface(
                            color = accentColor.copy(alpha = 0.16f),
                            shape = CircleShape
                        ) {
                            Text(
                                text = if (state == ShizukuConnectionState.CONNECTED) {
                                    "ADB UID 2000 • No-Root"
                                } else {
                                    "Shizuku Bridge"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = accentColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = statusTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = cs.onSurface
                        )
                        Text(
                            text = detail.ifBlank { "ตรวจสอบสถานะการเชื่อมต่อกับระบบ Shizuku" },
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_shizuku_button")
                    ) {
                        Icon(
                            Icons.Filled.Refresh,
                            contentDescription = "รีเฟรชสถานะ Shizuku",
                            tint = cs.onSurfaceVariant
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ExpressiveMorphingButton(
                        onClick = onPrimaryAction,
                        enabled = state != ShizukuConnectionState.CONNECTING,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("shizuku_primary_action_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state == ShizukuConnectionState.CONNECTED) {
                                accentColor
                            } else {
                                cs.primary
                            }
                        )
                    ) {
                        Text(
                            text = primaryBtnText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    ExpressiveMorphingOutlinedButton(
                        onClick = onOpenGuide,
                        modifier = Modifier.testTag("open_shizuku_guide_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.HelpOutline,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("คู่มือ")
                    }
                }
            }
        }
    }
}

private data class Quad<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

@Composable
fun SafetyBadge(
    level: SafetyLevel,
    modifier: Modifier = Modifier
) {
    val ext = LocalExtendedColors.current
    val cs = MaterialTheme.colorScheme
    val (bg, fg, icon) = when (level) {
        SafetyLevel.SAFE_100 -> Triple(ext.successContainer, ext.success, Icons.Filled.VerifiedUser)
        SafetyLevel.ANDROID_14_VERIFIED -> Triple(cs.tertiaryContainer, cs.onTertiaryContainer, Icons.Filled.Shield)
        SafetyLevel.CAUTION -> Triple(ext.warningContainer, ext.warning, Icons.Filled.WarningAmber)
    }

    Surface(
        modifier = modifier,
        color = bg,
        shape = CircleShape
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = level.labelTh,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                color = fg,
                maxLines = 1
            )
        }
    }
}

@Composable
fun AdbCommandBox(
    command: String,
    onCopy: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(ExpressiveCorner.Large),
        color = cs.surfaceContainerHighest,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExpressiveShapeIconBadge(
                shape = ExpressiveGeometry.Squircle,
                containerColor = cs.primaryContainer,
                size = 28.dp
            ) {
                Icon(
                    Icons.Filled.Terminal,
                    contentDescription = null,
                    tint = cs.onPrimaryContainer,
                    modifier = Modifier.size(15.dp)
                )
            }
            Text(
                text = command,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = AdbMonoFontFamily
                ),
                color = cs.onSurface,
                modifier = Modifier.weight(1f)
            )
            IconButton(
                onClick = {
                    clipboard.setText(AnnotatedString("adb shell \"$command\""))
                    onCopy("adb shell \"$command\"")
                },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("copy_adb_command_button")
            ) {
                Icon(
                    Icons.Filled.ContentCopy,
                    contentDescription = "คัดลอกคำสั่ง ADB",
                    tint = cs.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizukuSetupGuideSheet(
    onDismiss: () -> Unit,
    onOpenDeveloperSettings: () -> Unit,
    onOpenShizuku: () -> Unit,
    onCopyPcCommand: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme
    val pcStartCmd = "adb shell sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = ExpressiveCorner.ExtraLarge, topEnd = ExpressiveCorner.ExtraLarge),
        containerColor = cs.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ExpressiveShapeIconBadge(
                    shape = ExpressiveGeometry.scallopCookie(lobes = 8),
                    containerColor = cs.primaryContainer,
                    size = 46.dp
                ) {
                    Icon(
                        Icons.Filled.DeveloperMode,
                        contentDescription = null,
                        tint = cs.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column {
                    Text(
                        text = "วิธีเปิดใช้งาน Shizuku (No-Root)",
                        style = MaterialTheme.typography.titleLarge,
                        color = cs.onSurface
                    )
                    Text(
                        text = "ทำครั้งเดียวหลังเปิดเครื่อง ไม่ต้องใช้คอมพิวเตอร์ (Android 11–14+)",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            GuideStepItem(
                stepNumber = "1",
                title = "ติดตั้งและเปิดแอป Shizuku",
                desc = "ดาวน์โหลด Shizuku จาก Google Play Store หรือ GitHub จากนั้นเปิดเมนู 'Start via Wireless debugging'"
            )
            GuideStepItem(
                stepNumber = "2",
                title = "เปิดโหมดนักพัฒนา (Developer Options)",
                desc = "ไปที่ การตั้งค่า > เกี่ยวกับโทรศัพท์ > แตะ 'หมายเลขบิลด์ (Build number)' 7 ครั้ง"
            )
            GuideStepItem(
                stepNumber = "3",
                title = "จับคู่การแก้ไขจุดบกพร่องแบบไร้สาย",
                desc = "เชื่อมต่อ Wi-Fi -> เข้า 'การแก้ไขจุดบกพร่องแบบไร้สาย (Wireless debugging)' -> จับคู่ด้วยรหัส 6 หลักกับ Shizuku"
            )
            GuideStepItem(
                stepNumber = "4",
                title = "กด Start แล้วกลับมาอนุญาตสิทธิ์",
                desc = "เมื่อ Shizuku ขึ้นว่า running ให้กลับมาที่แอป PixelBoost ADB แล้วกด 'ขอสิทธิ์ Shizuku' เพื่อปรับแต่งได้ทันที"
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ExpressiveMorphingTonalButton(
                    onClick = onOpenDeveloperSettings,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("guide_open_dev_settings")
                ) {
                    Text("หน้าตั้งค่านักพัฒนา")
                }
                ExpressiveMorphingButton(
                    onClick = onOpenShizuku,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("guide_open_shizuku_app")
                ) {
                    Text("เปิดแอป Shizuku")
                }
            }

            HorizontalDivider(color = cs.outlineVariant)

            Text(
                text = "หรือเปิดใช้งาน Shizuku ผ่านสาย USB จากคอมพิวเตอร์:",
                style = MaterialTheme.typography.labelLarge,
                color = cs.onSurface
            )
            Surface(
                shape = RoundedCornerShape(ExpressiveCorner.Large),
                color = cs.surfaceContainerHigh,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(ExpressiveCorner.Large))
                    .clickable {
                        clipboard.setText(AnnotatedString(pcStartCmd))
                        onCopyPcCommand(pcStartCmd)
                    }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = pcStartCmd,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = AdbMonoFontFamily),
                        color = cs.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        Icons.Filled.ContentCopy,
                        contentDescription = "คัดลอกคำสั่งเริ่ม Shizuku",
                        tint = cs.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun GuideStepItem(
    stepNumber: String,
    title: String,
    desc: String
) {
    val cs = MaterialTheme.colorScheme
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        ExpressiveShapeIconBadge(
            shape = ExpressiveGeometry.Squircle,
            containerColor = cs.primaryContainer,
            size = 30.dp
        ) {
            Text(
                text = stepNumber,
                style = MaterialTheme.typography.labelLarge,
                color = cs.onPrimaryContainer,
                fontWeight = FontWeight.Bold
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = cs.onSurface
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfilePreviewSheet(
    profile: SavedProfileEntity,
    decodedSettings: Map<String, String>,
    scriptText: String,
    onDismiss: () -> Unit,
    onApply: () -> Unit,
    onCopyAll: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    val cs = MaterialTheme.colorScheme

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = ExpressiveCorner.ExtraLarge, topEnd = ExpressiveCorner.ExtraLarge),
        containerColor = cs.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ExpressiveShapeIconBadge(
                    shape = ExpressiveGeometry.softBurst(points = 10, amplitudeRatio = 0.1f),
                    containerColor = cs.primaryContainer,
                    size = 48.dp
                ) {
                    Icon(
                        Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = cs.onPrimaryContainer
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = cs.onSurface
                    )
                    Text(
                        text = profile.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(color = cs.outlineVariant)

            Text(
                text = "รายการที่จะปรับแต่ง (${decodedSettings.size} ค่า)",
                style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                decodedSettings.entries.forEach { (tweakId, value) ->
                    val tweak = Android14TweakCatalog.allTweaks.firstOrNull { it.id == tweakId }
                    val label = Android14TweakCatalog.getDisplayLabelForTweakValue(tweakId, value)
                    Surface(
                        shape = RoundedCornerShape(ExpressiveCorner.Large),
                        color = cs.surfaceContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = tweak?.titleTh ?: tweakId,
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = cs.tertiaryContainer,
                                shape = CircleShape
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onTertiaryContainer,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(visible = scriptText.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(ExpressiveCorner.Large),
                    color = cs.surfaceContainerHighest,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = scriptText,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = AdbMonoFontFamily),
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(scriptText))
                        onCopyAll()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("profile_sheet_copy_button")
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("คัดลอกสคริปต์")
                }

                ExpressiveMorphingButton(
                    onClick = onApply,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("profile_sheet_apply_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ปรับใช้งานทันที")
                }
            }
        }
    }
}
