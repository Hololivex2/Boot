package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.SavedProfileEntity
import com.example.model.CpuGpuPresetMode
import com.example.model.DeviceTelemetry
import com.example.model.ShizukuConnectionState
import com.example.model.ThemeAccent
import com.example.model.ThemeMode
import com.example.ui.components.AdbCommandBox
import com.example.ui.components.ExpressiveBrandDots
import com.example.ui.components.ExpressiveConnectedButtonGroup
import com.example.ui.components.ExpressiveMorphingButton
import com.example.ui.components.ExpressiveMorphingOutlinedButton
import com.example.ui.components.ExpressiveShapeIconBadge
import com.example.ui.components.ProfilePreviewSheet
import com.example.ui.components.ShizukuStatusCard
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveEmphasizedType
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.LocalReduceMotion
import com.example.ui.theme.SwatchBlue
import com.example.ui.theme.SwatchGreen
import com.example.ui.theme.SwatchPurple
import com.example.ui.theme.expressiveFocusRing
import java.util.Locale

@Composable
fun DashboardScreen(
    shizukuState: ShizukuConnectionState,
    shizukuDetail: String,
    telemetry: DeviceTelemetry,
    currentAnimationScale: String,
    safeBloatCount: Int,
    frozenAppsCount: Int,
    profiles: List<SavedProfileEntity>,
    themeMode: ThemeMode,
    themeAccent: ThemeAccent,
    activeCpuGpuMode: CpuGpuPresetMode,
    cpuGpuModeScript: String,
    decodeSettings: (String) -> Map<String, String>,
    buildProfileScript: (SavedProfileEntity) -> String,
    onPrimaryShizukuAction: () -> Unit,
    onRefreshAll: () -> Unit,
    onOpenGuide: () -> Unit,
    onCycleThemeMode: () -> Unit,
    onSelectThemeAccent: (ThemeAccent) -> Unit,
    onSelectCpuGpuMode: (CpuGpuPresetMode) -> Unit,
    onOpenCpuGpuTweaks: () -> Unit,
    onApplyUnifiedAnimation: (String) -> Unit,
    onOpenBloatwareManager: () -> Unit,
    onApplyRefreshAndFreezerBoost: () -> Unit,
    onRunCacheAndArtBoost: () -> Unit,
    onApplyProfile: (SavedProfileEntity) -> Unit,
    onCopyProfileScript: (SavedProfileEntity, String) -> Unit,
    onCopyCommand: (String, String) -> Unit,
    onRevertAll: () -> Unit,
    onNavigateToTweaks: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    var selectedProfile by remember { mutableStateOf<SavedProfileEntity?>(null) }
    var showAnimationQuickSheet by remember { mutableStateOf(false) }
    var showRevertConfirm by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "PixelBoost ADB",
                                style = ExpressiveEmphasizedType.HeadlineEmphasized,
                                color = cs.primary
                            )
                            ExpressiveBrandDots()
                        }
                        Text(
                            text = "ศูนย์ควบคุม Android 14 (No-Root) • Material 3 Expressive",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = cs.surfaceContainerHigh
                        ) {
                            IconButton(
                                onClick = onCycleThemeMode,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("dashboard_theme_toggle_button")
                            ) {
                                val icon = when (themeMode) {
                                    ThemeMode.LIGHT -> Icons.Filled.LightMode
                                    ThemeMode.DARK -> Icons.Filled.DarkMode
                                    ThemeMode.SYSTEM -> Icons.Filled.Tune
                                }
                                Icon(
                                    icon,
                                    contentDescription = "สลับโหมดมืด/สว่าง (${themeMode.labelTh})",
                                    tint = cs.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = cs.primaryContainer
                        ) {
                            IconButton(
                                onClick = onRefreshAll,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("dashboard_refresh_telemetry_button")
                            ) {
                                Icon(
                                    Icons.Filled.Refresh,
                                    contentDescription = "รีเฟรชข้อมูลเครื่อง",
                                    tint = cs.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }

            // Modern Google Theme Accent Selector (Blue / Purple / Green)
            item {
                ThemeAccentStrip(
                    selectedAccent = themeAccent,
                    onSelectAccent = onSelectThemeAccent
                )
            }

            // Shizuku Status Card (with Scallop/Burst badge & Polygon loader)
            item {
                ShizukuStatusCard(
                    state = shizukuState,
                    detail = shizukuDetail,
                    onPrimaryAction = onPrimaryShizukuAction,
                    onRefresh = onRefreshAll,
                    onOpenGuide = onOpenGuide
                )
            }

            // CPU & GPU 3-Mode Expressive Connected Switcher Card
            item {
                CpuGpuModeCard(
                    activeMode = activeCpuGpuMode,
                    modeScript = cpuGpuModeScript,
                    onSelectMode = onSelectCpuGpuMode,
                    onOpenDetailedTweaks = onOpenCpuGpuTweaks,
                    onCopyScript = {
                        onCopyCommand("โหมด CPU & GPU: ${activeCpuGpuMode.labelTh}", cpuGpuModeScript)
                    }
                )
            }

            // Quick Actions Section
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "รายการปรับแต่งด่วน (Quick Actions)",
                            style = ExpressiveEmphasizedType.TitleEmphasized,
                            color = cs.onSurface
                        )
                        TextButton(
                            onClick = onNavigateToTweaks,
                            modifier = Modifier.testTag("dashboard_goto_tweaks_button")
                        ) {
                            Text("ดูทั้งหมด", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val isWide = maxWidth >= 600.dp
                        val animBadge = if (currentAnimationScale == "0.0") "0x" else "${currentAnimationScale}x"
                        val bloatBadge = when {
                            frozenAppsCount > 0 -> "แช่แข็งอยู่ $frozenAppsCount"
                            safeBloatCount > 0 -> "พบ $safeBloatCount ปิดได้"
                            else -> "พร้อมจัดการ"
                        }

                        if (isWide) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                QuickActionCard(
                                    icon = Icons.Filled.Animation,
                                    title = "ปรับความเร็ว Animation",
                                    subtitle = "เร่งจอ/สลับหน้า 3 แกนพร้อมกัน",
                                    badgeText = "ปัจจุบัน $animBadge",
                                    highlighted = true,
                                    onClick = { showAnimationQuickSheet = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("quick_action_animation")
                                )
                                QuickActionCard(
                                    icon = Icons.Filled.DeleteSweep,
                                    title = "จัดการ Bloatware",
                                    subtitle = "แช่แข็ง/ปลดล็อกแอปติดเครื่อง",
                                    badgeText = bloatBadge,
                                    highlighted = false,
                                    onClick = onOpenBloatwareManager,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("quick_action_bloatware")
                                )
                                QuickActionCard(
                                    icon = Icons.Filled.RocketLaunch,
                                    title = "เร่งจอ 120Hz & Freezer",
                                    subtitle = "ปลดล็อก Hz + แช่แข็งแอปพัก",
                                    badgeText = "1-Tap Boost",
                                    highlighted = false,
                                    onClick = onApplyRefreshAndFreezerBoost,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("quick_action_refresh_freezer")
                                )
                                QuickActionCard(
                                    icon = Icons.Filled.CleaningServices,
                                    title = "ล้างแคช & คอมไพล์ ART",
                                    subtitle = "เคลียร์แคช 4GB + เร่งเปิดแอป",
                                    badgeText = "Android 14",
                                    highlighted = false,
                                    onClick = onRunCacheAndArtBoost,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("quick_action_cache_art")
                                )
                            }
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    QuickActionCard(
                                        icon = Icons.Filled.Animation,
                                        title = "ปรับความเร็ว Animation",
                                        subtitle = "เร่งสลับหน้าและ UI ไวขึ้น",
                                        badgeText = "ปัจจุบัน $animBadge",
                                        highlighted = true,
                                        onClick = { showAnimationQuickSheet = true },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("quick_action_animation")
                                    )
                                    QuickActionCard(
                                        icon = Icons.Filled.DeleteSweep,
                                        title = "จัดการ Bloatware",
                                        subtitle = "แช่แข็งแอปที่ไม่ใช้งาน",
                                        badgeText = bloatBadge,
                                        highlighted = false,
                                        onClick = onOpenBloatwareManager,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("quick_action_bloatware")
                                    )
                                }
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    QuickActionCard(
                                        icon = Icons.Filled.RocketLaunch,
                                        title = "เร่งจอ 120Hz & Freezer",
                                        subtitle = "ลื่น + ลดแอปกินเบื้องหลัง",
                                        badgeText = "1-Tap Boost",
                                        highlighted = false,
                                        onClick = onApplyRefreshAndFreezerBoost,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("quick_action_refresh_freezer")
                                    )
                                    QuickActionCard(
                                        icon = Icons.Filled.CleaningServices,
                                        title = "ล้างแคช & คอมไพล์ ART",
                                        subtitle = "เคลียร์แคช + เปิดแอปไว",
                                        badgeText = "Android 14",
                                        highlighted = false,
                                        onClick = onRunCacheAndArtBoost,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("quick_action_cache_art")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Real-Time System Telemetry Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "ข้อมูลระบบแบบเรียลไทม์",
                        style = ExpressiveEmphasizedType.TitleEmphasized,
                        color = cs.onSurface
                    )

                    val ramText = String.format(
                        Locale.US,
                        "%.1f / %.1f GB",
                        telemetry.availableRamGb,
                        telemetry.totalRamGb
                    )
                    val batteryText = "${telemetry.batteryLevel}% • ${
                        String.format(Locale.US, "%.1f", telemetry.batteryTempC)
                    }°C"
                    val displayText = "${telemetry.currentRefreshRateHz} Hz"
                    val animText = if (telemetry.windowAnimationScale == "-") {
                        "รอเชื่อมต่อ Shizuku"
                    } else {
                        "แอนิเมชัน ${telemetry.windowAnimationScale}x"
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TelemetryTile(
                                icon = Icons.Filled.PhoneAndroid,
                                label = "อุปกรณ์ & OS",
                                value = telemetry.deviceModel.ifBlank { "Android" },
                                subValue = "Android ${telemetry.androidRelease} (API ${telemetry.sdkInt})",
                                modifier = Modifier.weight(1f)
                            )
                            TelemetryTile(
                                icon = Icons.Filled.Memory,
                                label = "RAM ว่าง / ทั้งหมด",
                                value = ramText,
                                subValue = "Freezer: ${telemetry.cachedAppsFreezer}",
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TelemetryTile(
                                icon = Icons.Filled.BatteryChargingFull,
                                label = "แบตเตอรี่",
                                value = batteryText,
                                subValue = if (telemetry.isCharging) "กำลังชาร์จไฟ" else "ใช้งานแบตเตอรี่",
                                modifier = Modifier.weight(1f)
                            )
                            TelemetryTile(
                                icon = Icons.Filled.Speed,
                                label = "รีเฟรชหน้าจอ",
                                value = displayText,
                                subValue = "สูงสุด ${telemetry.maxSupportedRefreshRateHz} Hz • $animText",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // One-Tap Profiles Section
            item {
                Text(
                    text = "โปรไฟล์ปรับแต่งสำเร็จรูป (One-Tap)",
                    style = ExpressiveEmphasizedType.TitleEmphasized,
                    color = cs.onSurface
                )
            }

            items(profiles, key = { it.id }) { profile ->
                ProfileQuickCard(
                    profile = profile,
                    tweakCount = decodeSettings(profile.settingsJson).size,
                    onClick = { selectedProfile = profile }
                )
            }

            item {
                ExpressiveMorphingOutlinedButton(
                    onClick = { showRevertConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("quick_revert_all_button")
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("คืนค่าเริ่มต้นปลอดภัยทั้งหมด (Factory Defaults)")
                }
            }
        }
    }

    if (showAnimationQuickSheet) {
        AnimationQuickActionSheet(
            currentScale = currentAnimationScale,
            onDismiss = { showAnimationQuickSheet = false },
            onSelectScale = { scale ->
                onApplyUnifiedAnimation(scale)
                showAnimationQuickSheet = false
            },
            onCopyCommand = { cmd ->
                onCopyCommand("ปรับ Animation ทั้ง 3 แกน", cmd)
            }
        )
    }

    selectedProfile?.let { profile ->
        val decoded = decodeSettings(profile.settingsJson)
        val script = buildProfileScript(profile)
        ProfilePreviewSheet(
            profile = profile,
            decodedSettings = decoded,
            scriptText = script,
            onDismiss = { selectedProfile = null },
            onApply = {
                onApplyProfile(profile)
                selectedProfile = null
            },
            onCopyAll = {
                onCopyProfileScript(profile, script)
            }
        )
    }

    if (showRevertConfirm) {
        AlertDialog(
            onDismissRequest = { showRevertConfirm = false },
            shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
            containerColor = cs.surfaceContainerHigh,
            title = { Text("คืนค่าเริ่มต้นทั้งหมด?") },
            text = {
                Text("ระบบจะคืนค่าแอนิเมชัน 1.0x, รีเฟรชหน้าจออัตโนมัติ, Private DNS, และปลดล็อก Deep Doze กลับเป็นค่ามาตรฐานโรงงาน")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showRevertConfirm = false
                        onRevertAll()
                    },
                    modifier = Modifier.testTag("confirm_revert_all_button")
                ) {
                    Text("คืนค่าทันที")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRevertConfirm = false }) {
                    Text("ยกเลิก")
                }
            }
        )
    }
}

@Composable
private fun CpuGpuModeCard(
    activeMode: CpuGpuPresetMode,
    modeScript: String,
    onSelectMode: (CpuGpuPresetMode) -> Unit,
    onOpenDetailedTweaks: () -> Unit,
    onCopyScript: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    val (modeIcon, badgeShape, badgeBg, badgeFg) = when (activeMode) {
        CpuGpuPresetMode.SHARP_VISUALS -> QuadTuple(
            Icons.Filled.HighQuality,
            ExpressiveGeometry.scallopCookie(lobes = 8, amplitudeRatio = 0.08f),
            cs.tertiaryContainer,
            cs.onTertiaryContainer
        )
        CpuGpuPresetMode.SMOOTH_FPS -> QuadTuple(
            Icons.Filled.Speed,
            ExpressiveGeometry.softBurst(points = 10, amplitudeRatio = 0.11f),
            cs.primaryContainer,
            cs.onPrimaryContainer
        )
        CpuGpuPresetMode.BALANCED -> QuadTuple(
            Icons.Filled.GraphicEq,
            ExpressiveGeometry.Squircle,
            cs.secondaryContainer,
            cs.onSecondaryContainer
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dashboard_cpu_gpu_card"),
        shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(cs.surfaceContainer, cs.surfaceContainerLow)
                    )
                )
                .border(1.dp, cs.outlineVariant.copy(alpha = 0.7f), RoundedCornerShape(ExpressiveCorner.ExtraLarge))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    ExpressiveShapeIconBadge(
                        shape = badgeShape,
                        containerColor = badgeBg,
                        size = 46.dp
                    ) {
                        Icon(
                            imageVector = modeIcon,
                            contentDescription = null,
                            tint = badgeFg,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "โหมด CPU & GPU อัจฉริยะ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = cs.onSurface
                        )
                        Text(
                            text = "สลับโปรไฟล์การเรนเดอร์และพลังงาน 3 สไตล์",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = cs.surfaceContainerHigh
                ) {
                    IconButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(modeScript))
                            onCopyScript()
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("copy_cpu_gpu_mode_script")
                    ) {
                        Icon(
                            Icons.Filled.ContentCopy,
                            contentDescription = "คัดลอกคำสั่งโหมด CPU/GPU",
                            tint = cs.primary
                        )
                    }
                }
            }

            ExpressiveConnectedButtonGroup(
                items = CpuGpuPresetMode.entries,
                selectedItem = activeMode,
                labelProvider = { it.labelTh },
                onSelect = onSelectMode,
                tagProvider = { "cpu_gpu_mode_${it.name}" }
            )

            Surface(
                shape = RoundedCornerShape(ExpressiveCorner.Large),
                color = cs.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = activeMode.subtitleTh,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = onOpenDetailedTweaks,
                        modifier = Modifier.testTag("open_cpu_gpu_tweaks_button")
                    ) {
                        Text("ปรับละเอียด", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

private data class QuadTuple<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

@Composable
private fun ThemeAccentStrip(
    selectedAccent: ThemeAccent,
    onSelectAccent: (ThemeAccent) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    Surface(
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        color = cs.surfaceContainerLow,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(ExpressiveCorner.LargeIncreased))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Palette,
                    contentDescription = null,
                    tint = cs.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "สีธีม Material 3",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.onSurface
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeAccent.entries.forEach { accent ->
                    val swatchColor = when (accent) {
                        ThemeAccent.BLUE -> SwatchBlue
                        ThemeAccent.PURPLE -> SwatchPurple
                        ThemeAccent.GREEN -> SwatchGreen
                    }
                    val isSelected = selectedAccent == accent
                    val pillBg by animateColorAsState(
                        targetValue = if (isSelected) cs.primaryContainer else cs.surfaceContainerHigh,
                        animationSpec = ExpressiveMotion.effectsDefault(reduceMotion),
                        label = "accentPillBg"
                    )
                    val cornerRadius by animateDpAsState(
                        targetValue = if (isSelected) ExpressiveCorner.ExtraLarge else ExpressiveCorner.Large,
                        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
                        label = "accentCorner"
                    )
                    val pillShape = RoundedCornerShape(cornerRadius)
                    Surface(
                        shape = pillShape,
                        color = pillBg,
                        modifier = Modifier
                            .clip(pillShape)
                            .border(
                                width = if (isSelected) 1.5.dp else 0.5.dp,
                                color = if (isSelected) cs.primary else cs.outlineVariant,
                                shape = pillShape
                            )
                            .clickable { onSelectAccent(accent) }
                            .expressiveFocusRing(pillShape)
                            .testTag("theme_accent_${accent.name}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(if (isSelected) ExpressiveGeometry.Squircle else CircleShape)
                                    .background(swatchColor),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                            Text(
                                text = accent.labelTh,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) cs.onPrimaryContainer else cs.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badgeText: String,
    highlighted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val corner by animateDpAsState(
        targetValue = if (pressed) ExpressiveCorner.Medium else ExpressiveCorner.LargeIncreased,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "quickCardCorner"
    )
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduceMotion) 0.97f else 1f,
        animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
        label = "quickCardScale"
    )
    val shape = RoundedCornerShape(corner)

    Card(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            )
            .expressiveFocusRing(shape)
            .border(
                width = 1.dp,
                color = if (highlighted) cs.primary.copy(alpha = 0.45f) else cs.outlineVariant.copy(alpha = 0.6f),
                shape = shape
            ),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (highlighted) cs.surfaceContainerHigh else cs.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (highlighted) 2.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ExpressiveShapeIconBadge(
                    shape = if (highlighted) ExpressiveGeometry.scallopCookie(lobes = 8) else ExpressiveGeometry.Squircle,
                    containerColor = if (highlighted) cs.primaryContainer else cs.secondaryContainer,
                    size = 40.dp
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (highlighted) cs.onPrimaryContainer else cs.onSecondaryContainer,
                        modifier = Modifier.size(21.dp)
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = if (highlighted) cs.tertiaryContainer else cs.surfaceContainerHighest
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (highlighted) cs.onTertiaryContainer else cs.onSurfaceVariant,
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AnimationQuickActionSheet(
    currentScale: String,
    onDismiss: () -> Unit,
    onSelectScale: (String) -> Unit,
    onCopyCommand: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cs = MaterialTheme.colorScheme
    var pickedScale by remember { mutableStateOf(currentScale) }

    val scaleCmd = if (pickedScale == "0.0") "0" else pickedScale
    val previewCommand =
        "settings put global window_animation_scale $scaleCmd && " +
            "settings put global transition_animation_scale $scaleCmd && " +
            "settings put global animator_duration_scale $scaleCmd"

    val presets = listOf(
        "0.0" to "0x (ปิดแอนิเมชัน • เร็วสุด)",
        "0.25" to "0.25x (ลื่นมาก แนะนำสายเกม)",
        "0.5" to "0.5x (ลื่นสมดุล ยอดนิยม)",
        "1.0" to "1.0x (ค่าเริ่มต้นโรงงาน)"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = ExpressiveCorner.ExtraLarge, topEnd = ExpressiveCorner.ExtraLarge),
        containerColor = cs.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ExpressiveShapeIconBadge(
                    shape = ExpressiveGeometry.Squircle,
                    containerColor = cs.primaryContainer,
                    size = 44.dp
                ) {
                    Icon(Icons.Filled.Animation, contentDescription = null, tint = cs.onPrimaryContainer)
                }
                Column {
                    Text(
                        text = "ปรับความเร็ว Animation ทั้งระบบ",
                        style = MaterialTheme.typography.titleLarge,
                        color = cs.onSurface
                    )
                    Text(
                        text = "ปรับพร้อมกันทั้ง Window, Transition และ Animator Scale",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(color = cs.outlineVariant)

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { (value, label) ->
                    val selected = pickedScale == value
                    FilterChip(
                        selected = selected,
                        onClick = { pickedScale = value },
                        shape = if (selected) CircleShape else RoundedCornerShape(ExpressiveCorner.Large),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primaryContainer,
                            selectedLabelColor = cs.onPrimaryContainer
                        ),
                        label = { Text(label) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("anim_sheet_option_$value")
                    )
                }
            }

            AdbCommandBox(
                command = previewCommand,
                onCopy = onCopyCommand
            )

            ExpressiveMorphingButton(
                onClick = { onSelectScale(pickedScale) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("anim_sheet_apply_button")
            ) {
                Text("ปรับใช้งานความเร็ว ${if (pickedScale == "0.0") "0" else pickedScale}x ทันที")
            }
        }
    }
}

@Composable
private fun TelemetryTile(
    icon: ImageVector,
    label: String,
    value: String,
    subValue: String,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = cs.tertiary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = value,
                style = ExpressiveEmphasizedType.TitleEmphasized,
                color = cs.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subValue,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ProfileQuickCard(
    profile: SavedProfileEntity,
    tweakCount: Int,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val (icon, shape) = when (profile.iconKey) {
        "gaming" -> Icons.Filled.SportsEsports to ExpressiveGeometry.softBurst(points = 10, amplitudeRatio = 0.1f)
        "eco" -> Icons.Filled.Eco to ExpressiveGeometry.scallopCookie(lobes = 8)
        else -> Icons.Filled.Bolt to ExpressiveGeometry.Squircle
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(ExpressiveCorner.LargeIncreased))
            .clickable(onClick = onClick)
            .expressiveFocusRing(RoundedCornerShape(ExpressiveCorner.LargeIncreased))
            .testTag("dashboard_profile_card_${profile.id}"),
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ExpressiveShapeIconBadge(
                shape = shape,
                containerColor = cs.primaryContainer,
                size = 46.dp
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = cs.onPrimaryContainer,
                    modifier = Modifier.size(23.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = profile.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = cs.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Surface(
                        color = cs.tertiaryContainer,
                        shape = CircleShape
                    ) {
                        Text(
                            text = "$tweakCount ค่า",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = cs.onTertiaryContainer,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = profile.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
