package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ExecutionLogEntity
import com.example.data.PreferencesManager
import com.example.data.SavedProfileEntity
import com.example.data.TunerRepository
import com.example.model.Android14TweakCatalog
import com.example.model.AppFilter
import com.example.model.CpuGpuPresetMode
import com.example.model.DeviceTelemetry
import com.example.model.ExecutionStatus
import com.example.model.InstalledAppInfo
import com.example.model.ShizukuConnectionState
import com.example.model.ThemeAccent
import com.example.model.ThemeMode
import com.example.model.TweakCategory
import com.example.model.TweakDefinition
import com.example.shizuku.ShizukuShellEngine
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TunerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    val repository = TunerRepository(database.profileDao(), database.executionLogDao())
    private val prefsManager = PreferencesManager(application)
    private val shizukuEngine = ShizukuShellEngine(application)

    val shizukuState: StateFlow<ShizukuConnectionState> = shizukuEngine.connectionState
    val shizukuDetail: StateFlow<String> = shizukuEngine.statusDetail

    val profiles: StateFlow<List<SavedProfileEntity>> = repository.profiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentLogs: StateFlow<List<ExecutionLogEntity>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val themeMode: StateFlow<ThemeMode> = prefsManager.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.DARK)

    val themeAccent: StateFlow<ThemeAccent> = prefsManager.themeAccent
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeAccent.BLUE)

    val activeCpuGpuMode: StateFlow<CpuGpuPresetMode> = prefsManager.activeCpuGpuMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CpuGpuPresetMode.BALANCED)

    val confirmBeforeRun: StateFlow<Boolean> = prefsManager.confirmBeforeRun
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val showCommandChips: StateFlow<Boolean> = prefsManager.showCommandChips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    private val _appFilter = MutableStateFlow(AppFilter.USER)
    val appFilter: StateFlow<AppFilter> = _appFilter.asStateFlow()

    private val _telemetry = MutableStateFlow(DeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private val _tweakValues = MutableStateFlow<Map<String, String>>(
        Android14TweakCatalog.allTweaks.associate { it.id to it.defaultValue }
    )
    val tweakValues: StateFlow<Map<String, String>> = _tweakValues.asStateFlow()

    private val _selectedCategory = MutableStateFlow(TweakCategory.ALL)
    val selectedCategory: StateFlow<TweakCategory> = _selectedCategory.asStateFlow()

    private val _tweakSearchQuery = MutableStateFlow("")
    val tweakSearchQuery: StateFlow<String> = _tweakSearchQuery.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _executionMessage = MutableStateFlow("")
    val executionMessage: StateFlow<String> = _executionMessage.asStateFlow()

    private val _snackbarEvents = MutableSharedFlow<String>(extraBufferCapacity = 10)
    val snackbarEvents: SharedFlow<String> = _snackbarEvents.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.seedBuiltInProfilesIfNeeded()
        }
        viewModelScope.launch {
            shizukuState.collect { state ->
                refreshTelemetryAndLiveTweaks()
                if (state == ShizukuConnectionState.CONNECTED && _installedApps.value.isEmpty()) {
                    loadInstalledApps()
                }
            }
        }
        loadInstalledApps()
    }

    override fun onCleared() {
        super.onCleared()
        shizukuEngine.release()
    }

    fun refreshConnectionAndTelemetry() {
        shizukuEngine.refreshStatus()
        refreshTelemetryAndLiveTweaks()
    }

    fun requestShizukuPermissionOrConnect() {
        shizukuEngine.requestPermissionOrConnect()
    }

    fun openShizukuApp() {
        shizukuEngine.openShizukuApp()
    }

    fun openWirelessDebuggingSettings() {
        shizukuEngine.openWirelessDebuggingSettings()
    }

    fun setSelectedCategory(category: TweakCategory) {
        _selectedCategory.value = category
    }

    fun setTweakSearchQuery(query: String) {
        _tweakSearchQuery.value = query
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefsManager.setThemeMode(mode) }
    }

    fun setThemeAccent(accent: ThemeAccent) {
        viewModelScope.launch { prefsManager.setThemeAccent(accent) }
    }

    fun setAppFilter(filter: AppFilter) {
        _appFilter.value = filter
    }

    fun setConfirmBeforeRun(confirm: Boolean) {
        viewModelScope.launch { prefsManager.setConfirmBeforeRun(confirm) }
    }

    fun setShowCommandChips(show: Boolean) {
        viewModelScope.launch { prefsManager.setShowCommandChips(show) }
    }

    fun refreshTelemetryAndLiveTweaks() {
        viewModelScope.launch {
            val info = shizukuEngine.readDeviceTelemetry()
            _telemetry.value = info

            if (shizukuState.value == ShizukuConnectionState.CONNECTED) {
                val updatedMap = _tweakValues.value.toMutableMap()
                for (tweak in Android14TweakCatalog.allTweaks) {
                    val ns = tweak.settingNamespace ?: continue
                    val key = tweak.settingKey ?: continue
                    val liveValue = shizukuEngine.readSetting(ns, key)
                    if (liveValue != null) {
                        updatedMap[tweak.id] = normalizeValue(tweak.id, liveValue)
                    } else if (tweak.id == "peak_refresh_rate" || tweak.id == "min_refresh_rate") {
                        updatedMap[tweak.id] = "auto"
                    }
                }
                _tweakValues.value = updatedMap
            }
        }
    }

    private fun normalizeValue(tweakId: String, raw: String): String {
        return when (tweakId) {
            "window_animation_scale", "transition_animation_scale", "animator_duration_scale" -> {
                val f = raw.toFloatOrNull() ?: return raw
                when {
                    f == 0f -> "0.0"
                    f <= 0.3f -> "0.25"
                    f <= 0.6f -> "0.5"
                    else -> "1.0"
                }
            }
            "peak_refresh_rate", "min_refresh_rate" -> {
                val f = raw.toFloatOrNull() ?: return "auto"
                when {
                    f >= 115f -> "120.0"
                    f >= 85f -> "90.0"
                    f > 0f -> "60.0"
                    else -> "auto"
                }
            }
            else -> raw
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            _installedApps.value = shizukuEngine.loadInstalledApps()
            _isLoadingApps.value = false
        }
    }

    fun applyTweak(tweak: TweakDefinition, newValue: String, command: String) {
        viewModelScope.launch {
            val prevValue = _tweakValues.value[tweak.id] ?: tweak.defaultValue
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกคำสั่ง ADB หรือเชื่อมต่อ Shizuku ก่อน")
                return@launch
            }

            _isExecuting.value = true
            _executionMessage.value = "กำลังปรับใช้: ${tweak.titleTh}"

            val result = shizukuEngine.execute(command)
            if (result.success) {
                if (newValue != "action") {
                    _tweakValues.value = _tweakValues.value.toMutableMap().apply {
                        put(tweak.id, newValue)
                    }
                }
                repository.recordExecutionLog(
                    titleTh = tweak.titleTh,
                    command = command,
                    previousValue = prevValue,
                    newValue = newValue,
                    status = ExecutionStatus.SUCCESS,
                    outputMessage = result.stdout.ifBlank { "ปรับแต่งสำเร็จ" }
                )
                _snackbarEvents.tryEmit("ปรับใช้ \"${tweak.titleTh}\" สำเร็จ")
                refreshTelemetryAndLiveTweaks()
            } else {
                repository.recordExecutionLog(
                    titleTh = tweak.titleTh,
                    command = command,
                    previousValue = prevValue,
                    newValue = newValue,
                    status = ExecutionStatus.FAILED,
                    outputMessage = result.stderr.ifBlank { "Exit ${result.exitCode}" }
                )
                _snackbarEvents.tryEmit("ไม่สำเร็จ: ${result.stderr.ifBlank { "รหัส ${result.exitCode}" }}")
            }

            _isExecuting.value = false
            _executionMessage.value = ""
        }
    }

    fun revertTweak(tweak: TweakDefinition) {
        val cmd = tweak.revertCommand ?: return
        applyTweak(tweak, tweak.defaultValue, cmd)
    }

    fun applyProfile(profile: SavedProfileEntity) {
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("กรุณาเชื่อมต่อ Shizuku ก่อนใช้งานโปรไฟล์ หรือกดคัดลอกคำสั่ง")
                return@launch
            }
            val settings = repository.decodeSettings(profile.settingsJson)
            if (settings.isEmpty()) return@launch

            _isExecuting.value = true
            var successCount = 0
            var failCount = 0

            settings.forEach { (tweakId, targetValue) ->
                val tweak = Android14TweakCatalog.allTweaks.firstOrNull { it.id == tweakId }
                val cmd = Android14TweakCatalog.buildCommandForTweakValue(tweakId, targetValue)
                if (tweak != null && cmd != null) {
                    _executionMessage.value = "กำลังใช้โปรไฟล์ ${profile.name}: ${tweak.titleTh}"
                    val res = shizukuEngine.execute(cmd)
                    if (res.success) {
                        successCount++
                        _tweakValues.value = _tweakValues.value.toMutableMap().apply {
                            put(tweakId, targetValue)
                        }
                    } else {
                        failCount++
                    }
                }
            }

            repository.markProfileApplied(profile.id)
            val allCmds = buildProfileScript(profile)
            repository.recordExecutionLog(
                titleTh = "ใช้โปรไฟล์: ${profile.name}",
                command = allCmds,
                previousValue = "ชุดเดิม",
                newValue = "สำเร็จ $successCount รายการ" + if (failCount > 0) " (พลาด $failCount)" else "",
                status = if (failCount == 0) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = "รันคำสั่งในโปรไฟล์ครบแล้ว ($successCount/${settings.size})"
            )

            _isExecuting.value = false
            _executionMessage.value = ""
            refreshTelemetryAndLiveTweaks()
            _snackbarEvents.tryEmit("เปิดใช้โปรไฟล์ \"${profile.name}\" สำเร็จ ($successCount/${settings.size})")
        }
    }

    fun revertAllToDefault() {
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("กรุณาเชื่อมต่อ Shizuku ก่อนคืนค่าเริ่มต้น")
                return@launch
            }
            _isExecuting.value = true
            var ok = 0
            Android14TweakCatalog.safeRevertAllCommands.forEach { (label, cmd) ->
                _executionMessage.value = label
                if (shizukuEngine.execute(cmd).success) ok++
            }
            repository.recordExecutionLog(
                titleTh = "คืนค่าเริ่มต้นปลอดภัยทั้งหมด",
                command = Android14TweakCatalog.safeRevertAllCommands.joinToString("\n") { it.second },
                previousValue = "ค่าที่ปรับแต่ง",
                newValue = "ค่าเริ่มต้นโรงงาน",
                status = ExecutionStatus.SUCCESS,
                outputMessage = "คืนค่าสำเร็จ $ok/${Android14TweakCatalog.safeRevertAllCommands.size} รายการ"
            )
            _isExecuting.value = false
            _executionMessage.value = ""
            refreshTelemetryAndLiveTweaks()
            _snackbarEvents.tryEmit("คืนค่าเริ่มต้นโรงงานเรียบร้อยแล้ว")
        }
    }

    fun runDirectCommand(titleTh: String, command: String) {
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกคำสั่งไปรันผ่าน ADB ได้")
                return@launch
            }
            _isExecuting.value = true
            _executionMessage.value = titleTh
            val res = shizukuEngine.execute(command)
            repository.recordExecutionLog(
                titleTh = titleTh,
                command = command,
                previousValue = "-",
                newValue = if (res.success) "ดำเนินการแล้ว" else "ผิดพลาด",
                status = if (res.success) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = res.stdout.ifBlank { res.stderr }.ifBlank { "รหัสสถานะ ${res.exitCode}" }
            )
            _isExecuting.value = false
            _executionMessage.value = ""
            _snackbarEvents.tryEmit(if (res.success) "$titleTh สำเร็จ" else "ผิดพลาด: ${res.stderr}")
        }
    }

    fun applyUnifiedAnimationScale(scale: String) {
        viewModelScope.launch {
            val scaleCmdValue = if (scale == "0.0") "0" else scale
            val combinedCmd =
                "settings put global window_animation_scale $scaleCmdValue && " +
                    "settings put global transition_animation_scale $scaleCmdValue && " +
                    "settings put global animator_duration_scale $scaleCmdValue"
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกคำสั่ง ADB ได้")
                return@launch
            }
            _isExecuting.value = true
            _executionMessage.value = "กำลังปรับความเร็วแอนิเมชันทั้ง 3 แกนเป็น ${scale}x"
            val res = shizukuEngine.execute(combinedCmd)
            if (res.success) {
                _tweakValues.value = _tweakValues.value.toMutableMap().apply {
                    put("window_animation_scale", scale)
                    put("transition_animation_scale", scale)
                    put("animator_duration_scale", scale)
                }
                repository.recordExecutionLog(
                    titleTh = "ปรับแอนิเมชันทั้งหมดเป็น ${scale}x",
                    command = combinedCmd,
                    previousValue = "-",
                    newValue = "${scale}x",
                    status = ExecutionStatus.SUCCESS,
                    outputMessage = "ปรับความเร็วหน้าต่าง เปลี่ยนหน้า และตัวเคลื่อนไหวสำเร็จ"
                )
                refreshTelemetryAndLiveTweaks()
                _snackbarEvents.tryEmit("ปรับความเร็ว Animation เป็น ${scale}x สำเร็จ")
            } else {
                repository.recordExecutionLog(
                    titleTh = "ปรับแอนิเมชันทั้งหมดเป็น ${scale}x",
                    command = combinedCmd,
                    previousValue = "-",
                    newValue = "${scale}x",
                    status = ExecutionStatus.FAILED,
                    outputMessage = res.stderr.ifBlank { "Exit ${res.exitCode}" }
                )
                _snackbarEvents.tryEmit("ไม่สำเร็จ: ${res.stderr}")
            }
            _isExecuting.value = false
            _executionMessage.value = ""
        }
    }

    fun applyBoostRefreshAndFreezer() {
        viewModelScope.launch {
            val cmd = "settings put system peak_refresh_rate 120.0 && settings put global cached_apps_freezer enabled"
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กรุณาเชื่อมต่อก่อนเปิดใช้งาน")
                return@launch
            }
            _isExecuting.value = true
            _executionMessage.value = "กำลังเปิด 120Hz Peak และ Cached Apps Freezer"
            val res = shizukuEngine.execute(cmd)
            if (res.success) {
                _tweakValues.value = _tweakValues.value.toMutableMap().apply {
                    put("peak_refresh_rate", "120.0")
                    put("cached_apps_freezer", "enabled")
                }
                repository.recordExecutionLog(
                    titleTh = "เร่งจอ 120Hz + แช่แข็งแอปเบื้องหลัง",
                    command = cmd,
                    previousValue = "-",
                    newValue = "120Hz + Freezer",
                    status = ExecutionStatus.SUCCESS,
                    outputMessage = "ปรับใช้งานสำเร็จ"
                )
                refreshTelemetryAndLiveTweaks()
                _snackbarEvents.tryEmit("เปิดโหมดจอลื่น 120Hz & Cached Freezer สำเร็จ")
            } else {
                _snackbarEvents.tryEmit("ไม่สำเร็จ: ${res.stderr}")
            }
            _isExecuting.value = false
            _executionMessage.value = ""
        }
    }

    fun buildCpuGpuPresetScript(mode: CpuGpuPresetMode): String {
        return Android14TweakCatalog.commandsForCpuGpuPreset(mode)
            .joinToString("\n") { (_, _, cmd) -> "adb shell \"$cmd\"" }
    }

    fun applyCpuGpuPresetMode(mode: CpuGpuPresetMode) {
        viewModelScope.launch {
            prefsManager.setActiveCpuGpuMode(mode)
            val commands = Android14TweakCatalog.commandsForCpuGpuPreset(mode)
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit(
                    "เลือกโหมด ${mode.labelTh} แล้ว — เชื่อมต่อ Shizuku เพื่อสั่งงาน หรือกดคัดลอกสคริปต์ได้เลย"
                )
                return@launch
            }

            _isExecuting.value = true
            var successCount = 0
            var failCount = 0
            val updatedMap = _tweakValues.value.toMutableMap()

            commands.forEachIndexed { index, (tweakId, targetValue, cmd) ->
                _executionMessage.value = "โหมด ${mode.labelTh} (${index + 1}/${commands.size})"
                val res = shizukuEngine.execute(cmd)
                if (res.success) {
                    successCount++
                    updatedMap[tweakId] = targetValue
                } else {
                    failCount++
                }
            }
            _tweakValues.value = updatedMap

            val allCmds = commands.joinToString("\n") { it.third }
            repository.recordExecutionLog(
                titleTh = "สลับโหมด CPU & GPU: ${mode.labelTh}",
                command = allCmds,
                previousValue = "-",
                newValue = "${mode.labelTh} ($successCount/${commands.size})",
                status = if (failCount == 0) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = "ปรับค่า ${mode.labelTh} สำเร็จ $successCount/${commands.size} รายการ"
            )

            _isExecuting.value = false
            _executionMessage.value = ""
            refreshTelemetryAndLiveTweaks()
            _snackbarEvents.tryEmit(
                if (failCount == 0) "เปิดใช้โหมด ${mode.labelTh} สำเร็จ ($successCount รายการ)"
                else "เปิดใช้โหมด ${mode.labelTh} สำเร็จ $successCount/${commands.size} รายการ"
            )
        }
    }

    fun runPerAppCommand(
        app: InstalledAppInfo,
        titleTh: String,
        command: String,
        reloadAppsAfter: Boolean = false
    ) {
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — สามารถคัดลอกคำสั่งของ ${app.appName} ไปรันได้")
                return@launch
            }
            _isExecuting.value = true
            _executionMessage.value = "${app.appName}: $titleTh"
            val res = shizukuEngine.execute(command)
            repository.recordExecutionLog(
                titleTh = "${app.appName} • $titleTh",
                command = command,
                previousValue = app.packageName,
                newValue = if (res.success) "สำเร็จ" else "ไม่สำเร็จ",
                status = if (res.success) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = res.stdout.ifBlank { res.stderr }.ifBlank { "เสร็จสิ้น" }
            )
            if (reloadAppsAfter && res.success) {
                _installedApps.value = shizukuEngine.loadInstalledApps()
            }
            _isExecuting.value = false
            _executionMessage.value = ""
            _snackbarEvents.tryEmit(
                if (res.success) "ปรับแต่ง ${app.appName} ($titleTh) สำเร็จ"
                else "ไม่สำเร็จ: ${res.stderr.ifBlank { "Exit ${res.exitCode}" }}"
            )
        }
    }

    fun batchFreezeApps(apps: List<InstalledAppInfo>) {
        if (apps.isEmpty()) return
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกสคริปต์ไปรันผ่าน ADB ได้")
                return@launch
            }
            _isExecuting.value = true
            var ok = 0
            var fail = 0
            apps.forEachIndexed { idx, app ->
                _executionMessage.value = "กำลังแช่แข็ง (${idx + 1}/${apps.size}): ${app.appName}"
                val res = shizukuEngine.execute("pm disable-user --user 0 ${app.packageName}")
                if (res.success) ok++ else fail++
            }
            val cmds = apps.joinToString("\n") { "pm disable-user --user 0 ${it.packageName}" }
            repository.recordExecutionLog(
                titleTh = "แช่แข็งแอปแบบกลุ่ม (${apps.size} แอป)",
                command = cmds,
                previousValue = "เปิดใช้งาน",
                newValue = "แช่แข็งสำเร็จ $ok" + if (fail > 0) " (พลาด $fail)" else "",
                status = if (fail == 0) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = "แช่แข็งสำเร็จ $ok/${apps.size} แอป"
            )
            _installedApps.value = shizukuEngine.loadInstalledApps()
            _isExecuting.value = false
            _executionMessage.value = ""
            _snackbarEvents.tryEmit("แช่แข็งแอปสำเร็จ $ok/${apps.size} แอป")
        }
    }

    fun batchEnableApps(apps: List<InstalledAppInfo>) {
        if (apps.isEmpty()) return
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกสคริปต์ไปรันผ่าน ADB ได้")
                return@launch
            }
            _isExecuting.value = true
            var ok = 0
            var fail = 0
            apps.forEachIndexed { idx, app ->
                _executionMessage.value = "กำลังเปิดใช้งาน (${idx + 1}/${apps.size}): ${app.appName}"
                val res = shizukuEngine.execute("pm enable ${app.packageName}")
                if (res.success) ok++ else fail++
            }
            val cmds = apps.joinToString("\n") { "pm enable ${it.packageName}" }
            repository.recordExecutionLog(
                titleTh = "เปิดใช้งานแอปแบบกลุ่ม (${apps.size} แอป)",
                command = cmds,
                previousValue = "แช่แข็งอยู่",
                newValue = "เปิดใช้งานสำเร็จ $ok",
                status = if (fail == 0) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = "เปิดใช้งานคืนสำเร็จ $ok/${apps.size} แอป"
            )
            _installedApps.value = shizukuEngine.loadInstalledApps()
            _isExecuting.value = false
            _executionMessage.value = ""
            _snackbarEvents.tryEmit("เปิดใช้งานแอปสำเร็จ $ok/${apps.size} แอป")
        }
    }

    fun batchRestrictBackground(apps: List<InstalledAppInfo>) {
        if (apps.isEmpty()) return
        viewModelScope.launch {
            if (shizukuState.value != ShizukuConnectionState.CONNECTED) {
                _snackbarEvents.tryEmit("ยังไม่ได้เชื่อมต่อ Shizuku — กดคัดลอกสคริปต์ไปรันผ่าน ADB ได้")
                return@launch
            }
            _isExecuting.value = true
            var ok = 0
            apps.forEachIndexed { idx, app ->
                _executionMessage.value = "จำกัดเบื้องหลัง (${idx + 1}/${apps.size}): ${app.appName}"
                val cmd = "am set-standby-bucket ${app.packageName} restricted && " +
                    "cmd appops set ${app.packageName} RUN_ANY_IN_BACKGROUND ignore"
                if (shizukuEngine.execute(cmd).success) ok++
            }
            val cmds = apps.joinToString("\n") {
                "am set-standby-bucket ${it.packageName} restricted && cmd appops set ${it.packageName} RUN_ANY_IN_BACKGROUND ignore"
            }
            repository.recordExecutionLog(
                titleTh = "จำกัดการทำงานเบื้องหลังแบบกลุ่ม (${apps.size} แอป)",
                command = cmds,
                previousValue = "ปกติ",
                newValue = "Restricted ($ok/${apps.size})",
                status = if (ok > 0) ExecutionStatus.SUCCESS else ExecutionStatus.FAILED,
                outputMessage = "จำกัดเบื้องหลังสำเร็จ $ok/${apps.size} แอป"
            )
            _isExecuting.value = false
            _executionMessage.value = ""
            _snackbarEvents.tryEmit("จำกัดการทำงานเบื้องหลังสำเร็จ $ok/${apps.size} แอป")
        }
    }

    fun restoreAllFrozenApps() {
        val frozen = _installedApps.value.filter { !it.isEnabled }
        if (frozen.isEmpty()) {
            _snackbarEvents.tryEmit("ไม่มีแอปที่ถูกแช่แข็งอยู่")
            return
        }
        batchEnableApps(frozen)
    }

    fun buildProfileScript(profile: SavedProfileEntity): String {
        val settings = repository.decodeSettings(profile.settingsJson)
        return settings.entries.mapNotNull { (tweakId, value) ->
            Android14TweakCatalog.buildCommandForTweakValue(tweakId, value)?.let { "adb shell \"$it\"" }
        }.joinToString("\n")
    }

    fun createCustomProfile(
        name: String,
        description: String,
        iconKey: String,
        settings: Map<String, String>
    ) {
        viewModelScope.launch {
            repository.createCustomProfile(name, description, iconKey, settings)
            _snackbarEvents.tryEmit("บันทึกโปรไฟล์ \"$name\" ลงเครื่องแล้ว")
        }
    }

    fun deleteCustomProfile(profileId: Int) {
        viewModelScope.launch {
            repository.deleteCustomProfile(profileId)
            _snackbarEvents.tryEmit("ลบโปรไฟล์แล้ว")
        }
    }

    fun recordCopiedCommand(titleTh: String, command: String) {
        viewModelScope.launch {
            repository.recordExecutionLog(
                titleTh = "คัดลอก: $titleTh",
                command = command,
                previousValue = "-",
                newValue = "คัดลอกแล้ว",
                status = ExecutionStatus.COPIED,
                outputMessage = "คัดลอกคำสั่งไปยังคลิปบอร์ด"
            )
            _snackbarEvents.tryEmit("คัดลอกคำสั่ง ADB แล้ว")
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _snackbarEvents.tryEmit("ล้างประวัติคำสั่งแล้ว")
        }
    }
}
