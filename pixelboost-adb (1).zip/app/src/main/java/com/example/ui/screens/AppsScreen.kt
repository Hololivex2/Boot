package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppFilter
import com.example.model.AppSafetyRisk
import com.example.model.InstalledAppInfo
import com.example.ui.components.AdbCommandBox
import com.example.ui.components.ExpressiveMorphingButton
import com.example.ui.components.ExpressiveMorphingOutlinedButton
import com.example.ui.components.ExpressiveMorphingTonalButton
import com.example.ui.components.ExpressivePillSearchBar
import com.example.ui.components.ExpressivePolygonLoader
import com.example.ui.components.ExpressiveShapeIconBadge
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveEmphasizedType
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.LocalExtendedColors
import com.example.ui.theme.LocalReduceMotion

@Composable
fun AppsScreen(
    apps: List<InstalledAppInfo>,
    isLoading: Boolean,
    filter: AppFilter,
    onFilterChange: (AppFilter) -> Unit,
    onReloadApps: () -> Unit,
    onRunPerAppCommand: (InstalledAppInfo, String, String, Boolean) -> Unit,
    onBatchFreeze: (List<InstalledAppInfo>) -> Unit,
    onBatchEnable: (List<InstalledAppInfo>) -> Unit,
    onBatchRestrict: (List<InstalledAppInfo>) -> Unit,
    onRestoreAllFrozen: () -> Unit,
    onCopyCommand: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    val clipboard = LocalClipboardManager.current

    var search by remember { mutableStateOf("") }
    var selectedApp by remember { mutableStateOf<InstalledAppInfo?>(null) }
    var selectionMode by remember { mutableStateOf(false) }
    var selectedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showBatchFreezeConfirm by remember { mutableStateOf(false) }
    var showRestoreAllConfirm by remember { mutableStateOf(false) }

    val safeBloatApps = remember(apps) {
        apps.filter { it.safetyRisk == AppSafetyRisk.SAFE_BLOATWARE }
    }
    val safeEnabledBloatApps = remember(safeBloatApps) {
        safeBloatApps.filter { it.isEnabled }
    }
    val frozenAppsCount = remember(apps) {
        apps.count { !it.isEnabled }
    }

    val filteredApps = remember(apps, filter, search) {
        apps.filter { app ->
            val matchFilter = when (filter) {
                AppFilter.USER -> !app.isSystemApp
                AppFilter.BLOATWARE -> app.safetyRisk == AppSafetyRisk.SAFE_BLOATWARE
                AppFilter.GAMES -> app.isGame
                AppFilter.ALL -> true
                AppFilter.DISABLED -> !app.isEnabled
            }
            val q = search.trim()
            val matchSearch = q.isEmpty() ||
                app.appName.contains(q, ignoreCase = true) ||
                app.packageName.contains(q, ignoreCase = true) ||
                app.adviceTh.contains(q, ignoreCase = true)
            matchFilter && matchSearch
        }
    }

    val selectedAppObjects = remember(apps, selectedPackages) {
        apps.filter { it.packageName in selectedPackages }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "จัดการแอป & Bloatware",
                            style = ExpressiveEmphasizedType.HeadlineEmphasized,
                            color = cs.onSurface
                        )
                        Text(
                            text = "วิเคราะห์ความปลอดภัย แช่แข็ง หรือปรับ Game Downscale / FPS",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (selectionMode) cs.primaryContainer else cs.surfaceContainerHigh
                        ) {
                            IconButton(
                                onClick = {
                                    if (selectionMode) {
                                        selectionMode = false
                                        selectedPackages = emptySet()
                                    } else {
                                        selectionMode = true
                                    }
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("apps_toggle_multiselect_button")
                            ) {
                                Icon(
                                    imageVector = if (selectionMode) Icons.Filled.Close else Icons.Filled.CheckBox,
                                    contentDescription = if (selectionMode) "ออกจากโหมดเลือกหลายแอป" else "เลือกหลายแอปพร้อมกัน",
                                    tint = if (selectionMode) cs.onPrimaryContainer else cs.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            shape = CircleShape,
                            color = cs.primaryContainer
                        ) {
                            IconButton(
                                onClick = onReloadApps,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("apps_reload_button")
                            ) {
                                Icon(
                                    Icons.Filled.Refresh,
                                    contentDescription = "โหลดรายการแอปใหม่",
                                    tint = cs.onPrimaryContainer
                                )
                            }
                        }
                    }
                }

                BloatwareSummaryCard(
                    safeBloatCount = safeBloatApps.size,
                    safeEnabledCount = safeEnabledBloatApps.size,
                    frozenCount = frozenAppsCount,
                    totalCount = apps.size,
                    onSelectAllSafeBloat = {
                        onFilterChange(AppFilter.BLOATWARE)
                        selectionMode = true
                        selectedPackages = safeEnabledBloatApps.map { it.packageName }.toSet()
                    },
                    onRestoreAllFrozen = { showRestoreAllConfirm = true }
                )

                ExpressivePillSearchBar(
                    query = search,
                    onQueryChange = { search = it },
                    placeholder = "ค้นหาชื่อแอป, Package Name หรือคำแนะนำ...",
                    testTag = "apps_search_input"
                )
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(AppFilter.entries) { item ->
                    val badgeCount = when (item) {
                        AppFilter.BLOATWARE -> safeBloatApps.size
                        AppFilter.DISABLED -> frozenAppsCount
                        else -> null
                    }
                    val chipText = if (badgeCount != null) "${item.labelTh} ($badgeCount)" else item.labelTh
                    val selected = filter == item
                    val chipCorner by animateDpAsState(
                        targetValue = if (selected) ExpressiveCorner.ExtraLarge else ExpressiveCorner.Medium,
                        animationSpec = ExpressiveMotion.standardSpatialFast(reduceMotion),
                        label = "appFilterCorner"
                    )
                    FilterChip(
                        selected = selected,
                        onClick = { onFilterChange(item) },
                        shape = RoundedCornerShape(chipCorner),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primaryContainer,
                            selectedLabelColor = cs.onPrimaryContainer,
                            containerColor = cs.surfaceContainerLow
                        ),
                        label = {
                            Text(
                                chipText,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("app_filter_${item.name}")
                    )
                }
            }

            AnimatedVisibility(visible = selectionMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "เลือกอยู่ ${selectedPackages.size} แอป (แตะเพื่อเลือก/ยกเลิก)",
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.primary
                    )
                    TextButton(
                        onClick = {
                            val nonCritical = filteredApps
                                .filter { it.safetyRisk != AppSafetyRisk.SYSTEM_CRITICAL }
                                .map { it.packageName }
                                .toSet()
                            selectedPackages = if (selectedPackages.containsAll(nonCritical)) {
                                emptySet()
                            } else {
                                selectedPackages + nonCritical
                            }
                        },
                        modifier = Modifier.testTag("apps_select_all_visible_button")
                    ) {
                        Icon(Icons.Filled.SelectAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("เลือกหน้านี้")
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            ExpressivePolygonLoader(
                                size = 56.dp,
                                color = cs.primary,
                                containerColor = cs.primaryContainer
                            )
                            Text(
                                text = "กำลังวิเคราะห์แอปและ Bloatware ในเครื่อง...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }

                filteredApps.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ExpressiveShapeIconBadge(
                                shape = ExpressiveGeometry.scallopCookie(lobes = 8),
                                containerColor = cs.primaryContainer,
                                size = 56.dp
                            ) {
                                Icon(
                                    Icons.Filled.VerifiedUser,
                                    contentDescription = null,
                                    tint = cs.onPrimaryContainer,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Text(
                                text = when (filter) {
                                    AppFilter.BLOATWARE -> "ไม่พบ Bloatware ที่แนะนำให้ปิดในเครื่องนี้"
                                    AppFilter.DISABLED -> "ยังไม่มีแอปที่ถูกแช่แข็งอยู่"
                                    else -> "ไม่พบแอปที่ตรงกับเงื่อนไข"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(
                            start = 16.dp,
                            end = 16.dp,
                            top = 8.dp,
                            bottom = if (selectedPackages.isNotEmpty()) 112.dp else 16.dp
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            val isSelected = app.packageName in selectedPackages
                            AppItemCard(
                                app = app,
                                selectionMode = selectionMode,
                                isSelected = isSelected,
                                onClick = {
                                    if (selectionMode) {
                                        selectedPackages = if (isSelected) {
                                            selectedPackages - app.packageName
                                        } else {
                                            selectedPackages + app.packageName
                                        }
                                    } else {
                                        selectedApp = app
                                    }
                                },
                                onLongClick = {
                                    selectionMode = true
                                    selectedPackages = selectedPackages + app.packageName
                                }
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = selectedPackages.isNotEmpty(),
            enter = fadeIn(ExpressiveMotion.effectsDefault(reduceMotion)) +
                slideInVertically(ExpressiveMotion.spatialDefault(reduceMotion)) { it },
            exit = fadeOut(ExpressiveMotion.effectsFast(reduceMotion)) +
                slideOutVertically(ExpressiveMotion.standardSpatialFast(reduceMotion)) { it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .widthIn(max = 840.dp)
                .navigationBarsPadding()
        ) {
            BatchActionBottomBar(
                selectedCount = selectedPackages.size,
                onFreeze = { showBatchFreezeConfirm = true },
                onEnable = {
                    onBatchEnable(selectedAppObjects)
                    selectedPackages = emptySet()
                    selectionMode = false
                },
                onRestrict = {
                    onBatchRestrict(selectedAppObjects)
                    selectedPackages = emptySet()
                    selectionMode = false
                },
                onCopyScript = {
                    val script = selectedAppObjects.joinToString("\n") {
                        "adb shell \"pm disable-user --user 0 ${it.packageName}\""
                    }
                    clipboard.setText(AnnotatedString(script))
                    onCopyCommand("สคริปต์แช่แข็ง ${selectedAppObjects.size} แอป", script)
                }
            )
        }
    }

    selectedApp?.let { app ->
        AppTuningBottomSheet(
            app = app,
            onDismiss = { selectedApp = null },
            onRunCommand = { titleTh, cmd, reloadAfter ->
                onRunPerAppCommand(app, titleTh, cmd, reloadAfter)
                if (reloadAfter) {
                    selectedApp = null
                }
            },
            onCopyCommand = { titleTh, cmd ->
                onCopyCommand("${app.appName} • $titleTh", cmd)
            }
        )
    }

    if (showBatchFreezeConfirm) {
        val hasCritical = selectedAppObjects.any { it.safetyRisk == AppSafetyRisk.SYSTEM_CRITICAL }
        AlertDialog(
            onDismissRequest = { showBatchFreezeConfirm = false },
            shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
            containerColor = cs.surfaceContainerHigh,
            title = { Text("แช่แข็งแอปที่เลือก (${selectedAppObjects.size} แอป)?") },
            text = {
                val msg = if (hasCritical) {
                    "คำเตือน: มีบางแอปที่เป็น \"ระบบสำคัญ\" รวมอยู่ด้วย แนะนำให้ยกเลิกการเลือกระบบสำคัญก่อนแช่แข็ง เพื่อป้องกันเครื่องทำงานผิดปกติ"
                } else {
                    "ระบบจะรันคำสั่ง pm disable-user --user 0 เพื่อหยุดและซ่อนแอปที่เลือกทั้งหมดโดยไม่ลบข้อมูล สามารถเปิดคืนได้ทุกเมื่อ"
                }
                Text(msg)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showBatchFreezeConfirm = false
                        onBatchFreeze(selectedAppObjects)
                        selectedPackages = emptySet()
                        selectionMode = false
                    },
                    modifier = Modifier.testTag("confirm_batch_freeze_button")
                ) {
                    Text("ยืนยันแช่แข็ง")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchFreezeConfirm = false }) {
                    Text("ยกเลิก")
                }
            }
        )
    }

    if (showRestoreAllConfirm) {
        AlertDialog(
            onDismissRequest = { showRestoreAllConfirm = false },
            shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
            containerColor = cs.surfaceContainerHigh,
            title = { Text("เปิดคืนแอปที่แช่แข็งทั้งหมด?") },
            text = {
                Text("ระบบจะปลดล็อกเปิดใช้งานแอปที่ถูกแช่แข็งอยู่ทั้งหมด ($frozenAppsCount แอป) กลับมาเป็นปกติ")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showRestoreAllConfirm = false
                        onRestoreAllFrozen()
                    },
                    modifier = Modifier.testTag("confirm_restore_all_frozen_button")
                ) {
                    Text("เปิดคืนทั้งหมด")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreAllConfirm = false }) {
                    Text("ยกเลิก")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BloatwareSummaryCard(
    safeBloatCount: Int,
    safeEnabledCount: Int,
    frozenCount: Int,
    totalCount: Int,
    onSelectAllSafeBloat: () -> Unit,
    onRestoreAllFrozen: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ext = LocalExtendedColors.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, cs.outlineVariant.copy(alpha = 0.65f), RoundedCornerShape(ExpressiveCorner.LargeIncreased)),
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SummaryStatPill(
                    label = "Bloatware ปิดได้",
                    value = "$safeBloatCount แอป",
                    accentColor = cs.primary,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                SummaryStatPill(
                    label = "แช่แข็งแล้ว",
                    value = "$frozenCount แอป",
                    accentColor = ext.warning,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                SummaryStatPill(
                    label = "ทั้งหมดในเครื่อง",
                    value = "$totalCount แอป",
                    accentColor = ext.success,
                    modifier = Modifier.weight(1f)
                )
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (safeEnabledCount > 0) {
                    ExpressiveMorphingTonalButton(
                        onClick = onSelectAllSafeBloat,
                        modifier = Modifier.testTag("select_all_safe_bloat_button")
                    ) {
                        Icon(Icons.Filled.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("เลือก Bloatware ปลอดภัย ($safeEnabledCount)")
                    }
                }
                if (frozenCount > 0) {
                    ExpressiveMorphingOutlinedButton(
                        onClick = onRestoreAllFrozen,
                        modifier = Modifier.testTag("restore_all_frozen_button")
                    ) {
                        Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("เปิดคืนทั้งหมด ($frozenCount)")
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryStatPill(
    label: String,
    value: String,
    accentColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(ExpressiveCorner.Large),
        color = cs.surfaceContainerLowest
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = ExpressiveEmphasizedType.TitleEmphasized,
                color = accentColor,
                maxLines = 1
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppItemCard(
    app: InstalledAppInfo,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ext = LocalExtendedColors.current

    val (riskBg, riskFg, riskLabel) = when (app.safetyRisk) {
        AppSafetyRisk.SAFE_BLOATWARE -> Triple(ext.successContainer, ext.success, "แนะนำปิดได้")
        AppSafetyRisk.OPTIONAL -> Triple(cs.surfaceContainerHigh, cs.onSurfaceVariant, if (app.isSystemApp) "แอประบบ" else "แอปทั่วไป")
        AppSafetyRisk.SYSTEM_CRITICAL -> Triple(cs.errorContainer, cs.error, "ระบบสำคัญ")
    }

    val cardShape = RoundedCornerShape(ExpressiveCorner.LargeIncreased)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .border(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) cs.primary else cs.outlineVariant.copy(alpha = 0.6f),
                shape = cardShape
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("app_card_${app.packageName}"),
        shape = cardShape,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) cs.primaryContainer.copy(alpha = 0.28f) else cs.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectionMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    modifier = Modifier.testTag("app_checkbox_${app.packageName}")
                )
            } else {
                ExpressiveShapeIconBadge(
                    shape = if (app.isGame) ExpressiveGeometry.softBurst(points = 10, amplitudeRatio = 0.1f) else ExpressiveGeometry.Squircle,
                    containerColor = if (app.isGame) cs.tertiaryContainer else cs.surfaceContainerHigh,
                    size = 46.dp
                ) {
                    Icon(
                        imageVector = if (app.isGame) Icons.Filled.SportsEsports else Icons.Filled.Android,
                        contentDescription = null,
                        tint = if (app.isGame) cs.onTertiaryContainer else cs.onSurfaceVariant
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = app.appName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = cs.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (!app.isEnabled) {
                        Surface(color = ext.warningContainer, shape = CircleShape) {
                            Text(
                                text = "แช่แข็งอยู่",
                                style = MaterialTheme.typography.labelSmall,
                                color = ext.warning,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Text(
                    text = app.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (app.adviceTh.isNotBlank()) {
                    Text(
                        text = app.adviceTh,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (app.safetyRisk == AppSafetyRisk.SAFE_BLOATWARE) ext.success else cs.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(color = riskBg, shape = CircleShape) {
                    Text(
                        text = riskLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = riskFg,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                if (app.isGame) {
                    Surface(color = cs.tertiaryContainer, shape = CircleShape) {
                        Text(
                            text = "เกม",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = cs.onTertiaryContainer,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BatchActionBottomBar(
    selectedCount: Int,
    onFreeze: () -> Unit,
    onEnable: () -> Unit,
    onRestrict: () -> Unit,
    onCopyScript: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
        shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
        color = cs.surfaceContainerHighest,
        tonalElevation = 4.dp,
        shadowElevation = 6.dp
    ) {
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExpressiveMorphingButton(
                onClick = onFreeze,
                colors = ButtonDefaults.buttonColors(
                    containerColor = cs.errorContainer,
                    contentColor = cs.onErrorContainer
                ),
                modifier = Modifier.testTag("batch_freeze_button")
            ) {
                Icon(Icons.Filled.AcUnit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("แช่แข็ง ($selectedCount)")
            }

            ExpressiveMorphingTonalButton(
                onClick = onEnable,
                modifier = Modifier.testTag("batch_enable_button")
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("เปิดคืน")
            }

            ExpressiveMorphingOutlinedButton(
                onClick = onRestrict,
                modifier = Modifier.testTag("batch_restrict_button")
            ) {
                Icon(Icons.Filled.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("จำกัดเบื้องหลัง")
            }

            Surface(
                shape = CircleShape,
                color = cs.primaryContainer
            ) {
                IconButton(
                    onClick = onCopyScript,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("batch_copy_button")
                ) {
                    Icon(
                        Icons.Filled.ContentCopy,
                        contentDescription = "คัดลอกคำสั่ง ADB ทั้งหมด",
                        tint = cs.onPrimaryContainer
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AppTuningBottomSheet(
    app: InstalledAppInfo,
    onDismiss: () -> Unit,
    onRunCommand: (String, String, Boolean) -> Unit,
    onCopyCommand: (String, String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cs = MaterialTheme.colorScheme
    val ext = LocalExtendedColors.current
    var showFreezeConfirm by remember { mutableStateOf(false) }

    val pkg = app.packageName
    var previewCmd by remember { mutableStateOf("pm disable-user --user 0 $pkg") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = ExpressiveCorner.ExtraLarge, topEnd = ExpressiveCorner.ExtraLarge),
        containerColor = cs.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = app.appName,
                    style = MaterialTheme.typography.titleLarge,
                    color = cs.onSurface
                )
                Text(
                    text = pkg,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }

            val (bannerBg, bannerFg, bannerIcon) = when (app.safetyRisk) {
                AppSafetyRisk.SAFE_BLOATWARE -> Triple(ext.successContainer, ext.success, Icons.Filled.VerifiedUser)
                AppSafetyRisk.OPTIONAL -> Triple(cs.surfaceContainerHigh, cs.onSurfaceVariant, Icons.Filled.Shield)
                AppSafetyRisk.SYSTEM_CRITICAL -> Triple(cs.errorContainer, cs.error, Icons.Filled.WarningAmber)
            }

            Surface(
                color = bannerBg,
                shape = RoundedCornerShape(ExpressiveCorner.Large),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(bannerIcon, contentDescription = null, tint = bannerFg)
                    Column {
                        Text(
                            text = app.safetyRisk.labelTh,
                            style = MaterialTheme.typography.labelLarge,
                            color = bannerFg
                        )
                        Text(
                            text = app.adviceTh,
                            style = MaterialTheme.typography.bodySmall,
                            color = bannerFg
                        )
                    }
                }
            }

            HorizontalDivider(color = cs.outlineVariant)

            Text(
                text = "1. จัดการ Bloatware & หยุดการทำงาน (No-Root)",
                style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (app.isEnabled) {
                    ExpressiveMorphingButton(
                        onClick = {
                            previewCmd = "pm disable-user --user 0 $pkg"
                            showFreezeConfirm = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = cs.errorContainer,
                            contentColor = cs.onErrorContainer
                        )
                    ) {
                        Icon(Icons.Filled.AcUnit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("แช่แข็งแอป")
                    }
                } else {
                    ExpressiveMorphingButton(
                        onClick = {
                            val cmd = "pm enable $pkg"
                            previewCmd = cmd
                            onRunCommand("เปิดใช้งานแอปอีกครั้ง", cmd, true)
                        }
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ยกเลิกการแช่แข็ง")
                    }
                }

                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        val cmd = "am force-stop $pkg"
                        previewCmd = cmd
                        onRunCommand("บังคับหยุดทำงานทันที", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.StopCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("หยุดทำงานทันที (Force Stop)")
                }
            }

            Text(
                text = "2. จำกัดการทำงานเบื้องหลัง (Standby Bucket & AppOps)",
                style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        val cmd = "am set-standby-bucket $pkg active && cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow"
                        previewCmd = cmd
                        onRunCommand("ปลดล็อกเบื้องหลังเต็มที่", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("อนุญาตเบื้องหลังเต็มที่")
                }
                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        val cmd = "am set-standby-bucket $pkg restricted && cmd appops set $pkg RUN_ANY_IN_BACKGROUND ignore"
                        previewCmd = cmd
                        onRunCommand("จำกัดเบื้องหลังเข้มงวด", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("จำกัดเบื้องหลัง (ประหยัดแบต)")
                }
            }

            Text(
                text = "3. Android 14 Game Mode & ART Compile",
                style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExpressiveMorphingTonalButton(
                    onClick = {
                        val cmd = "cmd game mode performance $pkg"
                        previewCmd = cmd
                        onRunCommand("Game Mode: แรงสุด", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.SportsEsports, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Game แรงสุด")
                }
                ExpressiveMorphingTonalButton(
                    onClick = {
                        val cmd = "cmd game mode battery $pkg"
                        previewCmd = cmd
                        onRunCommand("Game Mode: ประหยัดแบต", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.BatterySaver, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Game ประหยัดไฟ")
                }
                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        val cmd = "cmd package compile -m speed-profile -f $pkg"
                        previewCmd = cmd
                        onRunCommand("ART Speed Profile", cmd, false)
                    }
                ) {
                    Icon(Icons.Filled.RocketLaunch, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("คอมไพล์ ART")
                }
            }

            var downscaleRatio by remember { mutableStateOf("0.75") }
            var targetFps by remember { mutableStateOf("90") }

            Text(
                text = "4. ปรับความละเอียดเกม (Downscale) & ล็อก FPS",
                style = MaterialTheme.typography.titleSmall,
                color = cs.onSurface
            )
            Text(
                text = "ลดสเกลความละเอียดเพื่อลดภาระ GPU ให้เฟรมนิ่งขึ้น หรือเลือก 1.0 เพื่อภาพสวยคมสุด",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    "0.6" to "0.6x ลื่นสุด",
                    "0.75" to "0.75x สมดุล",
                    "0.85" to "0.85x คม+ลื่น",
                    "1.0" to "1.0x ภาพสวยเต็ม"
                ).forEach { (ratio, label) ->
                    val selected = downscaleRatio == ratio
                    FilterChip(
                        selected = selected,
                        onClick = { downscaleRatio = ratio },
                        shape = if (selected) CircleShape else RoundedCornerShape(ExpressiveCorner.Medium),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primaryContainer,
                            selectedLabelColor = cs.onPrimaryContainer
                        ),
                        label = { Text(label) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("30", "60", "90", "120").forEach { fps ->
                    val selected = targetFps == fps
                    FilterChip(
                        selected = selected,
                        onClick = { targetFps = fps },
                        shape = if (selected) CircleShape else RoundedCornerShape(ExpressiveCorner.Medium),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.tertiaryContainer,
                            selectedLabelColor = cs.onTertiaryContainer
                        ),
                        label = { Text("$fps FPS") },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ExpressiveMorphingButton(
                    onClick = {
                        val cmd = "cmd game set --fps $targetFps --downscale $downscaleRatio $pkg"
                        previewCmd = cmd
                        onRunCommand("Game Scale ${downscaleRatio}x • $targetFps FPS", cmd, false)
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ปรับใช้กับเกมนี้")
                }
                ExpressiveMorphingOutlinedButton(
                    onClick = {
                        val cmd = "cmd game reset $pkg"
                        previewCmd = cmd
                        onRunCommand("รีเซ็ตค่าเกมเป็นปกติ", cmd, false)
                    }
                ) {
                    Text("รีเซ็ตเกม")
                }
            }

            AdbCommandBox(
                command = previewCmd,
                onCopy = { onCopyCommand("คำสั่งเฉพาะแอป", previewCmd) }
            )
        }
    }

    if (showFreezeConfirm) {
        AlertDialog(
            onDismissRequest = { showFreezeConfirm = false },
            shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
            containerColor = cs.surfaceContainerHigh,
            title = { Text("ยืนยันการแช่แข็งแอป?") },
            text = {
                val warn = if (app.safetyRisk == AppSafetyRisk.SYSTEM_CRITICAL) {
                    "คำเตือนสำคัญ: \"${app.appName}\" เป็นองค์ประกอบหลักของระบบ! ไม่แนะนำให้แช่แข็งเพราะอาจทำให้เครื่องค้างหรือเข้าเมนูไม่ได้"
                } else {
                    "แอป \"${app.appName}\" จะถูกซ่อนและหยุดทำงานเบื้องหลังทั้งหมดโดยข้อมูลไม่สูญหาย สามารถกดเปิดใช้งานคืนได้ทุกเมื่อ"
                }
                Text(warn)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showFreezeConfirm = false
                        onRunCommand("แช่แข็งแอป", "pm disable-user --user 0 $pkg", true)
                    }
                ) {
                    Text("ยืนยันแช่แข็ง")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFreezeConfirm = false }) {
                    Text("ยกเลิก")
                }
            }
        )
    }
}
