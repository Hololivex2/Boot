package com.example.ui.theme

import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.model.ThemeAccent
import com.example.model.ThemeMode

@Immutable
data class ExtendedColors(
    val success: Color,
    val successContainer: Color,
    val warning: Color,
    val warningContainer: Color
)

val LocalExtendedColors = staticCompositionLocalOf {
    ExtendedColors(
        success = StatusSuccessDark,
        successContainer = StatusSuccessContainerDark,
        warning = StatusWarningDark,
        warningContainer = StatusWarningContainerDark
    )
}

private fun buildLightScheme(accent: ThemeAccent): ColorScheme {
    return when (accent) {
        ThemeAccent.PURPLE -> lightColorScheme(
            primary = PurpleLightPrimary,
            onPrimary = PurpleLightOnPrimary,
            primaryContainer = PurpleLightPrimaryContainer,
            onPrimaryContainer = PurpleLightOnPrimaryContainer,
            secondary = PurpleLightSecondary,
            onSecondary = PurpleLightOnSecondary,
            secondaryContainer = PurpleLightSecondaryContainer,
            onSecondaryContainer = PurpleLightOnSecondaryContainer,
            tertiary = PurpleLightTertiary,
            onTertiary = PurpleLightOnTertiary,
            tertiaryContainer = PurpleLightTertiaryContainer,
            onTertiaryContainer = PurpleLightOnTertiaryContainer,
            background = PurpleLightSurface,
            onBackground = PurpleLightOnSurface,
            surface = PurpleLightSurface,
            onSurface = PurpleLightOnSurface,
            surfaceVariant = PurpleLightSurfaceContainerHighest,
            onSurfaceVariant = PurpleLightOnSurfaceVariant,
            surfaceContainerLowest = PurpleLightSurfaceContainerLowest,
            surfaceContainerLow = PurpleLightSurfaceContainerLow,
            surfaceContainer = PurpleLightSurfaceContainer,
            surfaceContainerHigh = PurpleLightSurfaceContainerHigh,
            surfaceContainerHighest = PurpleLightSurfaceContainerHighest,
            outline = PurpleLightOutline,
            outlineVariant = PurpleLightOutlineVariant,
            inverseSurface = PurpleLightInverseSurface,
            inverseOnSurface = PurpleLightInverseOnSurface,
            inversePrimary = PurpleLightInversePrimary,
            error = M3LightError,
            onError = M3LightOnError,
            errorContainer = M3LightErrorContainer,
            onErrorContainer = M3LightOnErrorContainer
        )

        ThemeAccent.BLUE -> lightColorScheme(
            primary = BlueLightPrimary,
            onPrimary = BlueLightOnPrimary,
            primaryContainer = BlueLightPrimaryContainer,
            onPrimaryContainer = BlueLightOnPrimaryContainer,
            secondary = BlueLightSecondary,
            onSecondary = BlueLightOnSecondary,
            secondaryContainer = BlueLightSecondaryContainer,
            onSecondaryContainer = BlueLightOnSecondaryContainer,
            tertiary = BlueLightTertiary,
            onTertiary = BlueLightOnTertiary,
            tertiaryContainer = BlueLightTertiaryContainer,
            onTertiaryContainer = BlueLightOnTertiaryContainer,
            background = BlueLightSurface,
            onBackground = BlueLightOnSurface,
            surface = BlueLightSurface,
            onSurface = BlueLightOnSurface,
            surfaceVariant = BlueLightSurfaceContainerHighest,
            onSurfaceVariant = BlueLightOnSurfaceVariant,
            surfaceContainerLowest = BlueLightSurfaceContainerLowest,
            surfaceContainerLow = BlueLightSurfaceContainerLow,
            surfaceContainer = BlueLightSurfaceContainer,
            surfaceContainerHigh = BlueLightSurfaceContainerHigh,
            surfaceContainerHighest = BlueLightSurfaceContainerHighest,
            outline = BlueLightOutline,
            outlineVariant = BlueLightOutlineVariant,
            inverseSurface = BlueLightInverseSurface,
            inverseOnSurface = BlueLightInverseOnSurface,
            inversePrimary = BlueLightInversePrimary,
            error = M3LightError,
            onError = M3LightOnError,
            errorContainer = M3LightErrorContainer,
            onErrorContainer = M3LightOnErrorContainer
        )

        ThemeAccent.GREEN -> lightColorScheme(
            primary = GreenLightPrimary,
            onPrimary = GreenLightOnPrimary,
            primaryContainer = GreenLightPrimaryContainer,
            onPrimaryContainer = GreenLightOnPrimaryContainer,
            secondary = GreenLightSecondary,
            onSecondary = GreenLightOnSecondary,
            secondaryContainer = GreenLightSecondaryContainer,
            onSecondaryContainer = GreenLightOnSecondaryContainer,
            tertiary = GreenLightTertiary,
            onTertiary = GreenLightOnTertiary,
            tertiaryContainer = GreenLightTertiaryContainer,
            onTertiaryContainer = GreenLightOnTertiaryContainer,
            background = GreenLightSurface,
            onBackground = GreenLightOnSurface,
            surface = GreenLightSurface,
            onSurface = GreenLightOnSurface,
            surfaceVariant = GreenLightSurfaceContainerHighest,
            onSurfaceVariant = GreenLightOnSurfaceVariant,
            surfaceContainerLowest = GreenLightSurfaceContainerLowest,
            surfaceContainerLow = GreenLightSurfaceContainerLow,
            surfaceContainer = GreenLightSurfaceContainer,
            surfaceContainerHigh = GreenLightSurfaceContainerHigh,
            surfaceContainerHighest = GreenLightSurfaceContainerHighest,
            outline = GreenLightOutline,
            outlineVariant = GreenLightOutlineVariant,
            inverseSurface = GreenLightInverseSurface,
            inverseOnSurface = GreenLightInverseOnSurface,
            inversePrimary = GreenLightInversePrimary,
            error = M3LightError,
            onError = M3LightOnError,
            errorContainer = M3LightErrorContainer,
            onErrorContainer = M3LightOnErrorContainer
        )
    }
}

private fun buildDarkScheme(accent: ThemeAccent): ColorScheme {
    return when (accent) {
        ThemeAccent.PURPLE -> darkColorScheme(
            primary = PurpleDarkPrimary,
            onPrimary = PurpleDarkOnPrimary,
            primaryContainer = PurpleDarkPrimaryContainer,
            onPrimaryContainer = PurpleDarkOnPrimaryContainer,
            secondary = PurpleDarkSecondary,
            onSecondary = PurpleDarkOnSecondary,
            secondaryContainer = PurpleDarkSecondaryContainer,
            onSecondaryContainer = PurpleDarkOnSecondaryContainer,
            tertiary = PurpleDarkTertiary,
            onTertiary = PurpleDarkOnTertiary,
            tertiaryContainer = PurpleDarkTertiaryContainer,
            onTertiaryContainer = PurpleDarkOnTertiaryContainer,
            background = PurpleDarkSurface,
            onBackground = PurpleDarkOnSurface,
            surface = PurpleDarkSurface,
            onSurface = PurpleDarkOnSurface,
            surfaceVariant = PurpleDarkSurfaceContainerHighest,
            onSurfaceVariant = PurpleDarkOnSurfaceVariant,
            surfaceContainerLowest = PurpleDarkSurfaceContainerLowest,
            surfaceContainerLow = PurpleDarkSurfaceContainerLow,
            surfaceContainer = PurpleDarkSurfaceContainer,
            surfaceContainerHigh = PurpleDarkSurfaceContainerHigh,
            surfaceContainerHighest = PurpleDarkSurfaceContainerHighest,
            outline = PurpleDarkOutline,
            outlineVariant = PurpleDarkOutlineVariant,
            inverseSurface = PurpleDarkInverseSurface,
            inverseOnSurface = PurpleDarkInverseOnSurface,
            inversePrimary = PurpleDarkInversePrimary,
            error = M3DarkError,
            onError = M3DarkOnError,
            errorContainer = M3DarkErrorContainer,
            onErrorContainer = M3DarkOnErrorContainer
        )

        ThemeAccent.BLUE -> darkColorScheme(
            primary = BlueDarkPrimary,
            onPrimary = BlueDarkOnPrimary,
            primaryContainer = BlueDarkPrimaryContainer,
            onPrimaryContainer = BlueDarkOnPrimaryContainer,
            secondary = BlueDarkSecondary,
            onSecondary = BlueDarkOnSecondary,
            secondaryContainer = BlueDarkSecondaryContainer,
            onSecondaryContainer = BlueDarkOnSecondaryContainer,
            tertiary = BlueDarkTertiary,
            onTertiary = BlueDarkOnTertiary,
            tertiaryContainer = BlueDarkTertiaryContainer,
            onTertiaryContainer = BlueDarkOnTertiaryContainer,
            background = BlueDarkSurface,
            onBackground = BlueDarkOnSurface,
            surface = BlueDarkSurface,
            onSurface = BlueDarkOnSurface,
            surfaceVariant = BlueDarkSurfaceContainerHighest,
            onSurfaceVariant = BlueDarkOnSurfaceVariant,
            surfaceContainerLowest = BlueDarkSurfaceContainerLowest,
            surfaceContainerLow = BlueDarkSurfaceContainerLow,
            surfaceContainer = BlueDarkSurfaceContainer,
            surfaceContainerHigh = BlueDarkSurfaceContainerHigh,
            surfaceContainerHighest = BlueDarkSurfaceContainerHighest,
            outline = BlueDarkOutline,
            outlineVariant = BlueDarkOutlineVariant,
            inverseSurface = BlueDarkInverseSurface,
            inverseOnSurface = BlueDarkInverseOnSurface,
            inversePrimary = BlueDarkInversePrimary,
            error = M3DarkError,
            onError = M3DarkOnError,
            errorContainer = M3DarkErrorContainer,
            onErrorContainer = M3DarkOnErrorContainer
        )

        ThemeAccent.GREEN -> darkColorScheme(
            primary = GreenDarkPrimary,
            onPrimary = GreenDarkOnPrimary,
            primaryContainer = GreenDarkPrimaryContainer,
            onPrimaryContainer = GreenDarkOnPrimaryContainer,
            secondary = GreenDarkSecondary,
            onSecondary = GreenDarkOnSecondary,
            secondaryContainer = GreenDarkSecondaryContainer,
            onSecondaryContainer = GreenDarkOnSecondaryContainer,
            tertiary = GreenDarkTertiary,
            onTertiary = GreenDarkOnTertiary,
            tertiaryContainer = GreenDarkTertiaryContainer,
            onTertiaryContainer = GreenDarkOnTertiaryContainer,
            background = GreenDarkSurface,
            onBackground = GreenDarkOnSurface,
            surface = GreenDarkSurface,
            onSurface = GreenDarkOnSurface,
            surfaceVariant = GreenDarkSurfaceContainerHighest,
            onSurfaceVariant = GreenDarkOnSurfaceVariant,
            surfaceContainerLowest = GreenDarkSurfaceContainerLowest,
            surfaceContainerLow = GreenDarkSurfaceContainerLow,
            surfaceContainer = GreenDarkSurfaceContainer,
            surfaceContainerHigh = GreenDarkSurfaceContainerHigh,
            surfaceContainerHighest = GreenDarkSurfaceContainerHighest,
            outline = GreenDarkOutline,
            outlineVariant = GreenDarkOutlineVariant,
            inverseSurface = GreenDarkInverseSurface,
            inverseOnSurface = GreenDarkInverseOnSurface,
            inversePrimary = GreenDarkInversePrimary,
            error = M3DarkError,
            onError = M3DarkOnError,
            errorContainer = M3DarkErrorContainer,
            onErrorContainer = M3DarkOnErrorContainer
        )
    }
}

private val PixelBoostShapes = Shapes(
    extraSmall = RoundedCornerShape(ExpressiveCorner.ExtraSmall),
    small = RoundedCornerShape(ExpressiveCorner.Small),
    medium = RoundedCornerShape(ExpressiveCorner.Large),
    large = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
    extraLarge = RoundedCornerShape(ExpressiveCorner.ExtraLarge)
)

@Composable
fun PixelBoostTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    themeAccent: ThemeAccent = ThemeAccent.BLUE,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val reduceMotion = remember(context) {
        runCatching {
            val scale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f
            )
            scale == 0f
        }.getOrDefault(false)
    }

    val isDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = if (isDark) buildDarkScheme(themeAccent) else buildLightScheme(themeAccent)
    val extendedColors = if (isDark) {
        ExtendedColors(
            success = StatusSuccessDark,
            successContainer = StatusSuccessContainerDark,
            warning = StatusWarningDark,
            warningContainer = StatusWarningContainerDark
        )
    } else {
        ExtendedColors(
            success = StatusSuccessLight,
            successContainer = StatusSuccessContainerLight,
            warning = StatusWarningLight,
            warningContainer = StatusWarningContainerLight
        )
    }

    CompositionLocalProvider(
        LocalExtendedColors provides extendedColors,
        LocalReduceMotion provides reduceMotion
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = PixelBoostTypography,
            shapes = PixelBoostShapes,
            content = content
        )
    }
}
