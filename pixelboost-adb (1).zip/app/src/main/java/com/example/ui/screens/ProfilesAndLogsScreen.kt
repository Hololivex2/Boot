package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ExecutionLogEntity
import com.example.data.SavedProfileEntity
import com.example.model.Android14TweakCatalog
import com.example.model.ExecutionStatus
import com.example.model.ThemeAccent
import com.example.model.ThemeMode
import com.example.model.TweakControlType
import com.example.ui.components.AdbCommandBox
import com.example.ui.components.ExpressiveConnectedButtonGroup
import com.example.ui.components.ExpressiveMorphingButton
import com.example.ui.components.ExpressiveMorphingExtendedFab
import com.example.ui.components.ExpressiveMorphingOutlinedButton
import com.example.ui.components.ExpressiveShapeIconBadge
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveEmphasizedType
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.LocalExtendedColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesAndLogsScreen(
    profiles: List<SavedProfileEntity>,
    recentLogs: List<ExecutionLogEntity>,
    themeMode: ThemeMode,
    themeAccent: ThemeAccent,
    confirmBeforeRun: Boolean,
    showCommandChips: Boolean,
    decodeSettings: (String) -> Map<String, String>,
    buildProfileScript: (SavedProfileEntity) -> String,
    onApplyProfile: (SavedProfileEntity) -> Unit,
    onCreateCustomProfile: (String, String, String, Map<String, String>) -> Unit,
    onDeleteCustomProfile: (Int) -> Unit,
    onClearLogs: () -> Unit,
    onRerunCommand: (String, String) -> Unit,
    onCopyCommand: (String, String) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onThemeAccentChange: (ThemeAccent) -> Unit,
    onConfirmBeforeRunChange: (Boolean) -> Unit,
    onShowCommandChipsChange: (Boolean) -> Unit,
    onOpenGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val ext = LocalExtendedColors.current
    val clipboard = LocalClipboardManager.current

    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreateProfileSheet by remember { mutableStateOf(false) }

    val subTabIndices = listOf(0, 1, 2)
    val subTabs = listOf("โปรไฟล์", "ประวัติคำสั่ง", "ตั้งค่า & คู่มือ")

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "โปรไฟล์และประวัติระบบ",
                    style = ExpressiveEmphasizedType.HeadlineEmphasized,
                    color = cs.onSurface
                )

                ExpressiveConnectedButtonGroup(
                    items = subTabIndices,
                    selectedItem = selectedTab,
                    labelProvider = { subTabs[it] },
                    onSelect = { selectedTab = it },
                    tagProvider = { "profiles_subtab_$it" }
                )
            }

            when (selectedTab) {
                0 -> {
                    LazyColumn(
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 92.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(profiles, key = { it.id }) { profile ->
                            val decoded = decodeSettings(profile.settingsJson)
                            val script = buildProfileScript(profile)
                            SavedProfileManageCard(
                                profile = profile,
                                itemCount = decoded.size,
                                onApply = { onApplyProfile(profile) },
                                onCopy = {
                                    clipboard.setText(AnnotatedString(script))
                                    onCopyCommand("โปรไฟล์ ${profile.name}", script)
                                },
                                onDelete = { onDeleteCustomProfile(profile.id) }
                            )
                        }
                    }
                }

                1 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "บันทึกล่าสุด (${recentLogs.size} รายการ)",
                                style = MaterialTheme.typography.titleSmall,
                                color = cs.onSurfaceVariant
                            )
                            if (recentLogs.isNotEmpty()) {
                                TextButton(
                                    onClick = onClearLogs,
                                    modifier = Modifier.testTag("clear_logs_button")
                                ) {
                                    Text("ล้างประวัติ")
                                }
                            }
                        }

                        if (recentLogs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ExpressiveShapeIconBadge(
                                        shape = ExpressiveGeometry.scallopCookie(lobes = 8),
                                        containerColor = cs.surfaceContainerHigh,
                                        size = 56.dp
                                    ) {
                                        Icon(
                                            Icons.Filled.History,
                                            contentDescription = null,
                                            tint = cs.onSurfaceVariant,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                    Text(
                                        text = "ยังไม่มีประวัติการปรับแต่งในเครื่อง",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = cs.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(recentLogs, key = { it.id }) { log ->
                                    val statusEnum = runCatching {
                                        ExecutionStatus.valueOf(log.status)
                                    }.getOrDefault(ExecutionStatus.SUCCESS)

                                    val (badgeBg, badgeFg) = when (statusEnum) {
                                        ExecutionStatus.SUCCESS -> ext.successContainer to ext.success
                                        ExecutionStatus.COPIED -> cs.tertiaryContainer to cs.onTertiaryContainer
                                        ExecutionStatus.FAILED -> cs.errorContainer to cs.error
                                    }

                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
                                        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = log.titleTh,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = cs.onSurface,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Surface(color = badgeBg, shape = CircleShape) {
                                                    Text(
                                                        text = statusEnum.labelTh,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = badgeFg,
                                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "${formatTimestamp(log.timestamp)} • ${log.outputMessage}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = cs.onSurfaceVariant
                                            )
                                            AdbCommandBox(
                                                command = log.command,
                                                onCopy = { onCopyCommand(log.titleTh, log.command) }
                                            )
                                            if (!log.command.contains("\n")) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.End
                                                ) {
                                                    TextButton(
                                                        onClick = { onRerunCommand(log.titleTh, log.command) }
                                                    ) {
                                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("รันคำสั่งซ้ำ")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
                            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "รูปแบบธีมสี (Material 3 Expressive)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = cs.onSurface
                                )
                                ExpressiveConnectedButtonGroup(
                                    items = ThemeMode.entries,
                                    selectedItem = themeMode,
                                    labelProvider = { it.labelTh },
                                    onSelect = onThemeModeChange,
                                    tagProvider = { "settings_theme_${it.name}" }
                                )

                                HorizontalDivider(color = cs.outlineVariant, modifier = Modifier.padding(vertical = 2.dp))

                                Text(
                                    text = "โทนสีหลักของแอป (ฟ้า / ม่วง / เขียว)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = cs.onSurface
                                )
                                ExpressiveConnectedButtonGroup(
                                    items = ThemeAccent.entries,
                                    selectedItem = themeAccent,
                                    labelProvider = { it.labelTh },
                                    onSelect = onThemeAccentChange,
                                    tagProvider = { "settings_accent_${it.name}" }
                                )
                            }
                        }

                        Card(
                            shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
                            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("ถามยืนยันก่อนรันคำสั่ง", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "แสดงป๊อปอัปตรวจสอบคำสั่งทุกครั้งก่อนส่งไปที่ Shizuku",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = cs.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = confirmBeforeRun,
                                        onCheckedChange = onConfirmBeforeRunChange,
                                        modifier = Modifier.testTag("settings_confirm_switch")
                                    )
                                }

                                HorizontalDivider(color = cs.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("แสดงปุ่มดูคำสั่ง ADB ในการ์ด", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "เปิดดูและคัดลอกคำสั่ง adb shell จริงได้จากการ์ดปรับแต่ง",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = cs.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = showCommandChips,
                                        onCheckedChange = onShowCommandChipsChange,
                                        modifier = Modifier.testTag("settings_cmd_preview_switch")
                                    )
                                }
                            }
                        }

                        Card(
                            shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
                            colors = CardDefaults.cardColors(containerColor = cs.surfaceContainer)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "เกี่ยวกับสิทธิ์ Shizuku และ Android 14",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = cs.onSurface
                                )
                                Text(
                                    text = "• แอปนี้ใช้ Shizuku UserService (UID 2000) ไม่จำเป็นต้องรูทเครื่อง\n" +
                                        "• คำสั่งทั้งหมดผ่านการคัดกรองให้ทำงานบน Android 14 (API 34+) ได้จริง\n" +
                                        "• โปรไฟล์และประวัติการปรับแต่งทั้งหมดถูกเก็บเป็นส่วนตัวในเครื่องของคุณเท่านั้น",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant
                                )
                                ExpressiveMorphingButton(
                                    onClick = onOpenGuide,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("settings_open_guide_button")
                                ) {
                                    Text("เปิดคู่มือเชื่อมต่อ Shizuku แบบละเอียด")
                                }
                            }
                        }
                    }
                }
            }
        }

        if (selectedTab == 0) {
            ExpressiveMorphingExtendedFab(
                text = "สร้างโปรไฟล์",
                icon = { Icon(Icons.Filled.Add, contentDescription = "สร้างโปรไฟล์ส่วนตัว") },
                onClick = { showCreateProfileSheet = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("create_custom_profile_fab")
            )
        }
    }

    if (showCreateProfileSheet) {
        CreateCustomProfileSheet(
            onDismiss = { showCreateProfileSheet = false },
            onSave = { name, desc, iconKey, map ->
                onCreateCustomProfile(name, desc, iconKey, map)
                showCreateProfileSheet = false
            }
        )
    }
}

@Composable
private fun SavedProfileManageCard(
    profile: SavedProfileEntity,
    itemCount: Int,
    onApply: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = profile.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = cs.onSurface
                        )
                        Surface(
                            color = if (profile.isBuiltIn) cs.tertiaryContainer else cs.secondaryContainer,
                            shape = CircleShape
                        ) {
                            Text(
                                text = if (profile.isBuiltIn) "แนะนำ" else "สร้างเอง",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (profile.isBuiltIn) cs.onTertiaryContainer else cs.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = profile.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }

                if (!profile.isBuiltIn) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("delete_profile_${profile.id}")
                    ) {
                        Icon(
                            Icons.Filled.DeleteOutline,
                            contentDescription = "ลบโปรไฟล์",
                            tint = cs.error
                        )
                    }
                }
            }

            if (profile.lastAppliedAt != null) {
                Text(
                    text = "ใช้งานล่าสุด: ${formatTimestamp(profile.lastAppliedAt)} • $itemCount การตั้งค่า",
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ExpressiveMorphingOutlinedButton(
                    onClick = onCopy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("คัดลอก")
                }
                ExpressiveMorphingButton(
                    onClick = onApply,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ใช้งาน ($itemCount)")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CreateCustomProfileSheet(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Map<String, String>) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cs = MaterialTheme.colorScheme

    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var iconKey by remember { mutableStateOf("smooth") }
    val selectedTweaks = remember {
        mutableStateMapOf(
            "window_animation_scale" to "0.5",
            "transition_animation_scale" to "0.5",
            "animator_duration_scale" to "0.5",
            "peak_refresh_rate" to "120.0",
            "cached_apps_freezer" to "enabled"
        )
    }

    val builderTweaks = remember {
        Android14TweakCatalog.allTweaks.filter {
            it.controlType is TweakControlType.ChoiceChips && it.settingKey != null
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = ExpressiveCorner.ExtraLarge, topEnd = ExpressiveCorner.ExtraLarge),
        containerColor = cs.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "สร้างโปรไฟล์ปรับแต่งส่วนตัว",
                style = MaterialTheme.typography.titleLarge,
                color = cs.onSurface
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("ชื่อโปรไฟล์ เช่น โหมดเล่น ROV / โหมดทำงาน") },
                singleLine = true,
                shape = RoundedCornerShape(ExpressiveCorner.Large),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_profile_name_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("คำอธิบายเพิ่มเติม (ไม่บังคับ)") },
                shape = RoundedCornerShape(ExpressiveCorner.Large),
                modifier = Modifier.fillMaxWidth()
            )

            Text("ไอคอนโปรไฟล์", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("gaming" to "เกมมิ่ง", "smooth" to "ลื่นไหล", "eco" to "ประหยัดไฟ").forEach { (key, label) ->
                    val selected = iconKey == key
                    FilterChip(
                        selected = selected,
                        onClick = { iconKey = key },
                        shape = if (selected) CircleShape else RoundedCornerShape(ExpressiveCorner.Medium),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primaryContainer,
                            selectedLabelColor = cs.onPrimaryContainer
                        ),
                        label = { Text(label) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                }
            }

            HorizontalDivider(color = cs.outlineVariant)

            Text("เลือกค่าที่ต้องการบันทึกไว้ในโปรไฟล์", style = MaterialTheme.typography.titleSmall)

            builderTweaks.forEach { tweak ->
                val options = (tweak.controlType as TweakControlType.ChoiceChips).options
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = tweak.titleTh,
                        style = MaterialTheme.typography.labelLarge,
                        color = cs.onSurface
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        options.forEach { opt ->
                            val selected = selectedTweaks[tweak.id] == opt.value
                            FilterChip(
                                selected = selected,
                                onClick = { selectedTweaks[tweak.id] = opt.value },
                                shape = if (selected) CircleShape else RoundedCornerShape(ExpressiveCorner.Medium),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = cs.primaryContainer,
                                    selectedLabelColor = cs.onPrimaryContainer
                                ),
                                label = { Text(opt.labelTh) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            )
                        }
                    }
                }
            }

            ExpressiveMorphingButton(
                onClick = {
                    if (name.isNotBlank() && selectedTweaks.isNotEmpty()) {
                        onSave(name, description, iconKey, selectedTweaks.toMap())
                    }
                },
                enabled = name.isNotBlank() && selectedTweaks.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_custom_profile_button")
            ) {
                Text("บันทึกโปรไฟล์ลงเครื่อง")
            }
        }
    }
}

private fun formatTimestamp(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
