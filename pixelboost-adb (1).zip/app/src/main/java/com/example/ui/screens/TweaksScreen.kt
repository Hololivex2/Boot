package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Android14TweakCatalog
import com.example.model.TweakCategory
import com.example.model.TweakControlType
import com.example.model.TweakDefinition
import com.example.ui.components.AdbCommandBox
import com.example.ui.components.ExpressiveMorphingButton
import com.example.ui.components.ExpressivePillSearchBar
import com.example.ui.components.ExpressiveShapeIconBadge
import com.example.ui.components.SafetyBadge
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.ExpressiveEmphasizedType
import com.example.ui.theme.ExpressiveGeometry
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.LocalReduceMotion

private data class PendingConfirmation(
    val tweak: TweakDefinition,
    val value: String,
    val command: String
)

@Composable
fun TweaksScreen(
    selectedCategory: TweakCategory,
    searchQuery: String,
    tweakValues: Map<String, String>,
    confirmBeforeRun: Boolean,
    showCommandChips: Boolean,
    onCategorySelected: (TweakCategory) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onApplyTweak: (TweakDefinition, String, String) -> Unit,
    onRevertTweak: (TweakDefinition) -> Unit,
    onCopyCommand: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    var pendingConfirm by remember { mutableStateOf<PendingConfirmation?>(null) }

    val filteredTweaks = remember(selectedCategory, searchQuery) {
        Android14TweakCatalog.allTweaks.filter { tweak ->
            val matchCat = selectedCategory == TweakCategory.ALL || tweak.category == selectedCategory
            val q = searchQuery.trim()
            val matchQuery = q.isEmpty() ||
                tweak.titleTh.contains(q, ignoreCase = true) ||
                tweak.descriptionTh.contains(q, ignoreCase = true) ||
                tweak.benefitTagTh.contains(q, ignoreCase = true) ||
                (tweak.settingKey?.contains(q, ignoreCase = true) == true)
            matchCat && matchQuery
        }
    }

    val dispatchTweak: (TweakDefinition, String, String) -> Unit = { tweak, value, cmd ->
        if (confirmBeforeRun) {
            pendingConfirm = PendingConfirmation(tweak, value, cmd)
        } else {
            onApplyTweak(tweak, value, cmd)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ExpressiveShapeIconBadge(
                        shape = ExpressiveGeometry.Squircle,
                        containerColor = cs.primaryContainer,
                        size = 42.dp
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = null,
                            tint = cs.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "ฟังก์ชันปรับแต่ง Android 14",
                            style = ExpressiveEmphasizedType.HeadlineEmphasized,
                            color = cs.onSurface
                        )
                        Text(
                            text = "ทั้งหมด ${Android14TweakCatalog.allTweaks.size} รายการ • ปรับค่าผ่าน Shizuku UID 2000",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                }

                ExpressivePillSearchBar(
                    query = searchQuery,
                    onQueryChange = onSearchQueryChange,
                    placeholder = "ค้นหาเมนู เช่น CPU, Vulkan, MSAA, แอนิเมชัน, DNS...",
                    testTag = "tweaks_search_input"
                )
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TweakCategory.entries) { category ->
                    val selected = selectedCategory == category
                    val chipCorner by animateDpAsState(
                        targetValue = if (selected) ExpressiveCorner.ExtraLarge else ExpressiveCorner.Medium,
                        animationSpec = ExpressiveMotion.standardSpatialFast(reduceMotion),
                        label = "catChipCorner"
                    )
                    FilterChip(
                        selected = selected,
                        onClick = { onCategorySelected(category) },
                        shape = RoundedCornerShape(chipCorner),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primaryContainer,
                            selectedLabelColor = cs.onPrimaryContainer,
                            containerColor = cs.surfaceContainerLow
                        ),
                        label = {
                            Text(
                                category.labelTh,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("category_chip_${category.name}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (filteredTweaks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ไม่พบฟังก์ชันที่ตรงกับคำค้นหา \"$searchQuery\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = cs.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredTweaks, key = { it.id }) { tweak ->
                        val currentValue = tweakValues[tweak.id] ?: tweak.defaultValue
                        TweakItemCard(
                            tweak = tweak,
                            currentValue = currentValue,
                            showCommandPreviewByDefault = showCommandChips,
                            onSelectOption = { value, cmd -> dispatchTweak(tweak, value, cmd) },
                            onRevert = { onRevertTweak(tweak) },
                            onCopy = { cmd -> onCopyCommand(tweak.titleTh, cmd) }
                        )
                    }
                }
            }
        }
    }

    pendingConfirm?.let { pending ->
        AlertDialog(
            onDismissRequest = { pendingConfirm = null },
            shape = RoundedCornerShape(ExpressiveCorner.ExtraLarge),
            containerColor = cs.surfaceContainerHigh,
            title = { Text("ยืนยันการปรับแต่ง") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ต้องการรันคำสั่งสำหรับ \"${pending.tweak.titleTh}\" หรือไม่?")
                    Surface(
                        color = cs.surfaceContainerHighest,
                        shape = RoundedCornerShape(ExpressiveCorner.Large),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = pending.command,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onApplyTweak(pending.tweak, pending.value, pending.command)
                        pendingConfirm = null
                    },
                    modifier = Modifier.testTag("confirm_run_tweak_button")
                ) {
                    Text("รันคำสั่ง")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingConfirm = null }) {
                    Text("ยกเลิก")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TweakItemCard(
    tweak: TweakDefinition,
    currentValue: String,
    showCommandPreviewByDefault: Boolean,
    onSelectOption: (String, String) -> Unit,
    onRevert: () -> Unit,
    onCopy: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val reduceMotion = LocalReduceMotion.current
    var showCommand by remember { mutableStateOf(false) }

    val activeCommand = remember(tweak, currentValue) {
        when (val control = tweak.controlType) {
            is TweakControlType.ChoiceChips ->
                control.options.firstOrNull { it.value == currentValue }?.command
                    ?: control.options.first().command
            is TweakControlType.ToggleSwitch ->
                if (currentValue == control.onValue) control.onCommand else control.offCommand
            is TweakControlType.ActionButton -> control.command
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tweak_card_${tweak.id}"),
        shape = RoundedCornerShape(ExpressiveCorner.LargeIncreased),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceContainerLow),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    SafetyBadge(level = tweak.safetyLevel)
                    Surface(
                        color = cs.surfaceContainerHigh,
                        shape = CircleShape
                    ) {
                        Text(
                            text = tweak.benefitTagTh,
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                if (showCommandPreviewByDefault) {
                    Surface(
                        shape = CircleShape,
                        color = if (showCommand) cs.primaryContainer else cs.surfaceContainerHigh
                    ) {
                        IconButton(
                            onClick = { showCommand = !showCommand },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("toggle_cmd_${tweak.id}")
                        ) {
                            Icon(
                                Icons.Filled.Code,
                                contentDescription = "แสดงคำสั่ง ADB",
                                tint = if (showCommand) cs.onPrimaryContainer else cs.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = tweak.titleTh,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.onSurface
                )
                Text(
                    text = tweak.descriptionTh,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }

            when (val control = tweak.controlType) {
                is TweakControlType.ChoiceChips -> {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        control.options.forEach { option ->
                            val selected = currentValue == option.value
                            val corner by animateDpAsState(
                                targetValue = if (selected) ExpressiveCorner.ExtraLarge else ExpressiveCorner.Medium,
                                animationSpec = ExpressiveMotion.standardSpatialFast(reduceMotion),
                                label = "optCorner"
                            )
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectOption(option.value, option.command) },
                                shape = RoundedCornerShape(corner),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = cs.primaryContainer,
                                    selectedLabelColor = cs.onPrimaryContainer,
                                    containerColor = cs.surfaceContainer
                                ),
                                label = {
                                    Text(
                                        option.labelTh,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("tweak_option_${tweak.id}_${option.value}")
                            )
                        }
                    }
                }

                is TweakControlType.ToggleSwitch -> {
                    val isOn = currentValue == control.onValue
                    Surface(
                        shape = RoundedCornerShape(ExpressiveCorner.Large),
                        color = if (isOn) cs.primaryContainer.copy(alpha = 0.45f) else cs.surfaceContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isOn) control.onLabelTh else control.offLabelTh,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isOn) FontWeight.SemiBold else FontWeight.Normal,
                                color = cs.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Switch(
                                checked = isOn,
                                onCheckedChange = { checked ->
                                    val targetVal = if (checked) control.onValue else control.offValue
                                    val cmd = if (checked) control.onCommand else control.offCommand
                                    onSelectOption(targetVal, cmd)
                                },
                                modifier = Modifier.testTag("tweak_switch_${tweak.id}")
                            )
                        }
                    }
                }

                is TweakControlType.ActionButton -> {
                    ExpressiveMorphingButton(
                        onClick = { onSelectOption("action", control.command) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tweak_action_btn_${tweak.id}")
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(control.buttonLabelTh)
                    }
                }
            }

            if (tweak.revertCommand != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onRevert,
                        modifier = Modifier.testTag("revert_tweak_${tweak.id}")
                    ) {
                        Icon(
                            Icons.Filled.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("คืนค่าเริ่มต้น (${tweak.defaultValue})")
                    }
                }
            }

            AnimatedVisibility(visible = showCommand) {
                AdbCommandBox(
                    command = activeCommand,
                    onCopy = onCopy
                )
            }
        }
    }
}
