package com.example.model

enum class AppSafetyRisk(val labelTh: String) {
    SAFE_BLOATWARE("แนะนำปิดได้ • ปลอดภัย"),
    OPTIONAL("ตรวจสอบก่อนปิด"),
    SYSTEM_CRITICAL("ระบบสำคัญ • ห้ามปิด")
}

data class BloatwareAdvice(
    val risk: AppSafetyRisk,
    val reasonTh: String
)

object BloatwareAdvisor {

    private val knownSafeBloatware: Map<String, String> = mapOf(
        "com.facebook.system" to "บริการติดตั้ง/อัปเดต Facebook เบื้องหลัง (ปิดได้ ปลอดภัย 100%)",
        "com.facebook.appmanager" to "ตัวจัดการอัปเดตแอปเครือ Meta เบื้องหลัง (ปิดได้ ปลอดภัย)",
        "com.facebook.services" to "บริการเบื้องหลังของ Facebook (ปิดได้ ช่วยลดแบตไหล)",
        "com.facebook.katana" to "แอป Facebook ที่ติดตั้งมากับเครื่อง (แช่แข็งได้หากไม่ใช้)",
        "com.google.android.feedback" to "ตัวส่งรายงานข้อผิดพลาด Google Feedback (ปิดได้ ปลอดภัย)",
        "com.google.android.partnersetup" to "ตัวช่วยตั้งค่าเริ่มต้นจากพาร์ทเนอร์ (ปิดได้หลังตั้งค่าเครื่องแล้ว)",
        "com.google.android.printservice.recommendation" to "บริการค้นหาเครื่องพิมพ์เบื้องหลัง (ปิดได้หากไม่ใช้เครื่องพิมพ์)",
        "com.android.printspooler" to "บริการคิวพิมพ์เอกสาร (ปิดได้หากไม่สั่งพิมพ์จากมือถือ)",
        "com.android.bips" to "บริการพิมพ์พื้นฐาน Built-in Print Service (ปิดได้หากไม่ใช้)",
        "com.android.retaildemo" to "โหมดสาธิตหน้าร้าน Retail Demo (ปิดได้ ปลอดภัย 100%)",
        "com.android.bookmarkprovider" to "ตัวเก็บ Bookmark เบื้องหลังแบบเก่า (ปิดได้ ปลอดภัย)",
        "com.android.egg" to "อีสเตอร์เอ้กเวอร์ชัน Android (ปิดได้ ปลอดภัย)",
        "com.android.wallpaper.livepicker" to "ตัวเลือกวอลเปเปอร์เคลื่อนไหวพื้นฐาน (ปิดได้หากใช้วอลเปเปอร์ภาพนิ่ง)",
        "com.google.android.videos" to "Google TV / Play Movies (แช่แข็งได้หากไม่รับชม)",
        "com.google.android.music" to "Play Music เก่า (ปิดได้ ปลอดภัย 100%)",
        "com.google.android.apps.magazines" to "Google News / Magazines (แช่แข็งได้หากไม่อ่าน)",
        "com.google.android.apps.tachyon" to "Google Meet / Duo ที่ติดเครื่อง (แช่แข็งได้หากไม่ใช้)",
        "com.google.android.play.games" to "Google Play Games (แช่แข็งได้หากไม่ซิงก์ความสำเร็จเกม)",
        "com.google.android.apps.wellbeing" to "Digital Wellbeing (แช่แข็งได้ ช่วยลดการติดตามเวลาใช้งาน)",
        "com.google.android.projection.gearhead" to "Android Auto (แช่แข็งได้หากไม่ได้เชื่อมต่อรถยนต์)",
        "com.google.android.apps.youtube.music" to "YouTube Music ติดเครื่อง (แช่แข็งได้หากใช้แอปฟังเพลงอื่น)",
        "com.miui.analytics" to "ตัวเก็บสถิติ/โฆษณา Xiaomi Analytics (แนะนำให้ปิด)",
        "com.miui.msa.global" to "ระบบแสดงโฆษณา MIUI System Ads (แนะนำให้ปิด)",
        "com.miui.daemon" to "ตัวส่งข้อมูลระบบ Xiaomi Daemon (ปิดได้ ปลอดภัย)",
        "com.xiaomi.mipicks" to "GetApps Store (แช่แข็งได้หากใช้ Play Store หลัก)",
        "com.samsung.android.bixby.agent" to "ผู้ช่วยเสียง Bixby (แช่แข็งได้หากไม่ใช้งาน)",
        "com.samsung.android.bixby.wakeup" to "ระบบปลุก Bixby ด้วยเสียง (แช่แข็งได้ ช่วยประหยัดแบต)",
        "com.samsung.android.rubin.app" to "Customization Service วิเคราะห์พฤติกรรม (ปิดได้ ปลอดภัย)",
        "com.samsung.android.game.gametools" to "Samsung Game Booster (ปิดได้หากต้องการรันเกมแบบดิบ)",
        "com.samsung.android.app.spage" to "หน้าข่าว Samsung Free / Daily (ปิดได้ ปลอดภัย)",
        "com.coloros.athena" to "ตัวจัดการเบื้องหลังของ ColorOS (ระวัง: ปิดเฉพาะเมื่อตั้งค่าเอง)",
        "com.heytap.browser" to "เบราว์เซอร์ติดเครื่อง HeyTap (แช่แข็งได้หากใช้ Chrome)",
        "com.heytap.market" to "App Market ติดเครื่อง (แช่แข็งได้หากใช้ Play Store)"
    )

    private val safeBloatwarePrefixes = listOf(
        "com.facebook.",
        "com.netflix.partner.",
        "com.spotify.music",
        "com.booking",
        "com.agoda",
        "com.lazada",
        "com.shopee",
        "com.tiktok",
        "com.zhiliaoapp.musically",
        "com.samsung.android.bixby",
        "com.samsung.android.kids",
        "com.samsung.android.ar",
        "com.miui.analytics",
        "com.miui.msa",
        "com.heytap.pictorial",
        "com.coloros.gamespace",
        "com.oppo.quicksearchbox",
        "com.vivo.appstore",
        "com.vivo.browser"
    )

    private val criticalExactPackages = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.shell",
        "com.android.keychain",
        "com.android.externalstorage",
        "com.android.documentsui",
        "com.google.android.documentsui",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending",
        "com.android.webview",
        "com.google.android.webview",
        "moe.shizuku.privileged.api"
    )

    private val criticalPrefixes = listOf(
        "com.android.providers.",
        "com.android.networkstack",
        "com.google.android.networkstack",
        "com.android.wifi",
        "com.google.android.wifi",
        "com.android.inputmethod",
        "com.google.android.inputmethod",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.sec.android.app.launcher",
        "com.miui.home"
    )

    fun evaluate(packageName: String, isSystemApp: Boolean): BloatwareAdvice {
        if (packageName in criticalExactPackages ||
            criticalPrefixes.any { packageName.startsWith(it) }
        ) {
            return BloatwareAdvice(
                risk = AppSafetyRisk.SYSTEM_CRITICAL,
                reasonTh = "องค์ประกอบหลักของระบบ Android หรือบริการสำคัญ ห้ามแช่แข็ง"
            )
        }

        knownSafeBloatware[packageName]?.let { reason ->
            return BloatwareAdvice(
                risk = AppSafetyRisk.SAFE_BLOATWARE,
                reasonTh = reason
            )
        }

        if (safeBloatwarePrefixes.any { packageName.startsWith(it) }) {
            return BloatwareAdvice(
                risk = AppSafetyRisk.SAFE_BLOATWARE,
                reasonTh = "แอปเสริมหรือบริการพาร์ทเนอร์ที่มักติดมากับเครื่อง ปิด/แช่แข็งได้อย่างปลอดภัย"
            )
        }

        return if (isSystemApp) {
            BloatwareAdvice(
                risk = AppSafetyRisk.OPTIONAL,
                reasonTh = "แอประบบทั่วไป — ตรวจสอบหน้าที่ของแอปให้แน่ใจก่อนแช่แข็ง"
            )
        } else {
            BloatwareAdvice(
                risk = AppSafetyRisk.OPTIONAL,
                reasonTh = "แอปที่ติดตั้งเพิ่มเติม — สามารถจำกัดเบื้องหลังหรือแช่แข็งได้"
            )
        }
    }
}
