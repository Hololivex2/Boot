package com.example.model

import kotlinx.serialization.Serializable

enum class ShizukuConnectionState {
    NOT_INSTALLED,
    NOT_RUNNING,
    PERMISSION_REQUIRED,
    CONNECTING,
    CONNECTED,
    ERROR
}

enum class ThemeMode(val labelTh: String) {
    SYSTEM("ตามระบบ"),
    LIGHT("สว่าง"),
    DARK("มืด")
}

enum class ThemeAccent(val labelTh: String) {
    BLUE("ฟ้า"),
    PURPLE("ม่วง"),
    GREEN("เขียว")
}

enum class AppFilter(val labelTh: String) {
    USER("แอปทั่วไป"),
    BLOATWARE("แนะนำให้ปิด (Bloatware)"),
    GAMES("เกมที่ติดตั้ง"),
    ALL("ทั้งหมด (รวมระบบ)"),
    DISABLED("แอปที่ถูกแช่แข็ง")
}

enum class CpuGpuPresetMode(val labelTh: String, val subtitleTh: String) {
    SHARP_VISUALS("ภาพสวย", "เต็มจอคมชัด • Skia Vulkan • 4x MSAA • 120Hz"),
    SMOOTH_FPS("เล่นลื่น", "CPU Fixed Perf • Game Driver • 0.25x • Freezer"),
    BALANCED("สมดุล", "ความละเอียดเดิม • 0.5x Anim • ประหยัดพลังอัตโนมัติ")
}

enum class TweakCategory(val labelTh: String) {
    ALL("ทั้งหมด"),
    CPU_PERFORMANCE("CPU และประสิทธิภาพ"),
    GPU_GRAPHICS("GPU และกราฟิก"),
    DISPLAY_ANIMATION("หน้าจอและแอนิเมชัน"),
    GAME_RUNTIME("เกมและ ART"),
    BACKGROUND_DEBLOAT("เบื้องหลังและแคช"),
    NETWORK_DNS("เครือข่ายและ DNS"),
    BATTERY_DOZE("แบตเตอรี่และ Doze")
}

enum class SafetyLevel(val labelTh: String) {
    SAFE_100("ปลอดภัย 100%"),
    ANDROID_14_VERIFIED("Android 14 รับรอง"),
    CAUTION("ใช้ตามความเหมาะสม")
}

data class TweakOption(
    val value: String,
    val labelTh: String,
    val hintTh: String,
    val command: String
)

sealed class TweakControlType {
    data class ChoiceChips(val options: List<TweakOption>) : TweakControlType()
    data class ToggleSwitch(
        val onValue: String,
        val offValue: String,
        val onLabelTh: String,
        val offLabelTh: String,
        val onCommand: String,
        val offCommand: String
    ) : TweakControlType()
    data class ActionButton(
        val buttonLabelTh: String,
        val command: String
    ) : TweakControlType()
}

data class TweakDefinition(
    val id: String,
    val titleTh: String,
    val descriptionTh: String,
    val benefitTagTh: String,
    val category: TweakCategory,
    val safetyLevel: SafetyLevel,
    val settingNamespace: String?,
    val settingKey: String?,
    val defaultValue: String,
    val revertCommand: String?,
    val controlType: TweakControlType
)

data class DeviceTelemetry(
    val deviceModel: String = "",
    val manufacturer: String = "",
    val androidRelease: String = "",
    val sdkInt: Int = 0,
    val totalRamGb: Float = 0f,
    val availableRamGb: Float = 0f,
    val batteryLevel: Int = 0,
    val batteryTempC: Float = 0f,
    val isCharging: Boolean = false,
    val currentRefreshRateHz: Int = 60,
    val maxSupportedRefreshRateHz: Int = 60,
    val resolutionText: String = "",
    val windowAnimationScale: String = "-",
    val transitionAnimationScale: String = "-",
    val animatorDurationScale: String = "-",
    val privateDnsMode: String = "-",
    val privateDnsHost: String = "-",
    val cachedAppsFreezer: String = "-"
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isSystemApp: Boolean,
    val isGame: Boolean,
    val isEnabled: Boolean,
    val safetyRisk: AppSafetyRisk = AppSafetyRisk.OPTIONAL,
    val adviceTh: String = ""
)

enum class ExecutionStatus(val labelTh: String) {
    SUCCESS("สำเร็จ"),
    COPIED("คัดลอกคำสั่ง"),
    FAILED("ไม่สำเร็จ")
}

@Serializable
data class ProfileTweakPayload(
    val settings: Map<String, String> = emptyMap()
)

data class ShellExecutionResult(
    val success: Boolean,
    val exitCode: Int,
    val stdout: String,
    val stderr: String
)
