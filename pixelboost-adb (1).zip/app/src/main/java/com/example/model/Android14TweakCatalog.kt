package com.example.model

object Android14TweakCatalog {

    val allTweaks: List<TweakDefinition> = listOf(
        // ==================== CPU & ประสิทธิภาพ ====================
        TweakDefinition(
            id = "cpu_fixed_performance",
            titleTh = "CPU/GPU Fixed Performance Mode (เร่งคล็อกคงที่)",
            descriptionTh = "ฟีเจอร์ทางการของ Android 14 สั่ง PowerManager ล็อกระดับความถี่ CPU และ GPU ให้อยู่ในย่านประสิทธิภาพสูงคงที่ ลดอาการเฟรมกระตุกเวลาเล่นเกม",
            benefitTagTh = "เล่นลื่น FPS นิ่ง",
            category = TweakCategory.CPU_PERFORMANCE,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "false",
            revertCommand = "cmd power set-fixed-performance-mode-enabled false",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "true",
                offValue = "false",
                onLabelTh = "เปิด Fixed Performance (แรงคงที่)",
                offLabelTh = "ปิด (ปรับคล็อกอัตโนมัติ)",
                onCommand = "cmd power set-fixed-performance-mode-enabled true",
                offCommand = "cmd power set-fixed-performance-mode-enabled false"
            )
        ),
        TweakDefinition(
            id = "cpu_adaptive_power_saver",
            titleTh = "ควบคุม Adaptive Power Saver (ไม่ดรอปคล็อกอัตโนมัติ)",
            descriptionTh = "ปิดการลดประสิทธิภาพ CPU อัตโนมัติเมื่อแบตลดหรือใช้งานต่อเนื่อง ช่วยให้เกมไม่หน่วงกลางแมตช์",
            benefitTagTh = "กันคล็อกตก",
            category = TweakCategory.CPU_PERFORMANCE,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "true",
            revertCommand = "cmd power set-adaptive-power-saver-enabled true",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "false",
                offValue = "true",
                onLabelTh = "ปิดการดรอปไฟ (เน้นแรง)",
                offLabelTh = "เปิดอัตโนมัติ (ประหยัดแบต)",
                onCommand = "cmd power set-adaptive-power-saver-enabled false",
                offCommand = "cmd power set-adaptive-power-saver-enabled true"
            )
        ),
        TweakDefinition(
            id = "cpu_max_cached_processes",
            titleTh = "จำกัดจำนวนแอปพักใน RAM (ลดภาระ CPU)",
            descriptionTh = "ควบคุมจำนวนโปรเซสเบื้องหลังสูงสุดผ่าน device_config ของ Android 14 เหลือพื้นที่ CPU/RAM ให้เกมเต็มที่",
            benefitTagTh = "เหลือ CPU ให้เกม",
            category = TweakCategory.CPU_PERFORMANCE,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "auto",
            revertCommand = "device_config delete activity_manager max_cached_processes",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("12", "12 แอป (เกมมิ่ง)", "กัน RAM ไว้สูงสุด", "device_config put activity_manager max_cached_processes 12"),
                    TweakOption("24", "24 แอป (สมดุล)", "สลับแอปไว + ลื่น", "device_config put activity_manager max_cached_processes 24"),
                    TweakOption("32", "32 แอป (มัลติทาสก์)", "เปิดหลายแอปพร้อมกัน", "device_config put activity_manager max_cached_processes 32"),
                    TweakOption("auto", "ค่าเริ่มต้นระบบ", "ปล่อยให้ระบบจัดการ", "device_config delete activity_manager max_cached_processes")
                )
            )
        ),
        TweakDefinition(
            id = "cpu_stay_awake_usb",
            titleTh = "คงจอสว่างขณะเสียบชาร์จเล่นเกม/ทดสอบ",
            descriptionTh = "ป้องกันหน้าจอหรี่หรือพักเมื่อเสียบสายชาร์จ ช่วยรักษาความต่อเนื่องขณะทดสอบหรือเปิดบอทเกม",
            benefitTagTh = "ไม่พักจอขณะชาร์จ",
            category = TweakCategory.CPU_PERFORMANCE,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "stay_on_while_plugged_in",
            defaultValue = "0",
            revertCommand = "settings put global stay_on_while_plugged_in 0",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "3",
                offValue = "0",
                onLabelTh = "เปิดจอค้างขณะชาร์จ",
                offLabelTh = "ปิด (พักจอตามปกติ)",
                onCommand = "settings put global stay_on_while_plugged_in 3",
                offCommand = "settings put global stay_on_while_plugged_in 0"
            )
        ),
        // ==================== GPU & กราฟิก ====================
        TweakDefinition(
            id = "gpu_updatable_driver",
            titleTh = "เลือกไดรเวอร์กราฟิก GPU (Game Driver)",
            descriptionTh = "สลับใช้ Game Driver ที่อัปเดตล่าสุดสำหรับการเรนเดอร์ 3D ช่วยรีดเฟรมเรตและลดอาการกระตุกในเกม",
            benefitTagTh = "เล่นลื่น + ภาพคม",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = "global",
            settingKey = "updatable_driver_all_apps",
            defaultValue = "0",
            revertCommand = "settings put global updatable_driver_all_apps 0",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("1", "Game Driver (แนะนำ)", "รีด FPS เกม 3D เต็มที่", "settings put global updatable_driver_all_apps 1"),
                    TweakOption("2", "Developer Driver", "ไดรเวอร์ทดสอบล่าสุด", "settings put global updatable_driver_all_apps 2"),
                    TweakOption("0", "System Default", "ค่ามาตรฐานโรงงาน", "settings put global updatable_driver_all_apps 0")
                )
            )
        ),
        TweakDefinition(
            id = "gpu_hwui_renderer",
            titleTh = "เอนจินเรนเดอร์ GPU (Skia Vulkan / OpenGL)",
            descriptionTh = "เลือก Pipeline การวาดกราฟิก: Skia Vulkan ให้สีสันและเงาเนียนลื่นบนชิปรุ่นใหม่ ส่วน Skia OpenGL เสถียรกับเกมเก่า",
            benefitTagTh = "ภาพสวย / เสถียร",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "skiavk",
            revertCommand = "setprop debug.hwui.renderer skiagl",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("skiavk", "Skia Vulkan (ภาพสวย+ลื่น)", "ประมวลผล GPU ขนานไวขึ้น", "setprop debug.hwui.renderer skiavk"),
                    TweakOption("skiagl", "Skia OpenGL", "เข้ากันได้กับทุกแอป", "setprop debug.hwui.renderer skiagl"),
                    TweakOption("skiaglthreaded", "Threaded OpenGL", "กระจายเธรดวาด UI", "setprop debug.hwui.renderer skiaglthreaded")
                )
            )
        ),
        TweakDefinition(
            id = "gpu_force_msaa",
            titleTh = "บังคับลบรอยหยัก 4x MSAA (ภาพสวยคมชัด)",
            descriptionTh = "เปิด 4x Multi-Sample Anti-Aliasing ให้ขอบวัตถุในเกม OpenGL ES 2.0/3.0 เนียนคมกริบ (หากต้องการ FPS สูงสุดแนะนำให้ปิด)",
            benefitTagTh = "ภาพสวยคมกริบ",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "false",
            revertCommand = "setprop debug.egl.force_msaa false",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "true",
                offValue = "false",
                onLabelTh = "เปิด 4x MSAA (ภาพสวยสุด)",
                offLabelTh = "ปิด (ประหยัด GPU / FPS สูง)",
                onCommand = "setprop debug.egl.force_msaa true",
                offCommand = "setprop debug.egl.force_msaa false"
            )
        ),
        TweakDefinition(
            id = "gpu_angle_driver",
            titleTh = "ANGLE OpenGL-on-Vulkan Driver",
            descriptionTh = "แปลงคำสั่ง OpenGL ES ให้วิ่งผ่าน Vulkan API ช่วยลดคอขวดไดรเวอร์เก่าบน Android 14",
            benefitTagTh = "ลดคอขวด GPU",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = "global",
            settingKey = "angle_gl_driver_all_angle",
            defaultValue = "0",
            revertCommand = "settings put global angle_gl_driver_all_angle 0",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "1",
                offValue = "0",
                onLabelTh = "เปิด ANGLE Vulkan Bridge",
                offLabelTh = "ปิด (ใช้ Native GL)",
                onCommand = "settings put global angle_gl_driver_all_angle 1",
                offCommand = "settings put global angle_gl_driver_all_angle 0"
            )
        ),
        TweakDefinition(
            id = "gpu_sf_latch_unsignaled",
            titleTh = "SurfaceFlinger Fast Frame Latch (ลดหน่วงภาพ)",
            descriptionTh = "ลดเวลาการรอ VSync ของบัฟเฟอร์ภาพ ช่วยให้ภาพตอบสนองนิ้วไวขึ้นและลด Micro-Stutter",
            benefitTagTh = "ลด Input Lag",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "0",
            revertCommand = "setprop debug.sf.latch_unsignaled 0",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "1",
                offValue = "0",
                onLabelTh = "เปิด Fast Frame Latch",
                offLabelTh = "ค่ามาตรฐาน VSync",
                onCommand = "setprop debug.sf.latch_unsignaled 1",
                offCommand = "setprop debug.sf.latch_unsignaled 0"
            )
        ),
        TweakDefinition(
            id = "gpu_hw_overlays",
            titleTh = "บังคับรวมภาพผ่าน GPU ตลอดเวลา (Disable HW Overlays)",
            descriptionTh = "ให้ GPU รับหน้าที่รวมเลเยอร์หน้าจอทั้งหมด ป้องกันภาพสั่นหรือสีเพี้ยนในบางแอป/เกม (กินแบตเพิ่มเล็กน้อย)",
            benefitTagTh = "ภาพนิ่งไม่เพี้ยน",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "0",
            revertCommand = "service call SurfaceFlinger 1008 i32 0",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "1",
                offValue = "0",
                onLabelTh = "ใช้ GPU Composite เสมอ",
                offLabelTh = "ปล่อยระบบเลือกอัตโนมัติ",
                onCommand = "service call SurfaceFlinger 1008 i32 1",
                offCommand = "service call SurfaceFlinger 1008 i32 0"
            )
        ),
        TweakDefinition(
            id = "gpu_screen_resolution",
            titleTh = "ความละเอียดหน้าจอทั้งระบบ (Resolution Scale)",
            descriptionTh = "เลือกความละเอียดเต็มจอเดิมเพื่อ 'ภาพสวยคมชัด' หรือปรับลดลงเพื่อ 'เล่นลื่น FPS สูงและเครื่องเย็นลง'",
            benefitTagTh = "ภาพสวย / ลดภาระ GPU",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "native",
            revertCommand = "wm size reset",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("native", "เต็มจอเดิม (ภาพสวย)", "คมชัดสูงสุดตามสเปกจอ", "wm size reset"),
                    TweakOption("1080x2400", "FHD+ (1080p)", "สมดุลคมชัดและลื่น", "wm size 1080x2400"),
                    TweakOption("720x1600", "HD+ (720p เล่นลื่น)", "ลดภาระ GPU ~50% เฟรมนิ่ง", "wm size 720x1600")
                )
            )
        ),
        TweakDefinition(
            id = "gpu_screen_dpi",
            titleTh = "ปรับสเกลความคมชัดพื้นที่จอ (Display DPI)",
            descriptionTh = "ปรับขนาดไอคอนและตัวอักษรทั้งระบบ ค่า DPI น้อยลงจะเห็นพื้นที่กว้างขึ้นคมขึ้น (กดคืนค่าเดิมได้ทันที)",
            benefitTagTh = "ปรับมุมมองจอ",
            category = TweakCategory.GPU_GRAPHICS,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "reset",
            revertCommand = "wm density reset",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("reset", "ค่าเริ่มต้นโรงงาน", "คืนค่า DPI เดิม", "wm density reset"),
                    TweakOption("380", "380 DPI (คม/พื้นที่กว้าง)", "เห็นเนื้อหาเยอะขึ้น", "wm density 380"),
                    TweakOption("420", "420 DPI (สมดุล Pixel)", "พอดีสายตา", "wm density 420"),
                    TweakOption("480", "480 DPI (ตัวใหญ่)", "อ่านง่ายเต็มตา", "wm density 480")
                )
            )
        ),
        // ==================== หน้าจอและแอนิเมชัน ====================
        TweakDefinition(
            id = "window_animation_scale",
            titleTh = "ความเร็วแอนิเมชันหน้าต่าง",
            descriptionTh = "ลดระยะเวลาการเปิด-ปิดหน้าต่างและป๊อปอัป ช่วยให้สลับหน้าจอดูเร็วและฉับไวขึ้นทันที",
            benefitTagTh = "หน้าจอลื่นไวขึ้น",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "window_animation_scale",
            defaultValue = "1.0",
            revertCommand = "settings put global window_animation_scale 1.0",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("0.0", "0x (ปิด)", "เปิดปุ๊บติดปั๊บ", "settings put global window_animation_scale 0"),
                    TweakOption("0.25", "0.25x", "ไวมากแต่ยังนุ่มนวล", "settings put global window_animation_scale 0.25"),
                    TweakOption("0.5", "0.5x", "สมดุลยอดนิยม", "settings put global window_animation_scale 0.5"),
                    TweakOption("1.0", "1.0x (ปกติ)", "ค่าเริ่มต้นโรงงาน", "settings put global window_animation_scale 1.0")
                )
            )
        ),
        TweakDefinition(
            id = "transition_animation_scale",
            titleTh = "ความเร็วแอนิเมชันเปลี่ยนหน้า",
            descriptionTh = "ปรับจังหวะการสไลด์เปลี่ยนหน้าระหว่างเมนูหรือเปิดแอปให้กระชับ ไม่หน่วงสายตา",
            benefitTagTh = "เปิดแอปไวขึ้น",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "transition_animation_scale",
            defaultValue = "1.0",
            revertCommand = "settings put global transition_animation_scale 1.0",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("0.0", "0x (ปิด)", "เปลี่ยนหน้าทันที", "settings put global transition_animation_scale 0"),
                    TweakOption("0.25", "0.25x", "ลื่นกระชับ", "settings put global transition_animation_scale 0.25"),
                    TweakOption("0.5", "0.5x", "สมดุลและเนียนตา", "settings put global transition_animation_scale 0.5"),
                    TweakOption("1.0", "1.0x (ปกติ)", "ค่าเริ่มต้นโรงงาน", "settings put global transition_animation_scale 1.0")
                )
            )
        ),
        TweakDefinition(
            id = "animator_duration_scale",
            titleTh = "ความเร็วตัวเคลื่อนไหวระบบ",
            descriptionTh = "คุมความเร็วเอฟเฟกต์ปุ่มกด ตัวโหลด และแอนิเมชัน Material ของ Android 14",
            benefitTagTh = "UI ตอบสนองไว",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "animator_duration_scale",
            defaultValue = "1.0",
            revertCommand = "settings put global animator_duration_scale 1.0",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("0.0", "0x (ปิด)", "ไม่มีดีเลย์", "settings put global animator_duration_scale 0"),
                    TweakOption("0.25", "0.25x", "ไวมาก", "settings put global animator_duration_scale 0.25"),
                    TweakOption("0.5", "0.5x", "ลื่นพอดี", "settings put global animator_duration_scale 0.5"),
                    TweakOption("1.0", "1.0x (ปกติ)", "ค่าเริ่มต้นโรงงาน", "settings put global animator_duration_scale 1.0")
                )
            )
        ),
        TweakDefinition(
            id = "peak_refresh_rate",
            titleTh = "อัตรารีเฟรชหน้าจอสูงสุด (Peak Hz)",
            descriptionTh = "กำหนดเพดานเฟรมเรตการแสดงผลของหน้าจอ เลือก 120 Hz เพื่อความลื่นสูงสุด หรือ 60 Hz เพื่อประหยัดแบต",
            benefitTagTh = "จอลื่น 90-120Hz",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = "system",
            settingKey = "peak_refresh_rate",
            defaultValue = "120.0",
            revertCommand = "settings delete system peak_refresh_rate",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("120.0", "120 Hz", "ลื่นสูงสุด (ถ้ารองรับ)", "settings put system peak_refresh_rate 120.0"),
                    TweakOption("90.0", "90 Hz", "สมดุลลื่นและประหยัด", "settings put system peak_refresh_rate 90.0"),
                    TweakOption("60.0", "60 Hz", "ประหยัดพลังงาน", "settings put system peak_refresh_rate 60.0"),
                    TweakOption("auto", "อัตโนมัติ", "คืนค่ามาตรฐานระบบ", "settings delete system peak_refresh_rate")
                )
            )
        ),
        TweakDefinition(
            id = "min_refresh_rate",
            titleTh = "อัตรารีเฟรชหน้าจอขั้นต่ำ (Min Hz)",
            descriptionTh = "บังคับไม่ให้หน้าจอลด Hz ลงต่ำเกินไปขณะเลื่อนฟีดหรือเล่นเกม (ควรใช้กับจอ 90/120 Hz)",
            benefitTagTh = "ลดอาการเฟรมดรอป",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = "system",
            settingKey = "min_refresh_rate",
            defaultValue = "auto",
            revertCommand = "settings delete system min_refresh_rate",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("120.0", "ล็อก 120 Hz", "ลื่นตลอดเวลา (กินแบตเพิ่ม)", "settings put system min_refresh_rate 120.0"),
                    TweakOption("90.0", "ขั้นต่ำ 90 Hz", "ลื่นนิ่งขึ้น", "settings put system min_refresh_rate 90.0"),
                    TweakOption("60.0", "ขั้นต่ำ 60 Hz", "ประหยัดเมื่อหยุดนิ่ง", "settings put system min_refresh_rate 60.0"),
                    TweakOption("auto", "อัตโนมัติ", "ปล่อยให้ LTPO/ระบบจัดการ", "settings delete system min_refresh_rate")
                )
            )
        ),
        TweakDefinition(
            id = "long_press_timeout",
            titleTh = "ความไวในการแตะค้าง (Touch Response)",
            descriptionTh = "ลดระยะเวลารอเมื่อแตะค้างบนหน้าจอ ช่วยให้การเปิดเมนูบริบทและควบคุมเกมเร็วขึ้น",
            benefitTagTh = "ทัชติดนิ้ว",
            category = TweakCategory.DISPLAY_ANIMATION,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "secure",
            settingKey = "long_press_timeout",
            defaultValue = "400",
            revertCommand = "settings put secure long_press_timeout 400",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("200", "ไวมาก (200ms)", "เหมาะกับสายเกม", "settings put secure long_press_timeout 200"),
                    TweakOption("300", "เร็ว (300ms)", "กระชับกำลังดี", "settings put secure long_press_timeout 300"),
                    TweakOption("400", "ปกติ (400ms)", "ค่ามาตรฐาน Android", "settings put secure long_press_timeout 400"),
                    TweakOption("500", "ช้า (500ms)", "กันกดค้างพลาด", "settings put secure long_press_timeout 500")
                )
            )
        ),
        TweakDefinition(
            id = "cached_apps_freezer",
            titleTh = "แช่แข็งแอปเบื้องหลัง (Cached Apps Freezer)",
            descriptionTh = "ฟีเจอร์หลักของ Android 14 ใช้ cgroup แช่แข็งแอปที่พักไว้ใน RAM ทันที ลดการใช้ CPU และแบตเบื้องหลัง",
            benefitTagTh = "ลดค้างและลดร้อน",
            category = TweakCategory.GAME_RUNTIME,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = "global",
            settingKey = "cached_apps_freezer",
            defaultValue = "device_default",
            revertCommand = "settings put global cached_apps_freezer device_default",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("enabled", "เปิดใช้งาน (แนะนำ)", "แช่แข็งแอปพักไว้ทันที", "settings put global cached_apps_freezer enabled"),
                    TweakOption("device_default", "ค่าเริ่มต้นระบบ", "ตามที่ผู้ผลิตกำหนด", "settings put global cached_apps_freezer device_default"),
                    TweakOption("disabled", "ปิดใช้งาน", "ไม่แช่แข็งแอปพัก", "settings put global cached_apps_freezer disabled")
                )
            )
        ),
        TweakDefinition(
            id = "bg_dexopt_job",
            titleTh = "คอมไพล์แอปทั้งเครื่องด้วย ART (bg-dexopt)",
            descriptionTh = "สั่งให้ Android Runtime ปรับแต่งโค้ดแอปเบื้องหลังทันที ช่วยให้เปิดแอปเร็วและเฟรมเรตนิ่งขึ้น",
            benefitTagTh = "เปิดแอปไวและเสถียร",
            category = TweakCategory.GAME_RUNTIME,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "action",
            revertCommand = null,
            controlType = TweakControlType.ActionButton(
                buttonLabelTh = "สั่งคอมไพล์ ART ทันที",
                command = "cmd package bg-dexopt-job"
            )
        ),
        TweakDefinition(
            id = "trim_caches",
            titleTh = "ล้างไฟล์แคชขยะทั้งระบบอย่างปลอดภัย",
            descriptionTh = "สั่งตัวจัดการแพ็กเกจของ Android เคลียร์พื้นที่แคชชั่วคราวที่ไม่จำเป็น โดยไม่ลบข้อมูลล็อกอินแอป",
            benefitTagTh = "คืนพื้นที่และลดหน่วง",
            category = TweakCategory.BACKGROUND_DEBLOAT,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "action",
            revertCommand = null,
            controlType = TweakControlType.ActionButton(
                buttonLabelTh = "ล้างแคชระบบ 4 GB",
                command = "pm trim-caches 4096M"
            )
        ),
        TweakDefinition(
            id = "idle_maintenance",
            titleTh = "เร่งทำความสะอาดหน่วยความจำ (Idle Maint)",
            descriptionTh = "สั่งงานบำรุงรักษาพื้นหลังของระบบ Android (fstrim & GC) โดยไม่ต้องรอชาร์จข้ามคืน",
            benefitTagTh = "หน่วยความจำลื่นขึ้น",
            category = TweakCategory.BACKGROUND_DEBLOAT,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "action",
            revertCommand = null,
            controlType = TweakControlType.ActionButton(
                buttonLabelTh = "รันบำรุงรักษาระบบ",
                command = "am idle-maintenance"
            )
        ),
        TweakDefinition(
            id = "private_dns_preset",
            titleTh = "ตั้งค่า Private DNS (ลดปิง / กรองโฆษณา)",
            descriptionTh = "เปลี่ยน DNS เข้ารหัสระดับระบบ Android 14 ช่วยให้เปิดเว็บไวขึ้นและลดโฆษณารบกวน",
            benefitTagTh = "เน็ตไวและปลอดภัย",
            category = TweakCategory.NETWORK_DNS,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "private_dns_specifier",
            defaultValue = "opportunistic",
            revertCommand = "settings put global private_dns_mode opportunistic",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption(
                        "one.one.one.one",
                        "Cloudflare (1.1.1.1)",
                        "ตอบสนองไว ลดปิงเกม",
                        "settings put global private_dns_mode hostname && settings put global private_dns_specifier one.one.one.one"
                    ),
                    TweakOption(
                        "dns.google",
                        "Google DNS",
                        "เสถียรสูง เชื่อถือได้",
                        "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.google"
                    ),
                    TweakOption(
                        "dns.adguard-dns.com",
                        "AdGuard DNS",
                        "ช่วยกรองโฆษณาและตัวติดตาม",
                        "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.adguard-dns.com"
                    ),
                    TweakOption(
                        "opportunistic",
                        "อัตโนมัติ (ระบบ)",
                        "ค่าเริ่มต้น Android",
                        "settings put global private_dns_mode opportunistic"
                    )
                )
            )
        ),
        TweakDefinition(
            id = "wifi_scan_always_enabled",
            titleTh = "สแกนหา Wi-Fi เบื้องหลังตลอดเวลา",
            descriptionTh = "ปิดการสแกน Wi-Fi แม้ปิดสวิตช์ Wi-Fi แล้ว ช่วยลดการใช้พลังงานและสัญญาณรบกวนระหว่างเล่นเกม",
            benefitTagTh = "ลดกินแบตและปิงนิ่ง",
            category = TweakCategory.NETWORK_DNS,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "wifi_scan_always_enabled",
            defaultValue = "1",
            revertCommand = "settings put global wifi_scan_always_enabled 1",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "0",
                offValue = "1",
                onLabelTh = "ปิดสแกนเบื้องหลัง (แนะนำ)",
                offLabelTh = "อนุญาตสแกนเบื้องหลัง",
                onCommand = "settings put global wifi_scan_always_enabled 0",
                offCommand = "settings put global wifi_scan_always_enabled 1"
            )
        ),
        TweakDefinition(
            id = "ble_scan_always_enabled",
            titleTh = "สแกนหา Bluetooth เบื้องหลังตลอดเวลา",
            descriptionTh = "ปิดการสแกน Bluetooth Low Energy เบื้องหลังเมื่อไม่ได้ใช้งาน ช่วยประหยัดพลังงานเพิ่มเติม",
            benefitTagTh = "ลดการทำงานเบื้องหลัง",
            category = TweakCategory.NETWORK_DNS,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "ble_scan_always_enabled",
            defaultValue = "1",
            revertCommand = "settings put global ble_scan_always_enabled 1",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "0",
                offValue = "1",
                onLabelTh = "ปิดสแกน BLE เบื้องหลัง",
                offLabelTh = "อนุญาตสแกน BLE",
                onCommand = "settings put global ble_scan_always_enabled 0",
                offCommand = "settings put global ble_scan_always_enabled 1"
            )
        ),
        TweakDefinition(
            id = "adaptive_battery",
            titleTh = "Adaptive Battery (จัดการแบตอัจฉริยะ)",
            descriptionTh = "ให้ AI ของ Android 14 จัดลำดับความสำคัญแอปที่ใช้บ่อยและจำกัดแอปที่ไม่ค่อยเปิด",
            benefitTagTh = "แบตอึดขึ้น",
            category = TweakCategory.BATTERY_DOZE,
            safetyLevel = SafetyLevel.ANDROID_14_VERIFIED,
            settingNamespace = "global",
            settingKey = "adaptive_battery_management_enabled",
            defaultValue = "1",
            revertCommand = "settings put global adaptive_battery_management_enabled 1",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "1",
                offValue = "0",
                onLabelTh = "เปิด Adaptive Battery",
                offLabelTh = "ปิด Adaptive Battery",
                onCommand = "settings put global adaptive_battery_management_enabled 1",
                offCommand = "settings put global adaptive_battery_management_enabled 0"
            )
        ),
        TweakDefinition(
            id = "low_power_mode",
            titleTh = "โหมดประหยัดพลังงานระบบ (Battery Saver)",
            descriptionTh = "สลับโหมดประหยัดพลังงานของ Android ทันที ลดการทำงานเบื้องหลังและจำกัดเอฟเฟกต์ที่ใช้ไฟสูง",
            benefitTagTh = "ยืดอายุแบตเตอรี่",
            category = TweakCategory.BATTERY_DOZE,
            safetyLevel = SafetyLevel.SAFE_100,
            settingNamespace = "global",
            settingKey = "low_power",
            defaultValue = "0",
            revertCommand = "settings put global low_power 0",
            controlType = TweakControlType.ToggleSwitch(
                onValue = "1",
                offValue = "0",
                onLabelTh = "เปิดประหยัดพลังงาน",
                offLabelTh = "ปิด (ใช้เต็มประสิทธิภาพ)",
                onCommand = "settings put global low_power 1",
                offCommand = "settings put global low_power 0"
            )
        ),
        TweakDefinition(
            id = "deep_doze_idle",
            titleTh = "เร่งเข้าสู่โหมด Deep Doze ทันที",
            descriptionTh = "บังคับระบบเข้าสู่โหมดหลับลึกเมื่อปิดจอ ช่วยลดแบตไหลขณะวางเครื่องทิ้งไว้",
            benefitTagTh = "สแตนด์บายแบตนิ่ง",
            category = TweakCategory.BATTERY_DOZE,
            safetyLevel = SafetyLevel.CAUTION,
            settingNamespace = null,
            settingKey = null,
            defaultValue = "unforce",
            revertCommand = "dumpsys deviceidle unforce",
            controlType = TweakControlType.ChoiceChips(
                options = listOf(
                    TweakOption("force-idle", "เข้าสู่ Deep Doze", "หลับลึกทันที", "dumpsys deviceidle force-idle"),
                    TweakOption("unforce", "ปลดล็อกปกติ", "คืนค่า Doze อัตโนมัติ", "dumpsys deviceidle unforce")
                )
            )
        )
    )

    fun buildCommandForTweakValue(tweakId: String, value: String): String? {
        val tweak = allTweaks.firstOrNull { it.id == tweakId } ?: return null
        return when (val control = tweak.controlType) {
            is TweakControlType.ChoiceChips ->
                control.options.firstOrNull { it.value == value }?.command
            is TweakControlType.ToggleSwitch ->
                if (value == control.onValue) control.onCommand else control.offCommand
            is TweakControlType.ActionButton -> control.command
        }
    }

    fun getDisplayLabelForTweakValue(tweakId: String, value: String): String {
        val tweak = allTweaks.firstOrNull { it.id == tweakId } ?: return value
        return when (val control = tweak.controlType) {
            is TweakControlType.ChoiceChips ->
                control.options.firstOrNull { it.value == value }?.labelTh ?: value
            is TweakControlType.ToggleSwitch ->
                if (value == control.onValue) control.onLabelTh else control.offLabelTh
            is TweakControlType.ActionButton -> control.buttonLabelTh
        }
    }

    fun commandsForCpuGpuPreset(mode: CpuGpuPresetMode): List<Triple<String, String, String>> {
        return when (mode) {
            CpuGpuPresetMode.SHARP_VISUALS -> listOf(
                Triple("gpu_screen_resolution", "native", "wm size reset"),
                Triple("gpu_hwui_renderer", "skiavk", "setprop debug.hwui.renderer skiavk"),
                Triple("gpu_force_msaa", "true", "setprop debug.egl.force_msaa true"),
                Triple("gpu_updatable_driver", "1", "settings put global updatable_driver_all_apps 1"),
                Triple("peak_refresh_rate", "120.0", "settings put system peak_refresh_rate 120.0"),
                Triple("window_animation_scale", "0.5", "settings put global window_animation_scale 0.5"),
                Triple("transition_animation_scale", "0.5", "settings put global transition_animation_scale 0.5"),
                Triple("animator_duration_scale", "0.5", "settings put global animator_duration_scale 0.5")
            )

            CpuGpuPresetMode.SMOOTH_FPS -> listOf(
                Triple("cpu_fixed_performance", "true", "cmd power set-fixed-performance-mode-enabled true"),
                Triple("cpu_adaptive_power_saver", "false", "cmd power set-adaptive-power-saver-enabled false"),
                Triple("gpu_updatable_driver", "1", "settings put global updatable_driver_all_apps 1"),
                Triple("gpu_force_msaa", "false", "setprop debug.egl.force_msaa false"),
                Triple("gpu_sf_latch_unsignaled", "1", "setprop debug.sf.latch_unsignaled 1"),
                Triple("cached_apps_freezer", "enabled", "settings put global cached_apps_freezer enabled"),
                Triple("peak_refresh_rate", "120.0", "settings put system peak_refresh_rate 120.0"),
                Triple("window_animation_scale", "0.25", "settings put global window_animation_scale 0.25"),
                Triple("transition_animation_scale", "0.25", "settings put global transition_animation_scale 0.25"),
                Triple("animator_duration_scale", "0.25", "settings put global animator_duration_scale 0.25")
            )

            CpuGpuPresetMode.BALANCED -> listOf(
                Triple("cpu_fixed_performance", "false", "cmd power set-fixed-performance-mode-enabled false"),
                Triple("cpu_adaptive_power_saver", "true", "cmd power set-adaptive-power-saver-enabled true"),
                Triple("gpu_screen_resolution", "native", "wm size reset"),
                Triple("gpu_force_msaa", "false", "setprop debug.egl.force_msaa false"),
                Triple("gpu_sf_latch_unsignaled", "0", "setprop debug.sf.latch_unsignaled 0"),
                Triple("gpu_updatable_driver", "0", "settings put global updatable_driver_all_apps 0"),
                Triple("cached_apps_freezer", "enabled", "settings put global cached_apps_freezer enabled"),
                Triple("window_animation_scale", "0.5", "settings put global window_animation_scale 0.5"),
                Triple("transition_animation_scale", "0.5", "settings put global transition_animation_scale 0.5"),
                Triple("animator_duration_scale", "0.5", "settings put global animator_duration_scale 0.5")
            )
        }
    }

    val safeRevertAllCommands: List<Pair<String, String>> = listOf(
        "คืนค่า CPU Fixed Performance" to "cmd power set-fixed-performance-mode-enabled false && cmd power set-adaptive-power-saver-enabled true",
        "คืนค่า GPU Driver & MSAA" to "settings put global updatable_driver_all_apps 0 && setprop debug.egl.force_msaa false && setprop debug.sf.latch_unsignaled 0",
        "คืนค่าความละเอียด & DPI เดิม" to "wm size reset && wm density reset",
        "คืนค่าแอนิเมชันหน้าต่าง 1.0x" to "settings put global window_animation_scale 1.0",
        "คืนค่าแอนิเมชันเปลี่ยนหน้า 1.0x" to "settings put global transition_animation_scale 1.0",
        "คืนค่าตัวเคลื่อนไหว 1.0x" to "settings put global animator_duration_scale 1.0",
        "คืนค่ารีเฟรชหน้าจออัตโนมัติ" to "settings delete system peak_refresh_rate && settings delete system min_refresh_rate",
        "คืนค่าความไวแตะค้าง 400ms" to "settings put secure long_press_timeout 400",
        "คืนค่า Cached Apps Freezer" to "settings put global cached_apps_freezer device_default",
        "คืนค่า Private DNS อัตโนมัติ" to "settings put global private_dns_mode opportunistic",
        "คืนค่า Doze & Battery Saver" to "dumpsys deviceidle unforce && settings put global low_power 0"
    )
}
