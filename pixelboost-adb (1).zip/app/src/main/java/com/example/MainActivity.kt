package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.model.AppFilter
import com.example.model.AppSafetyRisk
import com.example.model.ShizukuConnectionState
import com.example.model.ThemeMode
import com.example.model.TweakCategory
import com.example.ui.TunerViewModel
import com.example.ui.components.ExpressiveWavyLinearProgress
import com.example.ui.components.ShizukuSetupGuideSheet
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProfilesAndLogsScreen
import com.example.ui.screens.TweaksScreen
import com.example.ui.theme.ExpressiveMotion
import com.example.ui.theme.LocalReduceMotion
import com.example.ui.theme.PixelBoostTheme
import kotlinx.serialization.Serializable

@Serializable
object DashboardRoute

@Serializable
object TweaksRoute

@Serializable
object AppsRoute

@Serializable
object ProfilesRoute

private data class TopDestination(
    val route: Any,
    val labelTh: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: TunerViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val themeAccent by viewModel.themeAccent.collectAsStateWithLifecycle()

            PixelBoostTheme(themeMode = themeMode, themeAccent = themeAccent) {
                PixelBoostApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun PixelBoostApp(viewModel: TunerViewModel) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val reduceMotion = LocalReduceMotion.current

    val shizukuState by viewModel.shizukuState.collectAsStateWithLifecycle()
    val shizukuDetail by viewModel.shizukuDetail.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val tweakValues by viewModel.tweakValues.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val tweakSearchQuery by viewModel.tweakSearchQuery.collectAsStateWithLifecycle()
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val isLoadingApps by viewModel.isLoadingApps.collectAsStateWithLifecycle()
    val isExecuting by viewModel.isExecuting.collectAsStateWithLifecycle()
    val executionMessage by viewModel.executionMessage.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val themeAccent by viewModel.themeAccent.collectAsStateWithLifecycle()
    val activeCpuGpuMode by viewModel.activeCpuGpuMode.collectAsStateWithLifecycle()
    val appFilter by viewModel.appFilter.collectAsStateWithLifecycle()
    val confirmBeforeRun by viewModel.confirmBeforeRun.collectAsStateWithLifecycle()
    val showCommandChips by viewModel.showCommandChips.collectAsStateWithLifecycle()

    var showGuideSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { msg ->
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(msg)
        }
    }

    val destinations = remember {
        listOf(
            TopDestination(
                route = DashboardRoute,
                labelTh = "หน้าหลัก",
                selectedIcon = Icons.Filled.Dashboard,
                unselectedIcon = Icons.Outlined.Dashboard,
                testTag = "nav_dashboard"
            ),
            TopDestination(
                route = TweaksRoute,
                labelTh = "ปรับแต่ง",
                selectedIcon = Icons.Filled.Tune,
                unselectedIcon = Icons.Outlined.Tune,
                testTag = "nav_tweaks"
            ),
            TopDestination(
                route = AppsRoute,
                labelTh = "จัดการแอป",
                selectedIcon = Icons.Filled.Apps,
                unselectedIcon = Icons.Outlined.Apps,
                testTag = "nav_apps"
            ),
            TopDestination(
                route = ProfilesRoute,
                labelTh = "โปรไฟล์",
                selectedIcon = Icons.Filled.History,
                unselectedIcon = Icons.Outlined.History,
                testTag = "nav_profiles"
            )
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navigateTo: (Any) -> Unit = { dest ->
        navController.navigate(dest) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp
        val cs = MaterialTheme.colorScheme

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = cs.surface,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = cs.surfaceContainer,
                        tonalElevation = 0.dp
                    ) {
                        destinations.forEach { item ->
                            val selected = when (item.route) {
                                is DashboardRoute -> currentDestination?.hasRoute<DashboardRoute>() == true
                                is TweaksRoute -> currentDestination?.hasRoute<TweaksRoute>() == true
                                is AppsRoute -> currentDestination?.hasRoute<AppsRoute>() == true
                                else -> currentDestination?.hasRoute<ProfilesRoute>() == true
                            }
                            val iconScale by animateFloatAsState(
                                targetValue = if (selected && !reduceMotion) 1.12f else 1.0f,
                                animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
                                label = "navIconScale"
                            )
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = cs.onPrimaryContainer,
                                    selectedTextColor = cs.primary,
                                    indicatorColor = cs.primaryContainer,
                                    unselectedIconColor = cs.onSurfaceVariant,
                                    unselectedTextColor = cs.onSurfaceVariant
                                ),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.labelTh,
                                        modifier = Modifier.graphicsLayer {
                                            scaleX = iconScale
                                            scaleY = iconScale
                                        }
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.labelTh,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = cs.surfaceContainerLow
                    ) {
                        destinations.forEach { item ->
                            val selected = when (item.route) {
                                is DashboardRoute -> currentDestination?.hasRoute<DashboardRoute>() == true
                                is TweaksRoute -> currentDestination?.hasRoute<TweaksRoute>() == true
                                is AppsRoute -> currentDestination?.hasRoute<AppsRoute>() == true
                                else -> currentDestination?.hasRoute<ProfilesRoute>() == true
                            }
                            val iconScale by animateFloatAsState(
                                targetValue = if (selected && !reduceMotion) 1.12f else 1.0f,
                                animationSpec = ExpressiveMotion.spatialFast(reduceMotion),
                                label = "railIconScale"
                            )
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(item.route) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = cs.onPrimaryContainer,
                                    selectedTextColor = cs.primary,
                                    indicatorColor = cs.primaryContainer,
                                    unselectedIconColor = cs.onSurfaceVariant,
                                    unselectedTextColor = cs.onSurfaceVariant
                                ),
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.labelTh,
                                        modifier = Modifier.graphicsLayer {
                                            scaleX = iconScale
                                            scaleY = iconScale
                                        }
                                    )
                                },
                                label = {
                                    Text(
                                        item.labelTh,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1
                                    )
                                },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    AnimatedVisibility(visible = isExecuting) {
                        Surface(
                            color = cs.primaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                ExpressiveWavyLinearProgress(
                                    color = cs.primary,
                                    trackColor = cs.onPrimaryContainer.copy(alpha = 0.2f)
                                )
                                if (executionMessage.isNotBlank()) {
                                    Text(
                                        text = executionMessage,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = cs.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = DashboardRoute,
                        enterTransition = {
                            if (reduceMotion) {
                                fadeIn(ExpressiveMotion.effectsDefault(true))
                            } else {
                                fadeIn(ExpressiveMotion.effectsDefault(false)) +
                                    scaleIn(
                                        initialScale = 0.96f,
                                        animationSpec = ExpressiveMotion.spatialDefault(false)
                                    )
                            }
                        },
                        exitTransition = {
                            fadeOut(ExpressiveMotion.effectsFast(reduceMotion))
                        },
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        composable<DashboardRoute> {
                            val currentAnimScale = tweakValues["window_animation_scale"] ?: "1.0"
                            val safeBloatCount = installedApps.count { it.safetyRisk == AppSafetyRisk.SAFE_BLOATWARE }
                            val frozenCount = installedApps.count { !it.isEnabled }
                            DashboardScreen(
                                shizukuState = shizukuState,
                                shizukuDetail = shizukuDetail,
                                telemetry = telemetry,
                                currentAnimationScale = currentAnimScale,
                                safeBloatCount = safeBloatCount,
                                frozenAppsCount = frozenCount,
                                profiles = profiles,
                                themeMode = themeMode,
                                themeAccent = themeAccent,
                                activeCpuGpuMode = activeCpuGpuMode,
                                cpuGpuModeScript = viewModel.buildCpuGpuPresetScript(activeCpuGpuMode),
                                decodeSettings = { viewModel.repository.decodeSettings(it) },
                                buildProfileScript = { viewModel.buildProfileScript(it) },
                                onPrimaryShizukuAction = {
                                    when (shizukuState) {
                                        ShizukuConnectionState.PERMISSION_REQUIRED ->
                                            viewModel.requestShizukuPermissionOrConnect()
                                        ShizukuConnectionState.NOT_RUNNING ->
                                            viewModel.openShizukuApp()
                                        ShizukuConnectionState.NOT_INSTALLED ->
                                            showGuideSheet = true
                                        else ->
                                            viewModel.refreshConnectionAndTelemetry()
                                    }
                                },
                                onRefreshAll = { viewModel.refreshConnectionAndTelemetry() },
                                onOpenGuide = { showGuideSheet = true },
                                onCycleThemeMode = {
                                    val next = when (themeMode) {
                                        ThemeMode.DARK -> ThemeMode.LIGHT
                                        ThemeMode.LIGHT -> ThemeMode.SYSTEM
                                        ThemeMode.SYSTEM -> ThemeMode.DARK
                                    }
                                    viewModel.setThemeMode(next)
                                },
                                onSelectThemeAccent = { viewModel.setThemeAccent(it) },
                                onSelectCpuGpuMode = { viewModel.applyCpuGpuPresetMode(it) },
                                onOpenCpuGpuTweaks = {
                                    viewModel.setSelectedCategory(TweakCategory.GPU_GRAPHICS)
                                    navigateTo(TweaksRoute)
                                },
                                onApplyUnifiedAnimation = { viewModel.applyUnifiedAnimationScale(it) },
                                onOpenBloatwareManager = {
                                    viewModel.setAppFilter(
                                        if (safeBloatCount > 0) AppFilter.BLOATWARE else AppFilter.USER
                                    )
                                    navigateTo(AppsRoute)
                                },
                                onApplyRefreshAndFreezerBoost = {
                                    viewModel.applyBoostRefreshAndFreezer()
                                },
                                onRunCacheAndArtBoost = {
                                    viewModel.runDirectCommand(
                                        "ล้างแคช 4GB + คอมไพล์ ART",
                                        "pm trim-caches 4096M && cmd package bg-dexopt-job"
                                    )
                                },
                                onApplyProfile = { viewModel.applyProfile(it) },
                                onCopyProfileScript = { profile, script ->
                                    viewModel.recordCopiedCommand("โปรไฟล์ ${profile.name}", script)
                                },
                                onCopyCommand = { title, cmd ->
                                    viewModel.recordCopiedCommand(title, cmd)
                                },
                                onRevertAll = { viewModel.revertAllToDefault() },
                                onNavigateToTweaks = { navigateTo(TweaksRoute) }
                            )
                        }

                        composable<TweaksRoute> {
                            TweaksScreen(
                                selectedCategory = selectedCategory,
                                searchQuery = tweakSearchQuery,
                                tweakValues = tweakValues,
                                confirmBeforeRun = confirmBeforeRun,
                                showCommandChips = showCommandChips,
                                onCategorySelected = { viewModel.setSelectedCategory(it) },
                                onSearchQueryChange = { viewModel.setTweakSearchQuery(it) },
                                onApplyTweak = { tweak, value, cmd ->
                                    viewModel.applyTweak(tweak, value, cmd)
                                },
                                onRevertTweak = { viewModel.revertTweak(it) },
                                onCopyCommand = { title, cmd ->
                                    viewModel.recordCopiedCommand(title, cmd)
                                }
                            )
                        }

                        composable<AppsRoute> {
                            AppsScreen(
                                apps = installedApps,
                                isLoading = isLoadingApps,
                                filter = appFilter,
                                onFilterChange = { viewModel.setAppFilter(it) },
                                onReloadApps = { viewModel.loadInstalledApps() },
                                onRunPerAppCommand = { app, title, cmd, reload ->
                                    viewModel.runPerAppCommand(app, title, cmd, reload)
                                },
                                onBatchFreeze = { viewModel.batchFreezeApps(it) },
                                onBatchEnable = { viewModel.batchEnableApps(it) },
                                onBatchRestrict = { viewModel.batchRestrictBackground(it) },
                                onRestoreAllFrozen = { viewModel.restoreAllFrozenApps() },
                                onCopyCommand = { title, cmd ->
                                    viewModel.recordCopiedCommand(title, cmd)
                                }
                            )
                        }

                        composable<ProfilesRoute> {
                            ProfilesAndLogsScreen(
                                profiles = profiles,
                                recentLogs = recentLogs,
                                themeMode = themeMode,
                                themeAccent = themeAccent,
                                confirmBeforeRun = confirmBeforeRun,
                                showCommandChips = showCommandChips,
                                decodeSettings = { viewModel.repository.decodeSettings(it) },
                                buildProfileScript = { viewModel.buildProfileScript(it) },
                                onApplyProfile = { viewModel.applyProfile(it) },
                                onCreateCustomProfile = { name, desc, icon, map ->
                                    viewModel.createCustomProfile(name, desc, icon, map)
                                },
                                onDeleteCustomProfile = { viewModel.deleteCustomProfile(it) },
                                onClearLogs = { viewModel.clearLogs() },
                                onRerunCommand = { title, cmd -> viewModel.runDirectCommand(title, cmd) },
                                onCopyCommand = { title, cmd -> viewModel.recordCopiedCommand(title, cmd) },
                                onThemeModeChange = { viewModel.setThemeMode(it) },
                                onThemeAccentChange = { viewModel.setThemeAccent(it) },
                                onConfirmBeforeRunChange = { viewModel.setConfirmBeforeRun(it) },
                                onShowCommandChipsChange = { viewModel.setShowCommandChips(it) },
                                onOpenGuide = { showGuideSheet = true }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showGuideSheet) {
        ShizukuSetupGuideSheet(
            onDismiss = { showGuideSheet = false },
            onOpenDeveloperSettings = { viewModel.openWirelessDebuggingSettings() },
            onOpenShizuku = { viewModel.openShizukuApp() },
            onCopyPcCommand = { cmd ->
                viewModel.recordCopiedCommand("คำสั่งเริ่ม Shizuku ผ่าน PC", cmd)
            }
        )
    }
}
