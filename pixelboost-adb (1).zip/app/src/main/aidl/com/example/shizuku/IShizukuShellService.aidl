package com.example.shizuku;

interface IShizukuShellService {
    String execCommand(String command);
    void destroy();
}
