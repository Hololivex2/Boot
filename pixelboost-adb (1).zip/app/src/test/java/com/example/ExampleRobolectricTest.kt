package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.Android14TweakCatalog
import com.example.model.AppSafetyRisk
import com.example.model.BloatwareAdvisor
import com.example.model.CpuGpuPresetMode
import com.example.model.TweakCategory
import com.example.ui.theme.BlueLightPrimary
import com.example.ui.theme.ExpressiveCorner
import com.example.ui.theme.PurpleDarkPrimary
import com.example.ui.theme.PurpleDarkSurface
import com.example.ui.theme.PurpleLightPrimary
import com.example.ui.theme.PurpleLightSurface
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PixelBoost ADB", appName)
    }

    @Test
    fun `material 3 expressive color and corner tokens match baseline spec`() {
        assertEquals(Color(0xFF6750A4), PurpleLightPrimary)
        assertEquals(Color(0xFFFEF7FF), PurpleLightSurface)
        assertEquals(Color(0xFFD0BCFF), PurpleDarkPrimary)
        assertEquals(Color(0xFF141218), PurpleDarkSurface)
        assertTrue(BlueLightPrimary != PurpleLightPrimary)
        assertEquals(28.dp, ExpressiveCorner.ExtraLarge)
    }

    @Test
    fun `catalog builds valid android 14 adb commands`() {
        val cmd = Android14TweakCatalog.buildCommandForTweakValue("window_animation_scale", "0.25")
        assertEquals("settings put global window_animation_scale 0.25", cmd)
        assertTrue(Android14TweakCatalog.allTweaks.isNotEmpty())
    }

    @Test
    fun `cpu and gpu categories and presets produce expected android 14 commands`() {
        val cpuTweaks = Android14TweakCatalog.allTweaks.filter { it.category == TweakCategory.CPU_PERFORMANCE }
        val gpuTweaks = Android14TweakCatalog.allTweaks.filter { it.category == TweakCategory.GPU_GRAPHICS }
        assertTrue(cpuTweaks.size >= 4)
        assertTrue(gpuTweaks.size >= 8)

        val sharpCmds = Android14TweakCatalog.commandsForCpuGpuPreset(CpuGpuPresetMode.SHARP_VISUALS)
        assertTrue(sharpCmds.any { it.third == "setprop debug.egl.force_msaa true" })
        assertTrue(sharpCmds.any { it.third == "setprop debug.hwui.renderer skiavk" })

        val smoothCmds = Android14TweakCatalog.commandsForCpuGpuPreset(CpuGpuPresetMode.SMOOTH_FPS)
        assertTrue(smoothCmds.any { it.third == "cmd power set-fixed-performance-mode-enabled true" })
        assertTrue(smoothCmds.any { it.third == "setprop debug.egl.force_msaa false" })

        val balancedCmds = Android14TweakCatalog.commandsForCpuGpuPreset(CpuGpuPresetMode.BALANCED)
        assertTrue(balancedCmds.any { it.third == "cmd power set-fixed-performance-mode-enabled false" })
        assertTrue(balancedCmds.any { it.third == "wm size reset" })
    }

    @Test
    fun `bloatware advisor classifies safe and critical packages accurately`() {
        assertEquals(
            AppSafetyRisk.SAFE_BLOATWARE,
            BloatwareAdvisor.evaluate("com.facebook.system", true).risk
        )
        assertEquals(
            AppSafetyRisk.SYSTEM_CRITICAL,
            BloatwareAdvisor.evaluate("com.android.systemui", true).risk
        )
        assertEquals(
            AppSafetyRisk.OPTIONAL,
            BloatwareAdvisor.evaluate("com.custom.app", false).risk
        )
    }
}
